# Putting Mwani Zanzibar online (Firebase + GitHub Pages)

| Piece | Service | Cost |
|---|---|---|
| Database (products, orders, reviews, site text) and staff login | **Firebase** (Firestore + Authentication), free Spark plan | Free |
| Website hosting | **GitHub Pages** | Free |

- **No looking after:** Firebase never pauses or expires a free project, and GitHub Pages rebuilds the site by itself.
- **No terminal:**
  - Parts 1, 3 and 4 can be done in a phone browser.
  - Part 2 (sending the code to GitHub) is done once from the laptop with the GitHub Desktop app.
  - The products are loaded with one button in the admin panel.

> The site is already connected to the shop's Firebase project (`mwanizanzi`). Until the catalogue is loaded (Part 4), the shop shows no products.

---

## Part 1. Firebase (phone-friendly, about 10 minutes)

**Step 1. Create the project**
1. Open https://console.firebase.google.com and sign in with the business Google account.
2. Tap **Create a project**, name it `mwani-zanzibar`, and continue. Google Analytics isn't needed; you can switch it off.

**Step 2. Create the database**
1. **Build → Firestore Database → Create database**.
2. Location: **africa-south1 (Johannesburg)**, the closest to Zanzibar. It can't be changed later.
3. Choose **Start in production mode** → **Create**.

**Step 3. Paste the security rules**
1. In Firestore Database, open the **Rules** tab and delete everything in the editor.
2. Paste the whole contents of the **`firestore.rules`** file from the project. On a phone, open the file on GitHub (after Part 2) and tap **Raw**, or use the copy sent with this guide.
3. Tap **Publish**.

The rules decide who can do what:
- **Visitors can:** read the products, place an order, track their own order by number, send a review for approval, and join the newsletter.
- **Only staff can:** change anything, or see orders and customer details.

**Step 4. Staff login**
1. **Build → Authentication → Get started**.
2. **Sign-in method** → **Email/Password** → turn on the first switch → **Save**.
3. **Users** → **Add user** → the owner's email and a strong password → **Add user**.
4. Recommended: **Settings** tab → **User actions** → untick **Enable create (sign-up)** → **Save**. Then only you can create accounts.

**Step 5. Put the owner on the staff list**
1. **Firestore Database → Data** → **Start collection**.
2. Collection ID: `admins` → **Next**.
3. **Document ID:** the owner's email, **all in small letters**, for example `mama@wakulimahai.org`.
4. Add one field: name `role`, type `string`, value `owner` → **Save**.

To add more staff later: create their user in Authentication (Step 4), then add another document in `admins` with their email as the Document ID.

**Step 6. Connection:** already done. The shop's project settings (`mwanizanzi`) are built into `src/lib/firebase-config.ts`, so nothing needs to be copied or pasted.

---

## Part 2. Put the code on GitHub (laptop, once, no terminal)

1. Unzip `mwani-zanzibar-improved.zip`, for example to `C:\Projects\mwani`.
2. Install **GitHub Desktop** from https://desktop.github.com and sign in.
3. **File → Add local repository** → choose the `mwani` folder.
   - It will say this isn't a repository yet. Click **create a repository** → **Create repository**.
4. Click **Publish repository**.
   - Name: `mwani-zanzibar`
   - **Untick "Keep this code private"**. Free GitHub Pages needs a public repository.
   - Click **Publish repository**.

Later, to publish code changes: GitHub Desktop → short summary → **Commit to main** → **Push origin**. Or connect GitHub to Claude and ask Claude to push.

---

## Part 3. Switch on the website (github.com, phone is fine)

In the `mwani-zanzibar` repository:

1. **Settings → Pages** → under **Build and deployment**, set **Source** to **GitHub Actions**.
2. **Actions** tab → **Publish site** → **Run workflow** → **Run workflow**.
3. Wait for the green tick (about 3 minutes). The shop is live at **`https://YOUR-USERNAME.github.io/mwani-zanzibar/`**. The exact link is under **Settings → Pages**.

From now on, the site republishes itself every time code is pushed.

**Your own domain (optional):**
1. Add a variable `CUSTOM_DOMAIN`, for example `shop.wakulimahai.org`.
2. At your domain provider, add a **CNAME** record for `shop` pointing to `YOUR-USERNAME.github.io`.
3. In **Settings → Pages**, enter the domain under **Custom domain**. Tick **Enforce HTTPS** when it becomes available.
4. Run the workflow again.

---

## Part 4. Load the products and check everything (phone)

1. Open the live site. It will have no products yet; that's expected.
2. Open `…/mwani-zanzibar/?admin=1` and sign in with the owner email and password.
3. The dashboard says **"Your shop has no products yet"**. Tap **Load starting catalogue**. It adds the 15 products with photos, 6 recipes, sample promo codes and the shop settings. This takes a few seconds and only works once.
4. **Settings:** check both WhatsApp numbers, the footer phone, email, address, Instagram, the mainland shipping fee and the free-shipping amount.
5. **Products:** set the real prices. These are placeholders: Dried Seaweed, Seaweed Jelly, Scrub Powder, Seaweed Rub and the five soaps. Also confirm the Tea ingredients and the Hair Oil, Scrub and Rub sizes.
6. **Settings → Promo codes:** delete or switch off the sample codes `MWANI10`, `FREESHIP` and `OCEAN20` if you don't want them.
7. **Test order:** place an order on the live site and check that WhatsApp opens with the message. Confirm it in **Admin → Orders** and check that **Track order** shows "Confirmed". Then delete the test order.
8. **Site content:** change any wording or picture. Changes show immediately, with no republish.

---

## Good to know

- **Free Firebase (Spark) plan:** about 50,000 database reads and 20,000 writes a day, and 1 GB of storage. One visit reads roughly 40 to 60 small records, so this covers around 1,000 visits a day.
  - Nothing pauses or expires.
  - If the shop grows past that, you can switch the project to the pay-as-you-go **Blaze** plan in the Firebase console. At this size it costs a few US cents a day.
- **Pictures uploaded in the admin** are stored inside the database, so keep uploads to what you need. The standard product photos are served by GitHub Pages.
- **GitHub Pages** is free for public repositories and includes HTTPS.

## If something goes wrong

| What you see | What to do |
|---|---|
| "This account is not on the staff list" | Add a document in `admins` whose ID is exactly that email, in small letters (Part 1, Step 5). |
| "That email and password did not match" | Check the user under **Authentication → Users**, or reset the password there. |
| "Missing or insufficient permissions" | The rules weren't published (Part 1, Step 3), or the account isn't in `admins`. |
| The shop shows no products | Sign in to the admin and tap **Load starting catalogue** on the dashboard. |
| The workflow has a red ✕ | Open it in the **Actions** tab; the failing step explains why. |

---

## For developers (optional)

- **Run locally:**
  1. Install Node.js 22.
  2. Run `npm install`.
  3. Run `npm run dev`. It uses the real database. For fake in-browser data instead, put `NEXT_PUBLIC_DEMO=1` in `.env.local`.
- **Code map:**
  - The data layer is `src/lib/data.ts`. It talks to `src/lib/firebase-backend.ts`, or to `demo-backend.ts` when no config is set.
  - Access rules are in `firestore.rules`.
- **Testing against the Firebase emulators:** set `NEXT_PUBLIC_FIREBASE_EMULATOR_HOST=127.0.0.1`. Never set it on the live site.
