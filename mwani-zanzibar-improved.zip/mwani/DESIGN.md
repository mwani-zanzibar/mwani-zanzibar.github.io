# Mwani Zanzibar storefront: design system

Read this before touching any storefront UI. Every component follows it.

## Direction: "Tactile lagoon"

- **Subject:** seaweed powder and seaweed tea (the two heroes) plus food, wellness, skin and hair products, made by the women farmers of the Wakulima Hai co-operative in Zanzibar.
- **Audience:** Tanzanian shoppers on mid-range Android phones, plus visitors and diaspora on desktop.
- **Primary job:** get Powder and Tea into the bag, then send the order on WhatsApp.

Decisions taken from the owner's references and feedback:

1. **The page is made of objects.** It is layered, tactile UI: rounded cards, pills, chips, floating info cards and docks, all with real shadows over warm colour and photography (N99, Travorra). It is not an editorial page of text and lines.
2. **The product is a physical thing.** It lifts out of its card and travels into the bag, and the bag is one object that changes shape between a pill and a panel (the cart video).
3. **The shop is one scroll away.** The full product grid follows the hero directly; stories come after.
4. **The hero is a composition.** It layers a headline, the real product photograph (background removed), floating facts and a dock that overlaps its bottom edge (Travorra).

**Signature move:** the real Powder scene slides out as the Tea scene slides in, and the whole hero recolours from coral to lagoon.

**Photography:** only the co-operative's real product photos. `<name>.webp` is the photo, `<name>-cut.webp` the same photo with the background removed. Each product card is a small swipeable gallery: the cut-out first on the shell well, then the real photos, with dots (and arrows on hover for mouse users); the first card peeks once so phone users discover it; stories and galleries use the photos. No 3D renders or stock images.

## Tokens (see `src/app/globals.css`)

| Role | Token | Hex | Use |
|---|---|---|---|
| Page | `--porcelain` | #FBF7F5 | page background |
| Well | `--shell` | #F4E7E4 | image wells, soft bands |
| Sand | `--sand` | #EFDDD6 | stronger wells, pressed states |
| Primary | `--plum` | #4A1022 | text, primary pills, logo ink |
| Primary hover | `--plum-2` | #6B1D33 | hover on plum |
| Night | `--night` | #1F070E | dark bands, mobile dock, cart pill |
| Accent | `--rose` | #D6879B | small accents, never body text |
| Powder theme | `--coral` | #E07B63 | Powder accents; hero bg `--powder-a/b` |
| Tea theme | `--lagoon-deep` | #0F7F8A | Tea accents, "Added" state; hero bg `--tea-a/b` |
| Bubbles | `--lagoon` | #2FC4D4 | bubble particles, tiny highlights |

Contrast: body text is `--foreground` (#2B1419) or plum on porcelain or white. Rose and coral are for decoration only.

**Type**

| Role | Setting |
|---|---|
| Display | Fraunces (`.font-display`), weight 500, opsz 144, SOFT 100. The hero's second line alone uses Fraunces italic (`.font-display-italic`), following the owner's reference. |
| Body | Figtree 400/500/600, 16px minimum, line-height 1.55. |
| Wordmark only | Quicksand 600 (`.font-logo`). |

Type scale: hero `clamp(2.8rem,7vw,6.5rem)` / 0.95; section `clamp(2.3rem,4.6vw,4.4rem)` / 1; card title 1.05–1.25rem; chip 0.84rem.

**Shape and depth**

- Radii: 10 / 14 / 20 / 28 (cards) / 36 (sections) / 40 (hero) / pill.
- Shadows: `shadow-1` rests, `shadow-2` cards, `shadow-3` floating cards, docks and sheets. They are warm-tinted and have real offsets.
- No glass. The only blur is the scrim behind sheets.

## Dark theme ("lagoon at night")

Tokens swap roles rather than adding `dark:` variants everywhere:

- `--porcelain` (paper) turns deep wine-black `#140A0D`; `--plum` (ink) turns pale rose `#F5DFE5`. Plum pills therefore become light pills with dark text.
- Cards and sheets use `bg-surface` (white / `#1E1116`), never `bg-white`.
- Text and fills that sit on the night band, photos or dark gradients use `on-night` (light in both themes), never `porcelain`.
- The night band itself becomes a rich wine `#2B0F1A` so it still reads as its own slab.
- Hero, spotlight and story backgrounds come from `--powder-*`, `--tea-*` and `--story-lagoon`, which all have dark values.
- Switching theme opens the new theme as a circle from the control that was pressed (View Transitions), instant where unsupported.

## Components

| Component | Rule |
|---|---|
| Primary button | Plum pill, 48–56px tall, porcelain text. Hover changes the background to plum-2 and slides the arrow; press scales to 0.97. |
| Secondary button | White pill with `shadow-1`, plum text. |
| Text link | Underline draws from the left (`.link-draw`). |
| Chip | Pill 36–40px tall. Inactive is white with `shadow-1`; active is plum with porcelain text. A removable chip shows an ×. |
| Card | White, 28px radius, `shadow-2`. Card-in-card image well: 8px inset, 22px radius, `--shell` background. |
| Floating info card | White, 22px radius, `shadow-3`, 12–16px padding, one icon, two lines at most. |
| Dock | Desktop hero dock: white pill. Mobile bottom dock and desktop cart pill: `--night` pill. |
| Sheet / dialog | White, 28px radius (sheets have top corners only), plum/night scrim at 40% with a 6px blur. |
| Input | 48px tall, 14px radius, white, `--input` border, 2px plum focus ring. |

Tap targets are at least 44px. Every icon-only button has an aria-label.

## Motion language

**Easings**

- `--ease-out` cubic-bezier(.22,1,.36,1): entrances and exits.
- `--ease-in-out` cubic-bezier(.65,0,.35,1): things moving on screen.
- framer-motion springs: `snappy` (stiffness 500, damping 38) for UI, `soft` (260/30) for sheets and morphs, `pop` (420/18) for tiny confirmations only.

**Durations**

| What | Duration |
|---|---|
| Press | 120ms |
| Hover | 180ms |
| Menus and chips | 220ms |
| Sheets and dialogs | 380ms in, 260ms out |
| Large text and image reveals | 700–900ms (large surfaces move slower) |
| Stagger | 40–70ms |
| Anything else over 300ms | needs a reason |

**Scroll families**

1. **Text:** section headings rise line by line from a mask (GSAP SplitText, `<SplitReveal>`). Paragraphs fade and rise 16px.
2. **Images:** clip-path unveils upward while the image settles from scale 1.12 (`<ImageReveal>`).
3. **Scrubbed:** the hero product sinks as the hero leaves; the Powder→Tea spotlight pins; the lagoon story scrolls sideways; the ordering path draws; the footer wordmark rises.
4. **Cards:** grids stagger in (y 28, scale 0.97).

**Interaction**

- The menu grows out of the three-line button as a circle; the lines fold into an ✕ in the same spot; links rise one by one and roll their label on hover.
- Primary CTAs lean a little towards the cursor (mouse only). Product cards tilt a few degrees with a soft light that follows the cursor.
- Switching Powder/Tea sends up a short burst of bubbles; unlocking free shipping in the bag does the same.
- Adding from a card floats a "+1" off the button. A back-to-top button fills its ring as you read (desktop).

- Add to bag: the product image lifts out of its card and arcs into the cart target. The button morphs to "✓ Added", then a thumbnail pushes into the pill.
- The cart pill morphs into the cart panel (shared `layoutId`) and collapses back.
- Numbers (price, quantity, count) roll.
- Hearts pop.
- Chips slide their active pill (`layoutId`).

Motion only answers the user or marks something entering the screen. Nothing loops forever.

**Reduced motion and weak devices** (`src/lib/perf.ts`)

- **Reduced motion:** final states only, no scrub.
- **Low tier** (≤4 GB RAM, ≤4 cores or Save-Data): no Lenis, no blur.
- **Phones:** native scroll (no Lenis on touch), no pinning longer than 200% of the viewport.

## Copy

- Sentence case, concrete and short.
- Buttons say what happens ("Add to bag", "Send order on WhatsApp").
- Every visible string goes through `t()` with English and Swahili.
- No invented statistics, reviews or ratings; only real product data.

## Never

- Glass surfaces, gradient text, neon glows.
- An ALL-CAPS eyebrow above every heading.
- 01/02/03 labels on things that aren't a real sequence.
- Identical icon + heading + body card grids.
- More than one marquee.
- Stock avatar stacks or made-up numbers.
- `transition: all`, animating width/height/top/left, `scale(0)` entrances.
- A scroll-down arrow.
