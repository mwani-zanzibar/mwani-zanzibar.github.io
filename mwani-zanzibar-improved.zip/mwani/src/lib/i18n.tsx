'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { storeStrings } from './i18n-store'
import { overlayStrings } from './i18n-overlays'
import { discoveryStrings } from './i18n-discovery'
import { cartStrings } from './i18n-cart'
import { sectionsStrings } from './i18n-sections'
import { useContent } from './content-store'

const LAYERS = [overlayStrings, discoveryStrings, cartStrings, sectionsStrings, storeStrings]

export type Lang = 'en' | 'sw'

// Translation dictionary. Keys are dot-path strings. English first, then Swahili.
// Keep keys flat + namespaced (nav.*, hero.*, etc.) for easy lookups.
const dict: Record<Lang, Record<string, string>> = {
  en: {
    // announcement
    'ann.ferry': 'Free shipping to mainland on orders over TSh 150,000 via Azam Ferry',
    'ann.organic': '100% organic seaweed — sustainably farmed by Zanzibari women',
    'ann.new': 'New: Seaweed Face Mask now in stock — detoxify & refresh',
    'ann.whatsapp': 'Order online, confirm & pay easily via WhatsApp',

    // nav
    'nav.products': 'Products',
    'nav.recipes': 'Recipes',
    'nav.story': 'Our Story',
    'nav.how': 'How It Works',
    'nav.reviews': 'Reviews',
    'nav.faq': 'FAQ',
    'nav.contact': 'Contact',
    'nav.track': 'Track',
    'nav.myOrders': 'My Orders',
    'nav.bag': 'Open bag',
    'nav.menu': 'Menu',
    'nav.admin': 'Admin',

    // side nav
    'side.title': 'Navigation',
    'side.currency': 'Currency',
    'side.language': 'Language',
    'side.section': 'Sections',
    'side.admin': 'Admin panel',
    'side.close': 'Close',

    // hero
    'hero.badge': 'Wakulima Hai Co-operative Society · Zanzibar',
    'hero.subtitle': '100% organic Zanzibar seaweed — powder, tea, capsules, soaps, oils & skincare, harvested by hand and crafted with care by Wakulima Hai farmers.',
    'hero.explore': 'Explore Products',
    'hero.ourStory': 'Our Story',
    'hero.bestseller': 'Bestseller',
    'hero.stats.organic': 'Organic',
    'hero.stats.products': 'Products',
    'hero.stats.loved': 'Loved',
    'hero.keepGreen': 'Keep Zanzibar green',
    'hero.farmersCoop': "A farmers' co-op",

    // featured
    'featured.eyebrow': 'Bestsellers',
    'featured.title': 'Loved by our customers',
    'featured.sub': 'Our most popular seaweed creations — trusted in Zanzibar and across mainland Tanzania.',
    'product.addToBag': 'Add to bag',
    'product.outOfStock': 'Out of stock',
    'product.onlyLeft': 'Only {n} left',

    // products section
    'products.eyebrowL': 'Our Collection',
    'products.title': 'Browse all seaweed products',
    'products.sub': 'From nourishing foods to natural skincare — pure Zanzibar seaweed, crafted with care.',
    'products.search': 'Search products…',
    'products.all': 'All products',
    'products.sort.newest': 'Newest',
    'products.sort.priceAsc': 'Price: Low → High',
    'products.sort.priceDesc': 'Price: High → Low',
    'products.sort.rating': 'Top rated',
    'products.reset': 'Reset filters',
    'products.noResults': 'No products match your search.',
    'products.showing': 'Showing {n} of {total} products',

    // recently viewed
    'recently.eyebrow': 'Pick up where you left off',
    'recently.title': 'Recently viewed',

    // recipes
    'recipes.eyebrow': 'Recipes & Rituals',
    'recipes.title': 'Make seaweed part of your',
    'recipes.sub': 'Easy recipes and daily rituals using our organic Zanzibar seaweed — from smoothie bowls to spa moments.',
    'recipes.all': 'All',
    'recipes.viewRecipe': 'View recipe',
    'recipes.popular': 'Popular',
    'recipes.ingredients': 'Ingredients',
    'recipes.method': 'Method',
    'recipes.tip': 'Tip: shop the seaweed products used in this recipe and make it part of your daily routine.',

    // story
    'story.eyebrow': 'Our Story',
    'story.keepGreen': 'Keep Zanzibar green.',
    'story.farmer': 'Wakulima Hai Co-operative Society',
    'story.sustainable': 'Sustainably farmed',
    'story.sustainableDesc': 'By hand, along the Indian Ocean coast of Zanzibar.',
    'story.farmers': 'Women farmers',
    'story.organic': 'Organic',
    'story.products': 'Products',
    'story.islands': 'Islands reached',
    'story.noAdditives': 'No additives',
    'story.sunDried': 'Sun-dried',
    'story.womenLed': 'Women-led',
    'story.eco': 'Eco packaging',

    // how it works
    'how.eyebrow': 'Simple Process',
    'how.title': 'How ordering works',
    'how.sub': 'Four easy steps from ocean to your hands — pay easily via WhatsApp.',
    'how.1.title': 'Browse & choose',
    'how.1.desc': 'Explore our seaweed products, read details and reviews, then add your favourites to the bag.',
    'how.2.title': 'Confirm your order',
    'how.2.desc': 'Review your bag, add your name, phone and delivery location (Zanzibar or mainland), then confirm.',
    'how.3.title': 'Send via WhatsApp',
    'how.3.desc': 'Press the WhatsApp button — a pre-written order message is sent to the owner to confirm payment.',
    'how.4.title': 'Track progress',
    'how.4.desc': 'Zanzibar orders are delivered locally; mainland orders ship via Azam Ferry. Track anytime with your order number.',

    // testimonials
    'testi.eyebrow': 'Customer Love',
    'testi.title': 'Trusted in Zanzibar & beyond',
    'testi.sub': 'Real words from people who made seaweed part of their lives.',
    'testi.empty': 'Be the first to leave a review!',

    // FAQ
    'faq.eyebrow': 'Questions?',
    'faq.title': 'Everything you need to know',
    'faq.sub': "Can't find the answer you're looking for? Reach out on WhatsApp — we love a good seaweed question.",
    'faq.stillCurious': 'Still curious?',
    'faq.chatTeam': 'Chat with our team directly — we usually reply within minutes.',
    'faq.askWhatsapp': 'Ask on WhatsApp',

    // contact
    'contact.eyebrow': 'Get in touch',
    'contact.title': "We'd love to hear from you",
    'contact.sub': 'Questions about products, bulk orders, or shipping? Reach us directly — we respond fast.',
    'contact.callWhatsapp': 'Call / WhatsApp',
    'contact.secondary': 'Secondary line',
    'contact.email': 'Email',
    'contact.website': 'Website',
    'contact.address': 'Address',
    'contact.instagram': 'Instagram',
    'contact.shippingTitle': 'Shipping to mainland Tanzania',
    'contact.whatsappOrderTitle': 'Order via WhatsApp',
    'contact.whatsappOrderDesc': 'Confirm your order on the site, then tap the WhatsApp button to send your order details instantly to the owner.',
    'contact.chatNow': 'Chat with us now',
    'contact.trackOrder': 'Track my order',

    // footer
    'footer.newsletter': 'Newsletter',
    'footer.getOcean': 'Get ocean goodness in your inbox',
    'footer.newsletterDesc': 'Seaweed recipes, wellness tips, new products & special offers. No spam — just the good stuff.',
    'footer.privacy': 'We respect your privacy. Unsubscribe anytime.',
    'footer.join': 'Join',
    'footer.explore': 'Explore',
    'footer.allProducts': 'All Products',
    'footer.recipes': 'Recipes & Rituals',
    'footer.ourStory': 'Our Story',
    'footer.howWorks': 'How It Works',
    'footer.reviews': 'Reviews',
    'footer.faq': 'FAQ',
    'footer.contact': 'Contact',
    'footer.myOrders': 'My Orders',
    'footer.trackOrder': 'Track Order',
    'footer.byCoop': 'by Wakulima Hai Co-operative',
    'footer.copyright': 'Wakulima Hai Co-operative Society. All rights reserved.',
    'footer.admin': 'Admin Panel',

    // cart
    'cart.title': 'Your Bag',
    'cart.empty': 'Your bag is empty.',
    'cart.items': '{n} item(s) selected',
    'cart.emptyTitle': 'Your bag is empty',
    'cart.emptyDesc': 'Browse our seaweed collection and add your favourites.',
    'cart.startShopping': 'Start shopping',
    'cart.subtotal': 'Subtotal',
    'cart.shippingNote': 'Shipping & ferry fees are calculated at checkout based on your delivery location.',
    'cart.checkout': 'Checkout',
    'cart.clear': 'Clear bag',

    // checkout
    'checkout.title': 'Checkout',
    'checkout.sub': 'Confirm your details to place the order.',
    'checkout.empty': 'Your bag is empty. Add products first.',
    'checkout.name': 'Full name',
    'checkout.namePh': 'e.g. Amina Khamis',
    'checkout.phone': 'Phone number (WhatsApp)',
    'checkout.phonePh': 'e.g. +255 7XX XXX XXX',
    'checkout.delivery': 'Delivery method',
    'checkout.zanzibar': 'Zanzibar',
    'checkout.zanzibarDesc': 'Local delivery',
    'checkout.pickup': 'Pickup',
    'checkout.pickupDesc': 'Collect at shop',
    'checkout.mainland': 'Mainland',
    'checkout.mainlandDesc': 'Azam Ferry',
    'checkout.location': 'Location',
    'checkout.locationPh': 'e.g. Stone Town',
    'checkout.area': 'Area / region',
    'checkout.areaPh': 'e.g. Mbweni',
    'checkout.citySender': 'City (Zanzibar sender)',
    'checkout.mainlandDest': 'Mainland destination',
    'checkout.mainlandDestPh': 'e.g. Dar es Salaam — collect at Azam office',
    'checkout.notes': 'Notes (optional)',
    'checkout.notesPh': 'Any special instructions?',
    'checkout.promo': 'Promo code',
    'checkout.promoPh': 'Promo code',
    'checkout.apply': 'Apply',
    'checkout.tryCode': 'Try code MWANI10 for 10% off.',
    'checkout.subtotal': 'Subtotal',
    'checkout.shipping': 'Shipping',
    'checkout.freeOver': 'Free (over threshold)',
    'checkout.discount': 'Discount ({code})',
    'checkout.total': 'Total',
    'checkout.confirm': 'Confirm order',
    'checkout.noOnlinePay': 'No online payment here — you\'ll confirm payment via WhatsApp with the owner.',
    'checkout.confirmed': 'Order confirmed!',
    'checkout.thankYou': 'Thank you, {name}. Your order has been recorded.',
    'checkout.orderNumber': 'Order number',
    'checkout.sendWhatsapp': 'One last step — send your order to the owner',
    'checkout.sendWhatsappDesc': 'Tap below to open WhatsApp with your order details pre-filled. The owner will confirm payment and start processing.',
    'checkout.sendOrder': 'Send order via WhatsApp',
    'checkout.trySecondary': 'Try secondary number',
    'checkout.keepOrder': 'Keep your order number {n} to track progress on this site.',
    'checkout.continue': 'Continue browsing',

    // track
    'track.title': 'Track your order',
    'track.sub': 'Enter the order number you received at checkout to view its progress.',
    'track.orderNumber': 'Order number',
    'track.enterOrder': 'Enter your order number.',
    'track.notFound': 'Order not found. Please check your order number.',
    'track.items': 'Items',
    'track.statusHistory': 'Status history',
    'track.invoice': 'Download invoice / receipt',
    'track.etaPrefix': '',

    // my orders
    'myOrders.title': 'My Orders',
    'myOrders.sub': 'Enter the phone number you ordered with to see all your past orders & their progress.',
    'myOrders.phonePh': 'e.g. +255 712 345 678',
    'myOrders.enterPhone': 'Enter your phone number.',
    'myOrders.notFound': 'No orders found for this number.',
    'myOrders.checkNumber': 'Check the number and try again.',
    'myOrders.found': '{n} order(s) found',
    'myOrders.trackBtn': 'Track',

    // product modal
    'modal.benefits': 'Benefits',
    'modal.ingredients': 'Ingredients',
    'modal.howToUse': 'How to use',
    'modal.reviews': 'Customer reviews',
    'modal.noReviews': 'No reviews yet — be the first!',
    'modal.leaveReview': 'Leave a review',
    'modal.yourName': 'Your name',
    'modal.location': 'Location (e.g. Zanzibar)',
    'modal.rating': 'Rating:',
    'modal.shareExperience': 'Share your experience…',
    'modal.submitReview': 'Submit review',
    'modal.reviewNote': 'Reviews are shown after approval by the shop owner.',
    'modal.related': 'You may also like',
    'modal.addToBag': 'Add to bag',
    'modal.hoverZoom': 'Hover to zoom',
    'modal.shareWhatsapp': 'Ask about this on WhatsApp',
    'modal.copyLink': 'Copy product link',

    // common
    'common.loading': 'Loading…',
  },
  sw: {
    // announcement
    'ann.ferry': 'Usafirishaji wa bure kwenda mainland kwa order zaidi ya TSh 150,000 kupitia Azam Ferry',
    'ann.organic': 'Mwani wa asili 100% — unalimwa kwa uendelevu na wanawake wa Zanzibar',
    'ann.new': 'Mpya: Seaweed Face Mask sasa ipo — safisha na uibukeke ngozi',
    'ann.whatsapp': 'Agiza mtandaoni, thibitisha na lipia kwa urahisi kupitia WhatsApp',

    // nav
    'nav.products': 'Bidhaa',
    'nav.recipes': 'Mapishi',
    'nav.story': 'Hadithi Yetu',
    'nav.how': 'Jinsi Inavyofanya Kazi',
    'nav.reviews': 'Maoni',
    'nav.faq': 'Maswali',
    'nav.contact': 'Wasiliana',
    'nav.track': 'Fuata',
    'nav.myOrders': 'Order Zangu',
    'nav.bag': 'Fungua kikapu',
    'nav.menu': 'Menyu',
    'nav.admin': 'Admin',

    // side nav
    'side.title': 'Uelekeo',
    'side.currency': 'Sarafu',
    'side.language': 'Lugha',
    'side.section': 'Sehemu',
    'side.admin': 'Panel ya Admin',
    'side.close': 'Funga',

    // hero
    'hero.badge': 'Wakulima Hai Co-operative Society · Zanzibar',
    'hero.subtitle': 'Mwani wa asili 100% wa Zanzibar — unga, chai, vidonge, sabuni, mafuta na huduma za ngozi, uliovunwa kwa mkono na kutengenezwa kwa makini na wakulima wa Wakulima Hai.',
    'hero.explore': 'Tazama Bidhaa',
    'hero.ourStory': 'Hadithi Yetu',
    'hero.bestseller': 'Inauzwa zaidi',
    'hero.stats.organic': 'Asili',
    'hero.stats.products': 'Bidhaa',
    'hero.stats.loved': 'Hupendwa',
    'hero.keepGreen': 'Iweze Zanzibar kuwa kijani',
    'hero.farmersCoop': 'Shirika la wakulima',

    // featured
    'featured.eyebrow': 'Inauzwa zaidi',
    'featured.title': 'Inayopendwa na wateja wetu',
    'featured.sub': 'Bidhaa za mwani zinazopendwa zaidi — zinazoaminiwa Zanzibar na Tanzania mainland.',
    'product.addToBag': 'Ongeza kwenye kikapu',
    'product.outOfStock': 'Imeisha',
    'product.onlyLeft': 'Zimebaki {n} tu',

    // products section
    'products.eyebrowL': 'Mkusanyiko Wetu',
    'products.title': 'Tazama bidhaa zote za mwani',
    'products.sub': 'Kutoka vyakula vyenye virutubisho hadi huduma za asili za ngozi — mwani safi wa Zanzibar, uliotengenezwa kwa makini.',
    'products.search': 'Tafuta bidhaa…',
    'products.all': 'Bidhaa zote',
    'products.sort.newest': 'Mpya zaidi',
    'products.sort.priceAsc': 'Bei: Chini → Juu',
    'products.sort.priceDesc': 'Bei: Juu → Chini',
    'products.sort.rating': 'Inayopendwa zaidi',
    'products.reset': 'Futa chujio',
    'products.noResults': 'Hakuna bidhaa inayolingana na utafutaji wako.',
    'products.showing': 'Inaonyesha {n} kati ya {total} bidhaa',

    // recently viewed
    'recently.eyebrow': 'Endelea ulikuacha',
    'recently.title': 'Uliyotazama hivi karibuni',

    // recipes
    'recipes.eyebrow': 'Mapishi na Matumizi',
    'recipes.title': 'Fanya mwani kuwa sehemu ya',
    'recipes.sub': 'Mapishi rahisi na matumizi ya kila siku ya mwani wa asili wa Zanzibar — kutoka smoothie bowls hadi muda wa spa.',
    'recipes.all': 'Zote',
    'recipes.viewRecipe': 'Tazama mapishi',
    'recipes.popular': 'Inayopendwa',
    'recipes.ingredients': 'Viungo',
    'recipes.method': 'Mbinu',
    'recipes.tip': 'Kidokezo: nunua bidhaa za mwani zinazotumika katika mapishi hizi na zifanye sehemu ya maisha yako ya kila siku.',

    // story
    'story.eyebrow': 'Hadithi Yetu',
    'story.keepGreen': 'Iweze Zanzibar kuwa kijani.',
    'story.farmer': 'Wakulima Hai Co-operative Society',
    'story.sustainable': 'Kulimwa kwa uendelevu',
    'story.sustainableDesc': 'Kwa mkono, pwani ya Bahari Hindi ya Zanzibar.',
    'story.farmers': 'Wanawake wakulima',
    'story.organic': 'Asili',
    'story.products': 'Bidhaa',
    'story.islands': 'Visiwa vilivyofikiwa',
    'story.noAdditives': 'Hakuna viongezwi',
    'story.sunDried': 'Inakaukwa jua',
    'story.womenLed': 'Inayoongozwa na wanawake',
    'story.eco': 'Kifungashio cha mazingira',

    // how it works
    'how.eyebrow': 'Mchakato Rahisi',
    'how.title': 'Jinsi uagizaji unavyofanya kazi',
    'how.sub': 'Hatua nne rahisi kutoka baharini hadi mikononi mwako — lipia kwa urahisi kupitia WhatsApp.',
    'how.1.title': 'Tafuta na chagua',
    'how.1.desc': 'Tazama bidhaa zetu za mwani, soma maelezo na maoni, kisha ongeza unayopenda kwenye kikapu.',
    'how.2.title': 'Thibitisha order yako',
    'how.2.desc': 'Kagua kikapu chako, ongeza jina lako, simu na eneo la kujisilishia (Zanzibar au mainland), kisha thibitisha.',
    'how.3.title': 'Tuma kupitia WhatsApp',
    'how.3.desc': 'Bonyeza kitufe cha WhatsApp — ujumbe wa order ulioandikwa tayari unatumwa kwa mmiliki kuthibitisha malipo.',
    'how.4.title': 'Fuata maendeleo',
    'how.4.desc': 'Order za Zanzibar zinawasilishwa kimapacha; order za mainland zinapelekwa kupitia Azam Ferry. Fuata muda wowote na namba yako ya order.',

    // testimonials
    'testi.eyebrow': 'Upendo wa Wateja',
    'testi.title': 'Inayoaminiwa Zanzibar na zaidi',
    'testi.sub': 'Maneno halisi kutoka kwa watu walioufanya mwani kuwa sehemu ya maisha yao.',
    'testi.empty': 'Kuwa wa kwanza kuacha maoni!',

    // FAQ
    'faq.eyebrow': 'Maswali?',
    'faq.title': 'Kila unachohitaji kujua',
    'faq.sub': 'Hupati jibu unachotafuta? Wasiliana nasi kwenye WhatsApp — tunapenda swali zuri la mwani.',
    'faq.stillCurious': 'Bado unataka kujua zaidi?',
    'faq.chatTeam': 'Ongea na timu yetu moja kwa moja — kwa kawaida tunajibu ndani ya dakika.',
    'faq.askWhatsapp': 'Uliza kwenye WhatsApp',

    // contact
    'contact.eyebrow': 'Wasiliana nasi',
    'contact.title': 'Tungependa kusikia kutoka kwako',
    'contact.sub': 'Maswali kuhusu bidhaa, order nyingi, au usafirishaji? Wasiliana nasi moja kwa moja — tunajibu haraka.',
    'contact.callWhatsapp': 'Piga / WhatsApp',
    'contact.secondary': 'Namba nyingine',
    'contact.email': 'Barua pepe',
    'contact.website': 'Tovuti',
    'contact.address': 'Anwani',
    'contact.instagram': 'Instagram',
    'contact.shippingTitle': 'Usafirishaji kwenda mainland Tanzania',
    'contact.whatsappOrderTitle': 'Agiza kupitia WhatsApp',
    'contact.whatsappOrderDesc': 'Thibitisha order yako kwenye tovuti, kisha bonyeza kitufe cha WhatsApp kutuma maelezo ya order yako moja kwa moja kwa mmiliki.',
    'contact.chatNow': 'Ongea nasi sasa',
    'contact.trackOrder': 'Fuata order yangu',

    // footer
    'footer.newsletter': 'Newsletter',
    'footer.getOcean': 'Pata bahari nzuri kwenye inbox yako',
    'footer.newsletterDesc': 'Mapishi ya mwani, vidokezo vya afya, bidhaa mpya na ofa maalum. Hakuna spam — vitu vizuri tu.',
    'footer.privacy': 'Tunaheshimu faragha yako. Ondoa wakati wowote.',
    'footer.join': 'Jiunge',
    'footer.explore': 'Tafuta',
    'footer.allProducts': 'Bidhaa Zote',
    'footer.recipes': 'Mapishi na Matumizi',
    'footer.ourStory': 'Hadithi Yetu',
    'footer.howWorks': 'Jinsi Inavyofanya Kazi',
    'footer.reviews': 'Maoni',
    'footer.faq': 'Maswali',
    'footer.contact': 'Wasiliana',
    'footer.myOrders': 'Order Zangu',
    'footer.trackOrder': 'Fuata Order',
    'footer.byCoop': 'na Wakulima Hai Co-operative',
    'footer.copyright': 'Wakulima Hai Co-operative Society. Haki zote zimehifadhiwa.',
    'footer.admin': 'Panel ya Admin',

    // cart
    'cart.title': 'Kikapu Chako',
    'cart.empty': 'Kikapu chako kiko wazi.',
    'cart.items': '{n} bidhaa zimechaguliwa',
    'cart.emptyTitle': 'Kikapu chako kiko wazi',
    'cart.emptyDesc': 'Tazama mkusanyiko wetu wa mwani na uongeze unayopenda.',
    'cart.startShopping': 'Anza kununua',
    'cart.subtotal': 'Jumla',
    'cart.shippingNote': 'Ada za usafirishaji na ferry huhesabiwa kwenye checkout kulingana na eneo lako la kujisilishia.',
    'cart.checkout': 'Endelea kwenye checkout',
    'cart.clear': 'Futa kikapu',

    // checkout
    'checkout.title': 'Checkout',
    'checkout.sub': 'Thibitisha maelezo yako kuweka order.',
    'checkout.empty': 'Kikapu chako kiko wazi. Ongeza bidhaa kwanza.',
    'checkout.name': 'Jina kamili',
    'checkout.namePh': 'mf. Amina Khamis',
    'checkout.phone': 'Namba ya simu (WhatsApp)',
    'checkout.phonePh': 'mf. +255 7XX XXX XXX',
    'checkout.delivery': 'Njia ya kujisilishia',
    'checkout.zanzibar': 'Zanzibar',
    'checkout.zanzibarDesc': 'Masilishio ya karibu',
    'checkout.pickup': 'Kuchukua',
    'checkout.pickupDesc': 'Kusanya dukani',
    'checkout.mainland': 'Mainland',
    'checkout.mainlandDesc': 'Azam Ferry',
    'checkout.location': 'Eneo',
    'checkout.locationPh': 'mf. Stone Town',
    'checkout.area': 'Eneo / mkoa',
    'checkout.areaPh': 'mf. Mbweni',
    'checkout.citySender': 'Jiji (mtumiaji Zanzibar)',
    'checkout.mainlandDest': 'Lengo la mainland',
    'checkout.mainlandDestPh': 'mf. Dar es Salaam — kusanya ofisini pa Azam',
    'checkout.notes': 'Maelezo (hiari)',
    'checkout.notesPh': 'Maelezo maalum yoyote?',
    'checkout.promo': 'Koodi ya ofa',
    'checkout.promoPh': 'Koodi ya ofa',
    'checkout.apply': 'Tekeleza',
    'checkout.tryCode': 'Jaribu koodi MWANI10 kwa punguzo la 10%.',
    'checkout.subtotal': 'Jumla',
    'checkout.shipping': 'Usafirishaji',
    'checkout.freeOver': 'Bure (zaidi ya kiasi)',
    'checkout.discount': 'Punguzo ({code})',
    'checkout.total': 'Jumla',
    'checkout.confirm': 'Thibitisha order',
    'checkout.noOnlinePay': 'Hakuna malipo mtandaoni hapa — utathibitisha malipo kupitia WhatsApp na mmiliki.',
    'checkout.confirmed': 'Order imethibitishwa!',
    'checkout.thankYou': 'Asante, {name}. Order yako imerekodiwa.',
    'checkout.orderNumber': 'Namba ya order',
    'checkout.sendWhatsapp': 'Hatua ya mwisho — tuma order yako kwa mmiliki',
    'checkout.sendWhatsappDesc': 'Bonyeza hapa chini kufungua WhatsApp na maelezo ya order yako yamejazwa tayari. Mmiliki atathibitisha malipo na kuanza kuchakata.',
    'checkout.sendOrder': 'Tuma order kupitia WhatsApp',
    'checkout.trySecondary': 'Jaribu namba nyingine',
    'checkout.keepOrder': 'Hifadhi namba ya order {n} kufuata maendeleo kwenye tovuti hii.',
    'checkout.continue': 'Endelea kutazama',

    // track
    'track.title': 'Fuata order yako',
    'track.sub': 'Andika namba ya order uliyopokea kwenye checkout kuona maendeleo yake.',
    'track.orderNumber': 'Namba ya order',
    'track.enterOrder': 'Andika namba ya order yako.',
    'track.notFound': 'Order haijapatikana. Tafadhali kagua namba yako ya order.',
    'track.items': 'Bidhaa',
    'track.statusHistory': 'Historia ya hali',
    'track.invoice': 'Pakua ankawa / risiti',
    'track.etaPrefix': '',

    // my orders
    'myOrders.title': 'Order Zangu',
    'myOrders.sub': 'Andika namba ya simu uliyoiagizia nayo kuona order zako zote na maendeleo yake.',
    'myOrders.phonePh': 'mf. +255 712 345 678',
    'myOrders.enterPhone': 'Andika namba yako ya simu.',
    'myOrders.notFound': 'Hakuna order iliyopatikana kwa namba hii.',
    'myOrders.checkNumber': 'Kagua namba na ujaribu tena.',
    'myOrders.found': '{n} order zimepatikana',
    'myOrders.trackBtn': 'Fuata',

    // product modal
    'modal.benefits': 'Faida',
    'modal.ingredients': 'Viungo',
    'modal.howToUse': 'Jinsi ya kutumia',
    'modal.reviews': 'Maoni ya wateja',
    'modal.noReviews': 'Hakuna maoni bado — kuwa wa kwanza!',
    'modal.leaveReview': 'Acha maoni',
    'modal.yourName': 'Jina lako',
    'modal.location': 'Eneo (mf. Zanzibar)',
    'modal.rating': 'Alama:',
    'modal.shareExperience': 'Shiriki uzoefu wako…',
    'modal.submitReview': 'Tuma maoni',
    'modal.reviewNote': 'Maoni yanaonyeshwa baada ya kuidhiniwa na mmiliki wa duka.',
    'modal.related': 'Huenda ukapenda',
    'modal.addToBag': 'Ongeza kwenye kikapu',
    'modal.hoverZoom': 'Sogeza kushusha kupanua',
    'modal.shareWhatsapp': 'Uliza kuhusu bidhaa hii kwenye WhatsApp',
    'modal.copyLink': 'Nakili kiungo cha bidhaa',

    // common
    'common.loading': 'Inapakia…',
  },
}

type I18nCtx = {
  lang: Lang
  setLang: (l: Lang) => void
  t: (key: string, vars?: Record<string, string | number>) => string
}

const Ctx = createContext<I18nCtx>({
  lang: 'en',
  setLang: () => {},
  t: (k) => k,
})

/** The built-in wording for a key (no admin overrides). Used by the admin editor. */
export function builtinString(lang: Lang, key: string): string {
  for (const L of LAYERS) { const v = L[lang][key]; if (v !== undefined) return v }
  return dict[lang][key] ?? ''
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>('en')

  useEffect(() => {
    const saved = (typeof localStorage !== 'undefined' && localStorage.getItem('mwani-lang')) as Lang | null
    if (saved === 'en' || saved === 'sw') setLangState(saved)
  }, [])

  useEffect(() => { document.documentElement.lang = lang }, [lang])

  const setLang = (l: Lang) => {
    setLangState(l)
    try { localStorage.setItem('mwani-lang', l) } catch {}
  }

  const over = useContent((c) => (lang === 'sw' ? c.sw : c.en))
  const overEn = useContent((c) => c.en)
  const t = (key: string, vars?: Record<string, string | number>) => {
    let s: string | undefined = over[key] || undefined
    if (s === undefined) for (const L of LAYERS) { s = L[lang][key]; if (s !== undefined) break }
    s = s ?? dict[lang][key]
    if (s === undefined) s = overEn[key] || undefined
    if (s === undefined) for (const L of LAYERS) { s = L.en[key]; if (s !== undefined) break }
    s = s ?? dict.en[key] ?? key
    if (vars) {
      for (const [k, v] of Object.entries(vars)) {
        s = s.replaceAll(`{${k}}`, String(v))
      }
    }
    return s
  }

  return <Ctx.Provider value={{ lang, setLang, t }}>{children}</Ctx.Provider>
}

export function useI18n() {
  return useContext(Ctx)
}
