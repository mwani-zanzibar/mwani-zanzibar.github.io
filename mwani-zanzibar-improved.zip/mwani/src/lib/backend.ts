// Storage backend contract. The business logic in data.ts only ever talks
// to one of these, so Firestore and the in-browser demo behave identically.

export type Row = { id: string } & Record<string, unknown>
export type Eq = [field: string, value: unknown]

export type AdminSession = { authenticated: boolean; admin?: { id: string; username: string; name: string } }

export interface Backend {
  kind: 'firebase' | 'demo'
  list(col: string): Promise<Row[]>
  where(col: string, filters: Eq[]): Promise<Row[]>
  get(col: string, id: string): Promise<Row | null>
  add(col: string, data: Record<string, unknown>): Promise<string>
  set(col: string, id: string, data: Record<string, unknown>): Promise<void>
  update(col: string, id: string, data: Record<string, unknown>): Promise<void>
  remove(col: string, id: string): Promise<void>
  login(email: string, password: string): Promise<AdminSession>
  logout(): Promise<void>
  session(): Promise<AdminSession>
}
