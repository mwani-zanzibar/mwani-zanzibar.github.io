import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type WishItem = {
  id: string
  name: string
  price: number
  image: string
  category: string
  unit: string
}

type State = {
  items: WishItem[]
  toggle: (item: WishItem) => void
  has: (id: string) => boolean
  remove: (id: string) => void
  clear: () => void
  /** Refresh saved items from the live catalogue (names, prices, photos); drop removed products. */
  sync: (products: { id: string; name: string; price: number; image: string; category: string; unit: string; active: boolean }[]) => void
  open: boolean
  setOpen: (v: boolean) => void
}

export const useWishlist = create<State>()(
  persist(
    (set, get) => ({
      items: [],
      open: false,
      toggle: (item) =>
        set((s) => {
          const exists = s.items.some((i) => i.id === item.id)
          return {
            items: exists
              ? s.items.filter((i) => i.id !== item.id)
              : [...s.items, item],
          }
        }),
      has: (id) => get().items.some((i) => i.id === id),
      remove: (id) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),
      clear: () => set({ items: [] }),
      sync: (products) => set((s) => ({
        items: s.items.flatMap((i) => {
          const p = products.find((x) => x.id === i.id && x.active !== false)
          return p ? [{ ...i, name: p.name, price: p.price, image: p.image, category: p.category, unit: p.unit }] : []
        }),
      })),
      setOpen: (v) => set({ open: v }),
    }),
    { name: 'mwani-wishlist' }
  )
)
