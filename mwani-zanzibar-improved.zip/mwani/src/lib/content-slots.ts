// Every editable image on the storefront. The admin "Site content" page lists
// these; components read them with useImg(id, default).
export type ImageSlot = { id: string; group: string; label: string; def: string; hint?: string }

export const IMAGE_SLOTS: ImageSlot[] = [
  { id: 'hero.powder', group: 'Hero and spotlight', label: 'Seaweed Powder scene', def: '/products/powder-cut.webp', hint: 'Transparent background (PNG or WebP) blends best.' },
  { id: 'hero.tea', group: 'Hero and spotlight', label: 'Seaweed Tea scene', def: '/products/tea-cut.webp', hint: 'Transparent background (PNG or WebP) blends best.' },
  { id: 'hero.powderThumb', group: 'Hero and spotlight', label: 'Powder small icon', def: '/products/powder-pouch.webp', hint: 'Shown in round buttons, so a pouch on its own works best.' },
  { id: 'hero.teaThumb', group: 'Hero and spotlight', label: 'Tea small icon', def: '/products/tea-pouch.webp', hint: 'Shown in round buttons, so a pouch on its own works best.' },
  { id: 'ranges.food', group: 'Shop by range', label: 'Food & Beverage tile', def: '/products/seaweed-jelly.webp' },
  { id: 'ranges.skin', group: 'Shop by range', label: 'Skin Care tile', def: '/products/scrub-powder.webp' },
  { id: 'ranges.hair', group: 'Shop by range', label: 'Hair Care tile', def: '/products/hair-oil.webp' },
  { id: 'ranges.wellness', group: 'Shop by range', label: 'Health & Wellness tile', def: '/products/capsules.webp' },
  { id: 'story.2', group: 'Our farmers', label: 'Step 2 photo', def: '/products/dried-seaweed.webp' },
  { id: 'story.3', group: 'Our farmers', label: 'Step 3 photo', def: '/products/powder.webp' },
  { id: 'story.4a', group: 'Our farmers', label: 'Step 4 photo (left)', def: '/products/tea.webp' },
  { id: 'story.4b', group: 'Our farmers', label: 'Step 4 photo (right)', def: '/products/soaps.webp' },
  { id: 'cta.left', group: 'Closing band', label: 'Left product', def: '/products/powder-cut.webp', hint: 'Transparent background works best.' },
  { id: 'cta.right', group: 'Closing band', label: 'Right product', def: '/products/tea-cut.webp', hint: 'Transparent background works best.' },
  { id: 'brand.mark', group: 'Brand', label: 'Logo mark (top bar, menu)', def: '/brand/mwani-mark.png' },
  { id: 'brand.footer', group: 'Brand', label: 'Footer logo (light, for the dark footer)', def: '/brand/mwani-lockup-light.png' },
  { id: 'brand.coop', group: 'Brand', label: 'Co-operative logo', def: '/wakulima-hai-logo.png' },
]

export const slotDefault = (id: string) => IMAGE_SLOTS.find((s) => s.id === id)?.def ?? ''
