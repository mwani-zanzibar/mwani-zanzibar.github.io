import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type CompareItem = {
  id: string
  name: string
  price: number
  unit: string
  category: string
  image: string
  rating: number
  reviewCount: number
  stock: number
  benefits: string[]
  ingredients: string[]
  howToUse: string
}

type State = {
  items: CompareItem[]
  toggle: (item: CompareItem) => void
  has: (id: string) => boolean
  remove: (id: string) => void
  clear: () => void
  open: boolean
  setOpen: (v: boolean) => void
}

const MAX_COMPARE = 4

export const useCompare = create<State>()(
  persist(
    (set, get) => ({
      items: [],
      open: false,
      toggle: (item) =>
        set((s) => {
          const exists = s.items.some((i) => i.id === item.id)
          if (exists) {
            return { items: s.items.filter((i) => i.id !== item.id) }
          }
          if (s.items.length >= MAX_COMPARE) {
            return { items: [...s.items.slice(1), item] } // drop oldest
          }
          return { items: [...s.items, item] }
        }),
      has: (id) => get().items.some((i) => i.id === id),
      remove: (id) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),
      clear: () => set({ items: [] }),
      setOpen: (v) => set({ open: v }),
    }),
    { name: 'mwani-compare' }
  )
)

export const COMPARE_MAX = MAX_COMPARE
