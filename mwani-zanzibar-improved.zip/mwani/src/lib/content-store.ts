import { create } from 'zustand'
import type { SiteContent } from './types'

// Admin-edited site text and images. Loaded with the settings; the i18n layer
// and useImg() read from here first, then fall back to the built-in defaults.
type ContentState = SiteContent & { setContent: (c: SiteContent | undefined) => void }

export const EMPTY_CONTENT: SiteContent = { en: {}, sw: {}, img: {} }

export const useContent = create<ContentState>()((set) => ({
  ...EMPTY_CONTENT,
  setContent: (c) => set({ en: c?.en ?? {}, sw: c?.sw ?? {}, img: c?.img ?? {} }),
}))

/** An editable image slot: the admin's image if set, otherwise the default. */
export function useImg(slot: string, fallback: string): string {
  const v = useContent((s) => s.img[slot])
  return v && v.trim() ? v : fallback
}
