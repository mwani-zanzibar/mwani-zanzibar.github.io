'use client'

import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { SplitText } from 'gsap/SplitText'
import { useGSAP } from '@gsap/react'

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger, SplitText, useGSAP)
  ScrollTrigger.config({ ignoreMobileResize: true })
  gsap.defaults({ ease: 'power3.out', duration: 0.7 })
}

export { gsap, ScrollTrigger, SplitText, useGSAP }
