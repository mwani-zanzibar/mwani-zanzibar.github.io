import { asset } from './asset'

// next/image loader for static hosting: no resizing service, just the right path.
export default function imageLoader({ src, width }: { src: string; width: number }) {
  const url = asset(src)
  if (url.startsWith('data:') || url.startsWith('blob:')) return url
  return `${url}${url.includes('?') ? '&' : '?'}w=${width}`
}
