// Catalogue seed data. The admin panel's "Load starting catalogue" button writes it
// to a new Firestore database, and the in-browser demo backend uses it when Firebase
// has not been configured yet (local preview, design reviews).

import type { ApiSettings } from './types'

export type SeedProduct = {
  name: string; tagline: string; description: string; price: number; unit: string
  category: string; image: string; gallery: string[]; benefits: string[]; ingredients: string[]
  howToUse: string; stock: number; featured?: boolean; active: boolean
  rating: number; reviewCount: number; lowStockThreshold: number
}

export type SeedRecipe = {
  title: string; excerpt: string; content: string; image: string; category: string
  prepTime: string; servings: string; ingredients: string[]; steps: string[]
  featured?: boolean; active: boolean
}

export type SeedPromo = {
  code: string; description: string; type: 'percentage' | 'fixed'; value: number
  minOrder: number; maxDiscount: number; usageLimit: number; usedCount: number; active: boolean
}

export const DEFAULT_SETTINGS: ApiSettings = {
  whatsappPrimary: '+255774870703',
  whatsappSecondary: '+255773939262',
  email: 'Info@Wakulimahai.org',
  website: 'www.wakulimahai.org',
  address: 'P.O.Box 3943, Mbwenibotanga, Zanzibar',
  phonePrimary: '+255 774 870 703',
  phoneSecondary: '+255 773 939 262',
  instagram: 'zanzibar_sea_weed_products',
  ferryInfo: 'Orders to mainland Tanzania travel as Azam Marine parcels. You collect yours at the nearest Azam Marine office.',
  whatsappMessageTemplate:
    'Habari! Ningependa kuweka order yangu ya Mwani Zanzibar Seaweed.\n\nOrder No: {orderNumber}\nName: {name}\nLocation: {location}\nDelivery: {channel}\n\nOrder Items:\n{items}\n\nTotal: {total}\n\nTafadhali thibitisha order yangu na niambie jinsi ya kulipa.',
  shopName: 'Mwani Zanzibar Seaweed',
  tagline: 'Seaweed from the Zanzibar lagoons, farmed by women of Wakulima Hai.',
  aboutText:
    'Mwani Zanzibar Seaweed is the product line of Wakulima Hai Co-operative Society, a farmers co-operative in Zanzibar. Members grow seaweed on lines in the shallow lagoons, dry it in the sun, and turn it into food, wellness and skin care products here on the island.',
  heroTitle: 'Seaweed from our lagoons, made into food and care.',
  heroSubtitle: 'Powder, tea, capsules, soaps and oils, grown and prepared by the women farmers of Wakulima Hai in Zanzibar.',
  shippingFeeMainland: 15000,
  freeShippingThreshold: 150000,
  usdRate: 2680,
}

// Every product below matches a real product photo in /public/products.
// Cards, the product view and the bag all show these real photographs.
const photo = (n: string) => `/products/${n}.webp`
const img = photo
const base = { active: true, rating: 0, reviewCount: 0, lowStockThreshold: 8 }

export const SEED_PRODUCTS: SeedProduct[] = [
  { ...base, name: 'Zanzibar Seaweed Powder', tagline: '100% organic mwani, sun-dried and finely milled',
    description: 'Seaweed (mwani) grown on lines in the Zanzibar lagoons, sun-dried and milled into a fine powder. It has a mild taste, so it disappears into smoothies, juice, soups, porridge and baking.',
    price: 25000, unit: '160g pouch', category: 'Food & Beverage', image: img('powder'), gallery: [photo('powder-capsules')],
    benefits: ['Rich in iodine and minerals', 'High in dietary fibre', 'Supports thyroid health', 'Easy to add to any meal'],
    ingredients: ['100% organic Zanzibar seaweed (mwani)'],
    howToUse: 'Stir 1 teaspoon a day into smoothies, juice, soups, porridge or baking.', stock: 80, featured: true },
  { ...base, name: 'Zanzibar Seaweed Tea', tagline: 'Seaweed with warming Zanzibar spices',
    description: 'A spiced tea blend of seaweed with cloves, ginger, cinnamon, black pepper and black turmeric. Brew it strong on its own, or add milk and honey.',
    price: 18000, unit: '100g pouch', category: 'Food & Beverage', image: img('tea'), gallery: [],
    benefits: ['Supports weight management', 'Natural energy', 'Aids digestion', 'Warming spices'],
    ingredients: ['Seaweed', 'Cloves', 'Ginger', 'Cinnamon', 'Black pepper', 'Black turmeric'],
    howToUse: 'Steep 1 teaspoon in a cup of hot water for 5 to 7 minutes, then strain.', stock: 65, featured: true },
  { ...base, name: 'Zanzibar Seaweed Capsules', tagline: 'Your daily seaweed in one capsule',
    description: 'Our organic seaweed powder in capsules, for the days you have no time to cook with it. 60 capsules in a jar.',
    price: 35000, unit: '60 capsules', category: 'Health & Wellness', image: img('capsules'), gallery: [photo('powder-capsules')],
    benefits: ['Rich in iodine', 'Supports thyroid function', 'Convenient daily dose', 'No taste'],
    ingredients: ['100% organic seaweed powder', 'Capsule shell'],
    howToUse: 'Take 1 to 2 capsules a day with water, with a meal.', stock: 90, featured: true },
  { ...base, name: 'Zanzibar Dried Seaweed', tagline: 'Whole sun-dried mwani, 500 g',
    description: 'Whole seaweed strands, cleaned and sun-dried by the farmers. Soak and blend them into your own seaweed gel, or cook them in soups and salads.',
    price: 30000, unit: '500g pouch', category: 'Food & Beverage', image: img('dried-seaweed'), gallery: [],
    benefits: ['Whole and unprocessed', 'Makes a lot of gel', 'Rich in minerals and fibre'],
    ingredients: ['100% organic dried seaweed (mwani)'],
    howToUse: 'Rinse well and soak in clean water overnight. Blend with fresh water into a gel, or add to cooking.', stock: 50 },
  { ...base, name: 'Zanzibar Seaweed Jelly', tagline: 'Ready-made seaweed gel',
    description: 'Seaweed soaked and blended into a smooth gel, ready to use. Add a spoonful to smoothies, juice, porridge or tea.',
    price: 15000, unit: 'Tub', category: 'Food & Beverage', image: img('seaweed-jelly'), gallery: [],
    benefits: ['Ready to use', 'Rich in minerals', 'Blends into any drink'],
    ingredients: ['Seaweed', 'Water'],
    howToUse: 'Add 1 to 2 tablespoons a day to drinks or food. Keep in the fridge after opening.', stock: 40 },
  { ...base, name: 'Seaweed Petroleum Jelly', tagline: 'Seaweed, olive, aloe vera and rosemary',
    description: 'A rich jelly for dry skin, lips, heels and elbows, made with seaweed, olive oil, aloe vera, rosemary, lemongrass and Acalypha indica.',
    price: 15000, unit: '50g tin', category: 'Skin Care', image: img('petroleum-jelly'), gallery: [],
    benefits: ['Deeply moisturising', 'Soothes dry and cracked skin', 'Protects the skin barrier'],
    ingredients: ['Seaweed', 'Olive oil', 'Aloe vera', 'Rosemary', 'Lemongrass', 'Acalypha indica'],
    howToUse: 'Apply a thin layer to dry skin, lips, heels or elbows as needed.', stock: 120, featured: true },
  { ...base, name: 'Seaweed Scrub Powder', tagline: 'Seaweed, turmeric, sandalwood and rice',
    description: 'A dry face and body scrub. Mix it with water or honey into a paste to polish and brighten the skin.',
    price: 15000, unit: 'Jar', category: 'Skin Care', image: img('scrub-powder'), gallery: [],
    benefits: ['Gently exfoliates', 'Brightens dull skin', 'Leaves skin soft'],
    ingredients: ['Seaweed', 'Turmeric', 'Sandalwood', 'Rice'],
    howToUse: 'Mix 1 teaspoon with a little water or honey into a paste. Massage onto damp skin for a minute, then rinse. Use 2 to 3 times a week.', stock: 60, featured: true },
  { ...base, name: 'Seaweed Rub', tagline: 'A rich balm in a small glass jar',
    description: 'A seaweed balm to massage into the skin. Small enough to carry in a bag.',
    price: 12000, unit: 'Small jar', category: 'Skin Care', image: img('seaweed-rub'), gallery: [],
    benefits: ['Nourishes the skin', 'Easy to carry'],
    ingredients: ['Seaweed'],
    howToUse: 'Warm a little between your fingers and massage into the skin.', stock: 60 },
  { ...base, name: 'Seaweed Hair Oil', tagline: 'Scalp and hair oil in a pump bottle',
    description: 'A light hair oil made with seaweed, for the scalp and the ends of your hair.',
    price: 22000, unit: 'Pump bottle', category: 'Hair Care', image: img('hair-oil'), gallery: [],
    benefits: ['Nourishes the scalp', 'Reduces breakage', 'Adds shine'],
    ingredients: ['Seaweed', 'Natural oils'],
    howToUse: 'Massage a few pumps into the scalp and hair. Leave for 30 minutes or overnight, then wash.', stock: 70, featured: true },
  { ...base, name: 'Seaweed Hair Food', tagline: 'Conditioning hair cream, 200 ml',
    description: 'A creamy hair food made with seaweed, for soft and moisturised hair between wash days.',
    price: 25000, unit: '200ml jar', category: 'Hair Care', image: img('hair-food'), gallery: [],
    benefits: ['Deep conditioning', 'Tames frizz', 'Softens and defines'],
    ingredients: ['Seaweed', 'Natural butters and oils'],
    howToUse: 'Apply a small amount to clean, damp hair and style as usual.', stock: 60, featured: true },
  { ...base, name: 'Seaweed Soap', tagline: 'Sabuni ya Mwani, the original bar',
    description: 'Handmade soap with Zanzibar seaweed, for face and body.',
    price: 8000, unit: 'Bar', category: 'Skin Care', image: img('soap-mwani'), gallery: [photo('soaps')],
    benefits: ['Cleanses gently', 'Nourishes the skin'],
    ingredients: ['Seaweed', 'Soap base'],
    howToUse: 'Lather with water, wash face and body, then rinse.', stock: 150, featured: true },
  { ...base, name: 'Clove Seaweed Soap', tagline: 'Sabuni ya Karafuu, with Zanzibar cloves',
    description: 'Handmade seaweed soap with cloves, the spice Zanzibar is famous for.',
    price: 8000, unit: 'Bar', category: 'Skin Care', image: img('soap-karafuu'), gallery: [photo('soaps')],
    benefits: ['Deep cleansing', 'Helps with spots', 'Warm clove scent'],
    ingredients: ['Seaweed', 'Cloves', 'Soap base'],
    howToUse: 'Lather with water, wash face and body, then rinse.', stock: 120 },
  { ...base, name: 'Turmeric Seaweed Soap', tagline: 'Sabuni ya Manjano, with turmeric',
    description: 'Handmade seaweed soap with turmeric for a brighter, even-looking skin.',
    price: 8000, unit: 'Bar', category: 'Skin Care', image: img('soap-manjano'), gallery: [photo('soaps')],
    benefits: ['Brightens the skin', 'Evens skin tone'],
    ingredients: ['Seaweed', 'Turmeric', 'Soap base'],
    howToUse: 'Lather with water, wash face and body, then rinse.', stock: 120 },
  { ...base, name: 'Lemon Seaweed Soap', tagline: 'Sabuni ya Limau, with lemon',
    description: 'Handmade seaweed soap with lemon, fresh and clean.',
    price: 8000, unit: 'Bar', category: 'Skin Care', image: img('soap-limau'), gallery: [photo('soaps')],
    benefits: ['Fresh citrus scent', 'Clears oily skin'],
    ingredients: ['Seaweed', 'Lemon', 'Soap base'],
    howToUse: 'Lather with water, wash face and body, then rinse.', stock: 120 },
  { ...base, name: 'Eucalyptus Seaweed Soap', tagline: 'Sabuni ya Mkaratusi, with eucalyptus',
    description: 'Handmade seaweed soap with eucalyptus, cooling and refreshing.',
    price: 8000, unit: 'Bar', category: 'Skin Care', image: img('soap-mkaratusi'), gallery: [photo('soaps')],
    benefits: ['Cooling and refreshing', 'Clean herbal scent'],
    ingredients: ['Seaweed', 'Eucalyptus', 'Soap base'],
    howToUse: 'Lather with water, wash face and body, then rinse.', stock: 120 },
]
export const SEED_RECIPES: SeedRecipe[] = [
  { title: 'Seaweed Superfood Smoothie Bowl', excerpt: 'A nourishing breakfast bowl with seaweed powder and tropical fruit.', content: 'Start your day the Zanzibari way.', image: photo('powder'), category: 'Cooking', prepTime: '8 min', servings: '1 bowl', ingredients: ['1 tsp seaweed powder', '1 ripe banana', '1/2 cup frozen mango', '1/2 cup coconut milk', '1 tbsp honey'], steps: ['Blend banana, mango, coconut milk, honey and seaweed powder until smooth.', 'Pour into a bowl.', 'Top with fruit and enjoy.'], featured: true, active: true },
  { title: 'Spiced Seaweed Tea Latte', excerpt: 'A warming latte with cloves and ginger.', content: 'Turn our seaweed tea into a creamy latte.', image: photo('tea'), category: 'Beverage', prepTime: '10 min', servings: '1 cup', ingredients: ['1 tsp seaweed tea', '1 cup hot water', '1/4 cup warm milk', '1 tsp honey'], steps: ['Steep the seaweed tea in hot water for 6 minutes.', 'Strain into a mug.', 'Froth warm milk and pour over the tea.', 'Drizzle honey and serve.'], featured: true, active: true },
  { title: 'Homemade Seaweed Gel', excerpt: 'Turn a pouch of dried mwani into a week of gel.', content: 'Dried seaweed swells as it soaks. Blended with fresh water it becomes a smooth gel you can add to any drink.', image: photo('dried-seaweed'), category: 'Cooking', prepTime: '12 hrs soak', servings: '1 jar', ingredients: ['1 handful dried seaweed', 'Clean water for soaking', '1 cup fresh water', '1 lime (optional)'], steps: ['Rinse the dried seaweed well to remove sand and salt.', 'Soak it in clean water for 12 hours or overnight.', 'Drain, then blend with a cup of fresh water until smooth.', 'Pour into a clean jar and keep in the fridge for up to 2 weeks.'], featured: true, active: true },
  { title: 'Daily Seaweed Wellness Routine', excerpt: 'A 30-second morning habit with capsules.', content: 'Two capsules with breakfast and a glass of water.', image: photo('capsules'), category: 'Wellness', prepTime: '30 sec', servings: '1 daily dose', ingredients: ['2 seaweed capsules', '1 glass of water'], steps: ['Take 2 capsules with a meal.', 'Drink a full glass of water.', 'Use daily for best results.'], featured: true, active: true },
  { title: 'Weekly Seaweed Face Scrub', excerpt: 'Seaweed, turmeric and sandalwood for a brighter face.', content: 'Mix our scrub powder into a paste once or twice a week.', image: photo('scrub-powder'), category: 'Skincare', prepTime: '5 min', servings: '1 treatment', ingredients: ['1 tsp seaweed scrub powder', '1 tsp honey or water'], steps: ['Mix the scrub powder with honey or water into a paste.', 'Massage onto damp skin in small circles for a minute.', 'Rinse with warm water and pat dry.', 'Finish with a little petroleum jelly on dry spots.'], active: true },
  { title: 'Seaweed Soap Routine', excerpt: 'Pick a scent and wash morning and night.', content: 'Our handmade seaweed soaps come in five scents: seaweed, clove, turmeric, lemon and eucalyptus.', image: photo('soaps'), category: 'Skincare', prepTime: '3 min', servings: '1 wash', ingredients: ['1 seaweed soap bar', 'Warm water'], steps: ['Lather the soap with warm water.', 'Wash face and body in circular motions.', 'Rinse thoroughly and pat dry.'], active: true },
]
export const SEED_PROMOS: SeedPromo[] = [
  { code: 'MWANI10', description: '10% off your first order', type: 'percentage', value: 10, minOrder: 0, maxDiscount: 0, usageLimit: 0, usedCount: 0, active: true },
  { code: 'FREESHIP', description: 'TSh 15,000 off (covers mainland shipping)', type: 'fixed', value: 15000, minOrder: 50000, maxDiscount: 0, usageLimit: 0, usedCount: 0, active: true },
  { code: 'OCEAN20', description: '20% off orders over TSh 100,000', type: 'percentage', value: 20, minOrder: 100000, maxDiscount: 50000, usageLimit: 0, usedCount: 0, active: true },
]