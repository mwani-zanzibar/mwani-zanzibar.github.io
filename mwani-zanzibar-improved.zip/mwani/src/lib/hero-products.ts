import { useImg } from './content-store'
import type { ApiProduct } from './types'

export type HeroKey = 'powder' | 'tea'
// The two stars. Matched by name so it works for demo and database ids.
export function pickHeroes(products: ApiProduct[]): Record<HeroKey, ApiProduct | undefined> {
  const find = (re: RegExp) => products.find((p) => re.test(p.name))
  return { powder: find(/seaweed powder/i) ?? find(/powder/i), tea: find(/seaweed tea/i) ?? find(/\btea\b/i) }
}
// Real product photography, background removed. The full scene (pouch with
// strands and bowl, pouch with cup) for large stages; the pouch alone for
// small round thumbnails.
export const HERO_CUT: Record<HeroKey, string> = { powder: '/products/powder-cut.webp', tea: '/products/tea-cut.webp' }
export const HERO_POUCH: Record<HeroKey, string> = { powder: '/products/powder-pouch.webp', tea: '/products/tea-pouch.webp' }
export const HERO_PHOTO: Record<HeroKey, string> = { powder: '/products/powder.webp', tea: '/products/tea.webp' }

/** Hero images, with the admin's replacements applied. */
export function useHeroImages() {
  const cut = { powder: useImg('hero.powder', HERO_CUT.powder), tea: useImg('hero.tea', HERO_CUT.tea) }
  const pouch = { powder: useImg('hero.powderThumb', HERO_POUCH.powder), tea: useImg('hero.teaThumb', HERO_POUCH.tea) }
  return { cut, pouch }
}
