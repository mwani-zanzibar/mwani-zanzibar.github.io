import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type Currency = 'TZS' | 'USD'

type State = {
  currency: Currency
  rate: number // TSh per 1 USD
  setCurrency: (c: Currency) => void
  setRate: (r: number) => void
}

// Approximate rate; admin can override in settings (stored separately, but we keep a default here).
const DEFAULT_RATE = 2680

export const useCurrency = create<State>()(
  persist(
    (set) => ({
      currency: 'TZS',
      rate: DEFAULT_RATE,
      setCurrency: (c) => set({ currency: c }),
      setRate: (r) => set({ rate: r }),
    }),
    { name: 'mwani-currency' }
  )
)

export function formatMoney(amountTSh: number, currency: Currency, rate: number): string {
  if (currency === 'USD') {
    const usd = amountTSh / rate
    return '$' + new Intl.NumberFormat('en-US', { maximumFractionDigits: usd < 10 ? 2 : 0, minimumFractionDigits: usd < 10 ? 2 : 0 }).format(usd)
  }
  return 'TSh ' + new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.round(amountTSh))
}
