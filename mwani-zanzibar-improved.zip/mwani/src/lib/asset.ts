// Prefix site-relative asset paths with the deploy base path, so images keep
// working on GitHub Pages project sites (username.github.io/<repo>/).
// Set NEXT_PUBLIC_BASE_PATH=/<repo> when building for that host.

export const BASE_PATH = (process.env.NEXT_PUBLIC_BASE_PATH || '').replace(/\/$/, '')

export function asset(src: string | undefined | null): string {
  if (!src) return ''
  if (!src.startsWith('/') || src.startsWith('//')) return src
  if (BASE_PATH && src.startsWith(BASE_PATH + '/')) return src
  return BASE_PATH + src
}
