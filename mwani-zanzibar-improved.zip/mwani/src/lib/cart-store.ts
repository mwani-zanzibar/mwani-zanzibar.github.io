import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type CartItem = {
  productId: string
  name: string
  price: number
  qty: number
  unit: string
  image: string
  stock: number
}

type CartState = {
  items: CartItem[]
  add: (item: Omit<CartItem, 'qty'>, qty?: number) => void
  remove: (productId: string) => void
  setQty: (productId: string, qty: number) => void
  clear: () => void
  sync: (products: { id: string; name: string; price: number; unit: string; image: string; stock: number; active: boolean }[]) => void
  open: boolean
  setOpen: (v: boolean) => void
}

export const useCart = create<CartState>()(
  persist(
    (set) => ({
      items: [],
      open: false,
      add: (item, qty = 1) =>
        set((s) => {
          const existing = s.items.find((i) => i.productId === item.productId)
          if (existing) {
            return {
              items: s.items.map((i) =>
                i.productId === item.productId
                  ? { ...i, qty: Math.min(i.qty + qty, item.stock || 99) }
                  : i
              ),
            }
          }
          return { items: [...s.items, { ...item, qty }] }
        }),
      remove: (productId) => set((s) => ({ items: s.items.filter((i) => i.productId !== productId) })),
      setQty: (productId, qty) =>
        set((s) => ({
          items: s.items
            .map((i) => (i.productId === productId ? { ...i, qty: Math.max(0, Math.min(qty, i.stock || 99)) } : i))
            .filter((i) => i.qty > 0),
        })),
      clear: () => set({ items: [] }),
      sync: (products) =>
        set((s) => ({
          items: s.items
            .map((i) => {
              const p = products.find((x) => x.id === i.productId && x.active !== false)
              if (!p || p.stock <= 0) return null
              return { ...i, name: p.name, price: p.price, unit: p.unit, image: p.image, stock: p.stock, qty: Math.min(i.qty, p.stock) }
            })
            .filter((i): i is CartItem => !!i),
        })),
      setOpen: (v) => set({ open: v }),
    }),
    { name: 'mwani-cart' }
  )
)
