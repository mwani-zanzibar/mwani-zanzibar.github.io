export function formatTZS(amount: number): string {
  return 'TSh ' + new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(Math.round(amount))
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

export function orderNumberGen(): string {
  const ts = Date.now().toString(36).toUpperCase().slice(-6)
  const rand = Math.random().toString(36).toUpperCase().slice(2, 6)
  return `MWS-${ts}${rand}`
}

export function normalizePhone(phone: string): string {
  // Remove all non-digit except leading +
  let p = phone.trim()
  const hasPlus = p.startsWith('+')
  p = p.replace(/[^\d]/g, '')
  if (!hasPlus && p.startsWith('255')) {
    return '+' + p
  }
  if (!hasPlus && p.startsWith('0')) {
    return '+255' + p.slice(1)
  }
  if (!hasPlus) {
    return '+' + p
  }
  return p
}

export function whatsappLink(phone: string, message: string): string {
  const digits = phone.replace(/[^\d]/g, '')
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`
}

export function statusLabel(status: string): string {
  const map: Record<string, string> = {
    pending: 'Pending',
    confirmed: 'Confirmed',
    processing: 'Processing',
    shipped: 'Shipped via Azam',
    ready_for_pickup: 'Ready for Pickup',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
  }
  return map[status] || status
}

export function statusOrder(): string[] {
  return ['pending', 'confirmed', 'processing', 'shipped', 'ready_for_pickup', 'delivered']
}

export function toCSV(headers: string[], rows: (string | number)[][]): string {
  const esc = (v: string | number) => {
    const s = String(v ?? '')
    if (s.includes(',') || s.includes('"') || s.includes('\n')) return `"${s.replace(/"/g, '""')}"`
    return s
  }
  return [headers.map(esc).join(','), ...rows.map((r) => r.map(esc).join(','))].join('\n')
}

export function downloadCSV(filename: string, csv: string) {
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// Estimate delivery ETA based on delivery channel + current status.
// Returns { label, tone } where tone is 'green'|'amber'|'blue'|'muted'.
export function deliveryEta(channel: string, status: string, createdAt: string): { label: string; tone: string } | null {
  if (status === 'delivered') return { label: 'Delivered', tone: 'green' }
  if (status === 'cancelled') return { label: 'Cancelled', tone: 'muted' }
  if (status === 'ready_for_pickup') return { label: 'Ready for pickup now', tone: 'green' }
  if (status === 'pending') return { label: 'Awaiting confirmation', tone: 'amber' }

  // No promised durations: the co-operative confirms timing on WhatsApp.
  void createdAt
  const packing = status === 'confirmed' || status === 'processing'
  if (channel === 'ferry') {
    if (status === 'shipped') return { label: 'Arriving at Azam office soon', tone: 'blue' }
    if (packing) return { label: 'Being packed for the ferry', tone: 'blue' }
    return { label: 'Ferry date shared after confirmation', tone: 'amber' }
  }
  if (channel === 'pickup') {
    if (packing) return { label: 'Being prepared for pickup', tone: 'blue' }
    return { label: 'Ready for pickup after confirmation', tone: 'amber' }
  }
  if (status === 'shipped') return { label: 'On the way to you', tone: 'blue' }
  if (packing) return { label: 'Being prepared for delivery', tone: 'blue' }
  return { label: 'Delivery arranged after confirmation', tone: 'amber' }
}
