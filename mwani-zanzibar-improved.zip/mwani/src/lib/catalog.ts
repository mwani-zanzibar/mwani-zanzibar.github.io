import type { ApiProduct, ApiSettings } from '@/lib/api'
import { asset } from '@/lib/asset'
import { formatTZS } from '@/lib/format'

const BRAND = {
  name: 'Mwani Zanzibar Seaweed',
  parent: 'Wakulima Hai Co-operative Society',
}

export function generateCatalogHTML(products: ApiProduct[], settings: ApiSettings | null): string {
  const date = new Date()
  const logoUrl = typeof window !== 'undefined' ? `${window.location.origin}${asset('/mwani-logo.png')}` : '/mwani-logo.png'
  const wakulimaUrl = typeof window !== 'undefined' ? `${window.location.origin}${asset('/wakulima-hai-logo.png')}` : '/wakulima-hai-logo.png'

  // Group by category
  const byCat: Record<string, ApiProduct[]> = {}
  for (const p of products) {
    if (!p.active) continue
    ;(byCat[p.category] ||= []).push(p)
  }
  const categories = Object.keys(byCat).sort()

  const catBlocks = categories
    .map(
      (cat) => `
    <div class="category">
      <h2 class="cat-title">${cat}</h2>
      <table class="items">
        <thead>
          <tr><th>Product</th><th>Unit</th><th class="num">Price (TSh)</th><th>Stock</th></tr>
        </thead>
        <tbody>
          ${byCat[cat]
            .map(
              (p) => `
            <tr>
              <td>
                <div class="prod">
                  ${p.image ? `<img src="${p.image}" alt="" />` : ''}
                  <div>
                    <div class="prod-name">${p.name}${p.featured ? ' <span class="star">★</span>' : ''}</div>
                    <div class="prod-desc">${p.tagline}</div>
                  </div>
                </div>
              </td>
              <td>${p.unit}</td>
              <td class="num bold">${formatTZS(p.price).replace('TSh ', '')}</td>
              <td>${p.stock <= 0 ? '<span class="out">Out</span>' : p.stock}</td>
            </tr>`
            )
            .join('')}
        </tbody>
      </table>
    </div>`
    )
    .join('')

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Price List — ${BRAND.name}</title>
<style>
  @page { size: A4; margin: 14mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif; color: #2a1a1f; margin: 0; padding: 24px; background: #fff; }
  .header { display: flex; align-items: center; justify-content: space-between; padding-bottom: 16px; border-bottom: 2px solid #7a1f2b; }
  .brand { display: flex; align-items: center; gap: 12px; }
  .brand img { width: 50px; height: 50px; border-radius: 50%; object-fit: contain; border: 1px solid #e5d9d9; }
  .brand-name { font-family: 'Fraunces', Georgia, serif; font-size: 20px; font-weight: 800; color: #7a1f2b; line-height: 1.1; }
  .brand-sub { font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: #8a7272; }
  .meta { text-align: right; }
  .meta h1 { font-family: 'Fraunces', Georgia, serif; font-size: 24px; font-weight: 800; color: #7a1f2b; margin: 0; }
  .meta .date { font-size: 11px; color: #8a7272; margin-top: 2px; }
  .intro { margin-top: 14px; font-size: 12px; color: #6b5555; line-height: 1.5; }
  .category { margin-top: 22px; page-break-inside: avoid; }
  .cat-title { font-family: 'Fraunces', Georgia, serif; font-size: 15px; font-weight: 700; color: #fff; background: #7a1f2b; padding: 6px 14px; border-radius: 8px; display: inline-block; margin: 0 0 8px; }
  table.items { width: 100%; border-collapse: collapse; }
  table.items th { text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: #8a7272; padding: 6px 8px; border-bottom: 2px solid #7a1f2b; }
  table.items th.num { text-align: right; }
  table.items td { font-size: 12px; padding: 8px; border-bottom: 1px solid #f0e8e8; vertical-align: middle; }
  table.items td.num { text-align: right; }
  table.items td.bold { font-weight: 700; color: #7a1f2b; }
  .prod { display: flex; align-items: center; gap: 8px; }
  .prod img { width: 36px; height: 36px; border-radius: 6px; object-fit: cover; }
  .prod-name { font-weight: 600; font-size: 12px; }
  .prod-desc { font-size: 10px; color: #8a7272; margin-top: 1px; }
  .star { color: #c2634a; }
  .out { color: #991b1b; font-weight: 700; font-size: 10px; }
  .footer { margin-top: 32px; padding-top: 14px; border-top: 1px solid #ecdfdf; text-align: center; }
  .footer .contact { font-size: 11px; color: #8a7272; line-height: 1.6; }
  .footer .logos { display: flex; justify-content: center; gap: 10px; margin-top: 10px; }
  .footer .logos img { width: 32px; height: 32px; border-radius: 50%; object-fit: contain; border: 1px solid #ecdfdf; }
  .toolbar { position: sticky; top: 0; background: #7a1f2b; color: #fff; padding: 10px 16px; display: flex; align-items: center; justify-content: space-between; border-radius: 10px; margin-bottom: 16px; }
  .toolbar button { background: #fff; color: #7a1f2b; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; font-size: 12px; cursor: pointer; }
  .toolbar button:hover { background: #fde2e4; }
  @media print { body { padding: 0; } .toolbar, .no-print { display: none !important; } }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <span>Price list preview</span>
    <span>${products.length} products</span>
    <button onclick="window.print()">🖨 Print / Save PDF</button>
  </div>

  <div class="header">
    <div class="brand">
      <img src="${logoUrl}" alt="Mwani" />
      <div>
        <div class="brand-name">${settings?.shopName || BRAND.name}</div>
        <div class="brand-sub">${BRAND.parent}</div>
      </div>
    </div>
    <div class="meta">
      <h1>PRICE LIST</h1>
      <div class="date">${date.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}</div>
    </div>
  </div>

  <p class="intro">${settings?.tagline || 'Pure ocean goodness, harvested by Zanzibari women farmers.'} Prices in Tanzanian Shillings (TSh). To order, contact us on WhatsApp at ${settings?.phonePrimary || '+255 774 870 703'}.</p>

  ${catBlocks || '<p style="text-align:center;padding:40px;color:#8a7272;">No active products to display.</p>'}

  <div class="footer">
    <div class="contact">
      ${settings?.phonePrimary || '+255 774 870 703'} · ${settings?.email || 'Info@Wakulimahai.org'}<br/>
      ${settings?.address || 'P.O.Box 3943, Mbwenibotanga, Zanzibar'} · ${settings?.website || 'www.wakulimahai.org'}
    </div>
    <div class="logos">
      <img src="${logoUrl}" alt="Mwani" />
      <img src="${wakulimaUrl}" alt="Wakulima Hai" />
    </div>
    <div style="font-size:10px;color:#b8a0a0;margin-top:8px;">Keep Zanzibar green · © ${date.getFullYear()} ${BRAND.parent}</div>
  </div>

  <script>
    window.addEventListener('load', function(){ setTimeout(function(){ window.print(); }, 400); });
  </script>
</body>
</html>`
}

export function openCatalog(products: ApiProduct[], settings: ApiSettings | null) {
  const html = generateCatalogHTML(products, settings)
  const w = window.open('', '_blank', 'width=820,height=1000')
  if (!w) {
    alert('Please allow pop-ups to view the price list.')
    return
  }
  w.document.open()
  w.document.write(html)
  w.document.close()
}
