// Shared data types for the storefront and admin.

export type ApiProduct = {
  id: string
  name: string
  slug: string
  tagline: string
  description: string
  price: number
  unit: string
  category: string
  image: string
  gallery: string[]
  benefits: string[]
  ingredients: string[]
  howToUse: string
  stock: number
  lowStockThreshold: number
  featured: boolean
  active: boolean
  rating: number
  reviewCount: number
  createdAt: string
}

export type ApiReview = {
  id: string
  productId: string
  name: string
  location: string
  rating: number
  comment: string
  approved: boolean
  createdAt: string
}

export type ApiOrderItem = {
  productId: string
  name: string
  price: number
  qty: number
  unit: string
  image: string
}

export type ApiOrder = {
  id: string
  orderNumber: string
  customerName: string
  customerPhone: string
  customerLocation: string
  deliveryChannel: string
  notes: string
  subtotal: number
  shipping: number
  discount: number
  promoCode: string
  total: number
  status: string
  paymentStatus: string
  createdAt: string
  updatedAt: string
  items: ApiOrderItem[]
  statusHistory: { status: string; at: string; note?: string }[]
}

export type ApiSale = {
  id: string
  productId: string | null
  itemName: string
  qty: number
  price: number
  total: number
  channel: string
  customerName: string
  customerPhone: string
  location: string
  note: string
  date: string
  createdAt: string
}

export type ApiRecipe = {
  id: string
  title: string
  slug: string
  excerpt: string
  content: string
  image: string
  category: string
  prepTime: string
  servings: string
  ingredients: string[]
  steps: string[]
  featured: boolean
  active: boolean
  createdAt: string
  updatedAt: string
}

export type ApiPromoCode = {
  id: string
  code: string
  description: string
  type: string
  value: number
  minOrder: number
  maxDiscount: number
  usageLimit: number
  usedCount: number
  active: boolean
  expiresAt: string | null
  createdAt: string
}

export type ApiRestockLog = {
  id: string
  productId: string
  productName: string
  quantity: number
  fromStock: number
  toStock: number
  adminName: string
  note: string
  createdAt: string
}

/** Admin overrides for site text (per language, by i18n key) and image slots. */
export type SiteContent = { en: Record<string, string>; sw: Record<string, string>; img: Record<string, string> }

export type ApiSettings = {
  whatsappPrimary: string
  whatsappSecondary: string
  email: string
  website: string
  address: string
  phonePrimary: string
  phoneSecondary: string
  instagram: string
  ferryInfo: string
  whatsappMessageTemplate: string
  shopName: string
  tagline: string
  aboutText: string
  heroTitle: string
  heroSubtitle: string
  shippingFeeMainland: number
  freeShippingThreshold: number
  usdRate: number
  content?: SiteContent
}
