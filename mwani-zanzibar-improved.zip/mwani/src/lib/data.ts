// Business logic for the shop. Talks to Firestore or the demo backend
// through the same small contract (backend.ts), so both behave the same.
//
// Security model (see firestore.rules):
//  - Customers can read products, recipes, settings, approved reviews,
//    and a single public tracking document per order number.
//  - Customers can create an order, its tracking document, a pending
//    review and a newsletter signup. Nothing else.
//  - Stock and promo usage are only changed by the admin, when an order
//    is confirmed, so a failed or fake checkout never touches inventory.

import type { Backend, Row } from './backend'
import { isFirebaseConfigured } from './firebase-config'
import { firebaseBackend } from './firebase-backend'
import { demoBackend } from './demo-backend'
import { DEFAULT_SETTINGS, SEED_PRODUCTS, SEED_RECIPES, SEED_PROMOS } from './seed-data'
import type {
  ApiProduct, ApiReview, ApiOrder, ApiOrderItem, ApiSale, ApiRecipe,
  ApiPromoCode, ApiRestockLog, ApiSettings, SiteContent,
} from './types'

const be: Backend = isFirebaseConfigured ? firebaseBackend : demoBackend
export const backendKind = be.kind

// ── helpers ──────────────────────────────────────────────
function parseJSON<T>(val: unknown, fallback: T): T {
  if (Array.isArray(val)) return val as T
  if (typeof val !== 'string') return fallback
  try { return JSON.parse(val) as T } catch { return fallback }
}
const nowISO = () => new Date().toISOString()
const byNewest = (k: string) => (a: Record<string, unknown>, b: Record<string, unknown>) =>
  new Date(String(b[k] || 0)).getTime() - new Date(String(a[k] || 0)).getTime()
const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

const toProduct = (r: Row): ApiProduct => ({
  ...(r as unknown as ApiProduct),
  benefits: parseJSON(r.benefits, []),
  ingredients: parseJSON(r.ingredients, []),
  gallery: parseJSON(r.gallery, []),
  rating: Number(r.rating) || 0,
  reviewCount: Number(r.reviewCount) || 0,
  stock: Number(r.stock) || 0,
  price: Number(r.price) || 0,
  lowStockThreshold: Number(r.lowStockThreshold) || 5,
})
const toRecipe = (r: Row): ApiRecipe => ({
  ...(r as unknown as ApiRecipe),
  ingredients: parseJSON(r.ingredients, []),
  steps: parseJSON(r.steps, []),
})
const toOrder = (r: Row): ApiOrder => ({
  ...(r as unknown as ApiOrder),
  items: parseJSON(r.itemsJson ?? r.items, []),
  statusHistory: parseJSON(r.statusHistory, []),
})

// Orders placed on this device, so "My orders" works without exposing
// every customer's phone number to the public internet.
const MY_ORDERS_KEY = 'mwani-my-orders'
function rememberOrder(orderNumber: string) {
  try {
    const list = JSON.parse(localStorage.getItem(MY_ORDERS_KEY) || '[]') as string[]
    if (!list.includes(orderNumber)) localStorage.setItem(MY_ORDERS_KEY, JSON.stringify([orderNumber, ...list].slice(0, 30)))
  } catch { /* storage blocked */ }
}
function rememberedOrders(): string[] {
  try { return JSON.parse(localStorage.getItem(MY_ORDERS_KEY) || '[]') as string[] } catch { return [] }
}

function promoDiscount(promo: ApiPromoCode, subtotal: number) {
  let d = promo.type === 'percentage' ? (subtotal * promo.value) / 100 : promo.value
  if (promo.type === 'percentage' && promo.maxDiscount > 0) d = Math.min(d, promo.maxDiscount)
  return Math.round(Math.min(d, subtotal))
}

function checkPromo(promo: ApiPromoCode | null, subtotal: number): string | null {
  if (!promo || !promo.active) return 'That code is not valid.'
  if (promo.expiresAt && new Date(promo.expiresAt) < new Date()) return 'That code has expired.'
  if (promo.usageLimit > 0 && (promo.usedCount || 0) >= promo.usageLimit) return 'That code has been fully used.'
  if (promo.minOrder > 0 && subtotal < promo.minOrder) return `That code needs an order of at least TSh ${promo.minOrder.toLocaleString('en-US')}.`
  return null
}

async function getPromo(code: string): Promise<ApiPromoCode | null> {
  const id = code.trim().toUpperCase()
  if (!id) return null
  const r = await be.get('promoCodes', id)
  return r ? ({ ...(r as unknown as ApiPromoCode), id: r.id, code: String(r.code || r.id) }) : null
}

function publicTracking(o: {
  orderNumber: string; customerName: string; deliveryChannel: string; status: string; statusHistory: string
  paymentStatus: string; itemsJson: string; subtotal: number; shipping: number; discount: number; total: number
  createdAt: string; updatedAt: string
}) {
  const items = parseJSON<ApiOrderItem[]>(o.itemsJson, []).map(({ name, qty, price, unit, image, productId }) => ({ name, qty, price, unit, image, productId }))
  return {
    orderNumber: o.orderNumber,
    customerName: o.customerName.split(' ')[0] || '',
    deliveryChannel: o.deliveryChannel,
    status: o.status,
    statusHistory: o.statusHistory,
    paymentStatus: o.paymentStatus,
    itemsJson: JSON.stringify(items),
    subtotal: o.subtotal, shipping: o.shipping, discount: o.discount, total: o.total,
    createdAt: o.createdAt, updatedAt: o.updatedAt,
  }
}

const IN_STOCK_STATES = ['confirmed', 'processing', 'shipped', 'ready_for_pickup', 'delivered']

export const data = {
  // ── First run: fill an empty database from seed-data.ts ──
  // Used by the admin panel's "Load starting catalogue" button, so setting up
  // a new Firebase project needs no terminal.
  async isEmpty() {
    return (await be.list('products')).length === 0
  },
  async loadStarterData() {
    if (!(await this.isEmpty())) throw new Error('The shop already has products, so nothing was added.')
    const now = Date.now()
    const at = new Date(now).toISOString()
    // Staggered times keep the catalogue in the same order as seed-data.ts.
    const stamp = (i: number) => new Date(now - i * 60_000).toISOString()
    for (const [i, p] of SEED_PRODUCTS.entries()) {
      await be.set('products', 'p-' + slugify(p.name), {
        ...p, featured: !!p.featured, slug: slugify(p.name),
        benefits: JSON.stringify(p.benefits), ingredients: JSON.stringify(p.ingredients), gallery: JSON.stringify(p.gallery),
        createdAt: stamp(i), updatedAt: stamp(i),
      })
    }
    for (const [i, r] of SEED_RECIPES.entries()) {
      await be.set('recipes', 'r-' + slugify(r.title), {
        ...r, featured: !!r.featured, slug: slugify(r.title),
        ingredients: JSON.stringify(r.ingredients), steps: JSON.stringify(r.steps), createdAt: stamp(i), updatedAt: stamp(i),
      })
    }
    const promos = new Set((await be.list('promoCodes')).map((r) => r.id))
    for (const p of SEED_PROMOS) if (!promos.has(p.code)) await be.set('promoCodes', p.code, { ...p, expiresAt: null, createdAt: at })
    const keys = new Set((await be.list('settings')).map((r) => String(r.key)))
    for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) if (!keys.has(key)) await be.set('settings', key, { key, value: String(value) })
    return { products: SEED_PRODUCTS.length, recipes: SEED_RECIPES.length }
  },

  // ── Settings ─────────────────────────────────────────
  async getSettings(): Promise<ApiSettings> {
    const rows = await be.list('settings')
    const merged: ApiSettings = { ...DEFAULT_SETTINGS }
    const content: SiteContent = { en: {}, sw: {}, img: {} }
    for (const r of rows) {
      const raw = String(r.key)
      // Site content lives in its own rows: text.en / text.sw (JSON) and img.<slot> (one image each,
      // so an uploaded photo never pushes another over the document size limit).
      if (raw === 'text.en' || raw === 'text.sw') {
        try { const o = JSON.parse(String(r.value || '{}')); if (o && typeof o === 'object') content[raw === 'text.en' ? 'en' : 'sw'] = o } catch { /* ignore bad row */ }
        continue
      }
      if (raw.startsWith('img.')) { if (r.value) content.img[raw.slice(4)] = String(r.value); continue }
      const key = raw as keyof ApiSettings
      if (!(key in DEFAULT_SETTINGS)) continue
      const def = DEFAULT_SETTINGS[key]
      ;(merged as Record<string, unknown>)[key] = typeof def === 'number' ? Number(r.value) || def : String(r.value)
    }
    merged.content = content
    return merged
  },
  /** Save site text overrides (whole map per language) and image slots (null or '' removes one). */
  async updateContent(patch: { en?: Record<string, string>; sw?: Record<string, string>; img?: Record<string, string | null> }) {
    const clean = (o: Record<string, string>) => Object.fromEntries(Object.entries(o).filter(([, v]) => typeof v === 'string' && v.trim() !== ''))
    if (patch.en) await be.set('settings', 'text.en', { key: 'text.en', value: JSON.stringify(clean(patch.en)) })
    if (patch.sw) await be.set('settings', 'text.sw', { key: 'text.sw', value: JSON.stringify(clean(patch.sw)) })
    for (const [slot, url] of Object.entries(patch.img || {})) {
      if (url && url.trim()) await be.set('settings', `img.${slot}`, { key: `img.${slot}`, value: url.trim() })
      else await be.remove('settings', `img.${slot}`).catch(() => {})
    }
    return this.getSettings()
  },
  async updateSettings(values: Partial<ApiSettings>) {
    const rows = await be.list('settings')
    for (const [k, v] of Object.entries(values)) {
      if (k === 'content' || !(k in DEFAULT_SETTINGS)) continue
      const existing = rows.find((r) => r.key === k)
      if (existing) await be.update('settings', existing.id, { value: String(v) })
      else await be.set('settings', k, { key: k, value: String(v) })
    }
    return this.getSettings()
  },

  // ── Products ─────────────────────────────────────────
  async getProducts(params?: Record<string, string>) {
    let products = (await be.list('products')).map(toProduct)
    if (params?.admin !== '1') products = products.filter((p) => p.active)
    if (params?.category && params.category !== 'all') products = products.filter((p) => p.category === params.category)
    if (params?.featured === '1') products = products.filter((p) => p.featured)
    if (params?.q) {
      const s = params.q.toLowerCase()
      products = products.filter((p) => p.name.toLowerCase().includes(s) || p.description.toLowerCase().includes(s))
    }
    return products.sort(byNewest('createdAt'))
  },
  async getProduct(id: string) {
    const r = await be.get('products', id)
    return r ? toProduct(r) : null
  },
  async createProduct(body: Partial<ApiProduct>) {
    const at = nowISO()
    const row = {
      name: body.name || '', slug: slugify(body.name || '') + '-' + Math.random().toString(36).slice(2, 6),
      tagline: body.tagline || '', description: body.description || '',
      price: Number(body.price) || 0, unit: body.unit || 'each',
      category: body.category || 'Food & Beverage', image: body.image || '/products/powder-cut.webp',
      benefits: JSON.stringify(body.benefits || []), ingredients: JSON.stringify(body.ingredients || []),
      gallery: JSON.stringify(body.gallery || []), howToUse: body.howToUse || '',
      stock: Number(body.stock) || 0, lowStockThreshold: Number(body.lowStockThreshold) || 5,
      featured: !!body.featured, active: body.active !== false, rating: 0, reviewCount: 0,
      createdAt: at, updatedAt: at,
    }
    const id = await be.add('products', row)
    return toProduct({ id, ...row })
  },
  async updateProduct(id: string, body: Partial<ApiProduct>) {
    const patch: Record<string, unknown> = {}
    const fields = ['name', 'tagline', 'description', 'price', 'unit', 'category', 'image', 'howToUse', 'stock', 'lowStockThreshold', 'featured', 'active'] as const
    for (const f of fields) if (body[f] !== undefined) patch[f] = body[f]
    if (body.benefits !== undefined) patch.benefits = JSON.stringify(body.benefits)
    if (body.ingredients !== undefined) patch.ingredients = JSON.stringify(body.ingredients)
    if (body.gallery !== undefined) patch.gallery = JSON.stringify(body.gallery)
    patch.updatedAt = nowISO()
    await be.update('products', id, patch)
    return this.getProduct(id)
  },
  async deleteProduct(id: string) {
    await be.remove('products', id)
    return { ok: true }
  },
  async restock(id: string, quantity: number) {
    const p = await this.getProduct(id)
    if (!p) throw new Error('Product not found')
    const add = Math.floor(quantity)
    const toStock = p.stock + add
    await be.update('products', id, { stock: toStock, updatedAt: nowISO() })
    await be.add('restockLogs', {
      productId: id, productName: p.name, quantity: add, fromStock: p.stock, toStock,
      adminName: 'admin', note: `Quick restock +${add}`, createdAt: nowISO(),
    })
    return { product: await this.getProduct(id), fromStock: p.stock, toStock }
  },
  async getRestockLogs() {
    return (await be.list('restockLogs')).map((r) => r as unknown as ApiRestockLog).sort(byNewest('createdAt'))
  },

  // ── Reviews ──────────────────────────────────────────
  // Public: approved only. The query itself filters on approved == true,
  // which is what the database rules require.
  async getApprovedReviews(productId?: string) {
    let rows = (await be.where('reviews', [['approved', true]])).map((r) => r as unknown as ApiReview)
    if (productId) rows = rows.filter((r) => r.productId === productId)
    return rows.sort(byNewest('createdAt'))
  },
  async getAllReviews() {
    return (await be.list('reviews')).map((r) => r as unknown as ApiReview).sort(byNewest('createdAt'))
  },
  async addReview(body: { productId: string; name: string; location: string; rating: number; comment: string }) {
    const row = {
      productId: body.productId, name: body.name.trim().slice(0, 80),
      location: (body.location || 'Zanzibar').trim().slice(0, 80),
      rating: Math.min(5, Math.max(1, Math.round(Number(body.rating) || 5))),
      comment: body.comment.trim().slice(0, 600),
      approved: false, createdAt: nowISO(),
    }
    const id = await be.add('reviews', row)
    return { id, ...row } as ApiReview
  },
  async recalcProductRating(productId: string) {
    const approved = await this.getApprovedReviews(productId)
    const avg = approved.length ? approved.reduce((s, r) => s + r.rating, 0) / approved.length : 0
    await be.update('products', productId, { rating: Math.round(avg * 10) / 10, reviewCount: approved.length })
  },
  async approveReview(id: string, approved: boolean) {
    const r = await be.get('reviews', id)
    await be.update('reviews', id, { approved })
    if (r?.productId) await this.recalcProductRating(String(r.productId))
    return { id, approved } as unknown as ApiReview
  },
  async deleteReview(id: string) {
    const r = await be.get('reviews', id)
    await be.remove('reviews', id)
    if (r?.productId && r.approved) await this.recalcProductRating(String(r.productId))
    return { ok: true }
  },

  // ── Orders ───────────────────────────────────────────
  async createOrder(body: {
    customerName: string; customerPhone: string; customerLocation: string
    deliveryChannel: string; notes?: string; promoCode?: string
    items: ApiOrderItem[]
  }) {
    if (!body.items.length) throw new Error('Your bag is empty.')
    // Price every line from the live catalogue, never from the browser's cart.
    const catalogue = await this.getProducts()
    const items: ApiOrderItem[] = []
    for (const it of body.items) {
      const p = catalogue.find((c) => c.id === it.productId)
      if (!p) throw new Error(`${it.name} is no longer available. Remove it from your bag to continue.`)
      if (p.stock <= 0) throw new Error(`${p.name} is out of stock. Remove it from your bag to continue.`)
      items.push({ productId: p.id, name: p.name, price: p.price, qty: Math.max(1, Math.min(it.qty, p.stock)), unit: p.unit, image: p.image })
    }
    const settings = await this.getSettings()
    const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0)

    let discount = 0, promoCode = ''
    if (body.promoCode) {
      const promo = await getPromo(body.promoCode)
      if (!checkPromo(promo, subtotal) && promo) { discount = promoDiscount(promo, subtotal); promoCode = promo.code }
    }
    const shipping = body.deliveryChannel === 'ferry' && subtotal < settings.freeShippingThreshold ? settings.shippingFeeMainland : 0
    const total = Math.max(0, subtotal + shipping - discount)
    const rand = Array.from(crypto.getRandomValues(new Uint8Array(5))).map((b) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('')
    const orderNumber = 'MWS-' + Date.now().toString(36).toUpperCase().slice(-4) + rand
    const at = nowISO()
    const statusHistory = JSON.stringify([{ status: 'pending', at }])
    const row = {
      orderNumber, customerName: body.customerName.trim().slice(0, 80), customerPhone: body.customerPhone.trim().slice(0, 30),
      customerLocation: body.customerLocation.trim().slice(0, 160), deliveryChannel: body.deliveryChannel,
      notes: (body.notes || '').slice(0, 600), subtotal, shipping, discount, promoCode, total,
      itemsJson: JSON.stringify(items), status: 'pending', statusHistory,
      paymentStatus: 'unpaid', stockApplied: false, createdAt: at, updatedAt: at,
    }
    const id = await be.add('orders', row)
    await be.set('orderTracking', orderNumber, publicTracking(row))
    rememberOrder(orderNumber)
    return { ...toOrder({ id, ...row }) }
  },
  async getOrders() {
    return (await be.list('orders')).map(toOrder).sort(byNewest('createdAt'))
  },
  async updateOrder(id: string, body: Record<string, unknown>) {
    const existing = await be.get('orders', id)
    if (!existing) throw new Error('Order not found')
    const cur = toOrder(existing)
    const patch: Record<string, unknown> = { updatedAt: nowISO() }

    if (typeof body.status === 'string' && body.status !== cur.status) {
      const next = body.status
      patch.status = next
      patch.statusHistory = JSON.stringify([...cur.statusHistory, { status: next, at: nowISO() }])
      const applied = !!existing.stockApplied
      // Stock and promo usage move only when the admin confirms.
      if (!applied && IN_STOCK_STATES.includes(next)) {
        for (const it of cur.items) {
          const p = await this.getProduct(it.productId)
          if (p) await be.update('products', p.id, { stock: Math.max(0, p.stock - it.qty) })
        }
        if (cur.promoCode) {
          const promo = await getPromo(cur.promoCode)
          if (promo) await be.update('promoCodes', promo.id, { usedCount: (promo.usedCount || 0) + 1 })
        }
        patch.stockApplied = true
      }
      if (applied && next === 'cancelled') {
        for (const it of cur.items) {
          const p = await this.getProduct(it.productId)
          if (p) await be.update('products', p.id, { stock: p.stock + it.qty })
        }
        patch.stockApplied = false
      }
    }
    if (typeof body.paymentStatus === 'string') patch.paymentStatus = body.paymentStatus
    if (body.notes !== undefined) patch.notes = String(body.notes)
    await be.update('orders', id, patch)

    const updated = toOrder((await be.get('orders', id))!)
    await be.set('orderTracking', updated.orderNumber, publicTracking({
      ...updated, itemsJson: JSON.stringify(updated.items), statusHistory: JSON.stringify(updated.statusHistory),
    }))
    return updated
  },
  async trackOrder(orderNumber: string) {
    const r = await be.get('orderTracking', orderNumber.trim().toUpperCase())
    if (!r) return null
    return { ...toOrder(r), id: r.id, customerPhone: '', customerLocation: '', notes: '', promoCode: '' } as ApiOrder
  },
  async getMyOrders() {
    const found = await Promise.all(rememberedOrders().map((n) => this.trackOrder(n).catch(() => null)))
    return found.filter((o): o is ApiOrder => !!o)
  },

  // ── Sales (walk-in, recorded by admin) ───────────────
  async getSales() {
    return (await be.list('sales')).map((r) => r as unknown as ApiSale).sort(byNewest('date'))
  },
  async createSale(body: Partial<ApiSale> & { itemName: string; qty: number; price: number }) {
    const qty = Number(body.qty), price = Number(body.price)
    const row = {
      productId: body.productId || null, itemName: body.itemName, qty, price, total: qty * price,
      channel: body.channel || 'local', customerName: body.customerName || 'Walk-in',
      customerPhone: body.customerPhone || '', location: body.location || 'Zanzibar',
      note: body.note || '', date: nowISO(), createdAt: nowISO(),
    }
    const id = await be.add('sales', row)
    if (body.productId) {
      const p = await this.getProduct(body.productId)
      if (p) await be.update('products', p.id, { stock: Math.max(0, p.stock - qty) })
    }
    return { id, ...row } as ApiSale
  },
  async deleteSale(id: string) {
    await be.remove('sales', id)
    return { ok: true }
  },

  // ── Recipes ──────────────────────────────────────────
  async getRecipes(params?: Record<string, string>) {
    let recipes = (await be.list('recipes')).map(toRecipe)
    if (params?.admin !== '1') recipes = recipes.filter((r) => r.active)
    if (params?.category && params.category !== 'all') recipes = recipes.filter((r) => r.category === params.category)
    if (params?.featured === '1') recipes = recipes.filter((r) => r.featured)
    return recipes.sort(byNewest('createdAt'))
  },
  async getRecipe(id: string) {
    const r = await be.get('recipes', id)
    return r ? toRecipe(r) : null
  },
  async createRecipe(body: Partial<ApiRecipe>) {
    const at = nowISO()
    const row = {
      title: body.title || '', slug: slugify(body.title || '') + '-' + Math.random().toString(36).slice(2, 6),
      excerpt: body.excerpt || '', content: body.content || '', image: body.image || '/products/powder.webp',
      category: body.category || 'Cooking', prepTime: body.prepTime || '', servings: body.servings || '',
      ingredients: JSON.stringify(body.ingredients || []), steps: JSON.stringify(body.steps || []),
      featured: !!body.featured, active: body.active !== false, createdAt: at, updatedAt: at,
    }
    const id = await be.add('recipes', row)
    return toRecipe({ id, ...row })
  },
  async updateRecipe(id: string, body: Partial<ApiRecipe>) {
    const patch: Record<string, unknown> = {}
    const fields = ['title', 'excerpt', 'content', 'image', 'category', 'prepTime', 'servings', 'featured', 'active'] as const
    for (const f of fields) if (body[f] !== undefined) patch[f] = body[f]
    if (body.ingredients !== undefined) patch.ingredients = JSON.stringify(body.ingredients)
    if (body.steps !== undefined) patch.steps = JSON.stringify(body.steps)
    patch.updatedAt = nowISO()
    await be.update('recipes', id, patch)
    return this.getRecipe(id)
  },
  async deleteRecipe(id: string) {
    await be.remove('recipes', id)
    return { ok: true }
  },

  // ── Promo codes (document id = the code itself) ──────
  async getPromoCodes() {
    return (await be.list('promoCodes')).map((r) => ({ ...(r as unknown as ApiPromoCode), id: r.id, code: String(r.code || r.id) }))
  },
  async createPromo(body: Partial<ApiPromoCode>) {
    const code = (body.code || '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '')
    if (!code) throw new Error('Enter a code.')
    if (await be.get('promoCodes', code)) throw new Error(`${code} already exists.`)
    const row = {
      code, description: body.description || '', type: body.type || 'percentage', value: Number(body.value) || 0,
      minOrder: Number(body.minOrder) || 0, maxDiscount: Number(body.maxDiscount) || 0,
      usageLimit: Number(body.usageLimit) || 0, usedCount: 0, active: true,
      expiresAt: body.expiresAt || null, createdAt: nowISO(),
    }
    await be.set('promoCodes', code, row)
    return { id: code, ...row } as ApiPromoCode
  },
  async updatePromo(id: string, body: Partial<ApiPromoCode>) {
    const patch: Record<string, unknown> = {}
    const fields = ['description', 'type', 'value', 'minOrder', 'maxDiscount', 'usageLimit', 'active', 'expiresAt'] as const
    for (const f of fields) if (body[f] !== undefined) patch[f] = body[f]
    await be.update('promoCodes', id, patch)
    return { id, ...body } as ApiPromoCode
  },
  async deletePromo(id: string) {
    await be.remove('promoCodes', id)
    return { ok: true }
  },
  async validatePromo(code: string, subtotal: number) {
    const promo = await getPromo(code)
    const problem = checkPromo(promo, subtotal)
    if (problem || !promo) throw new Error(problem || 'That code is not valid.')
    return { valid: true, code: promo.code, description: promo.description, type: promo.type, value: promo.value, discount: promoDiscount(promo, subtotal) }
  },

  // ── Newsletter (document id = email, so repeats are harmless) ──
  async subscribe(email: string, name?: string) {
    const e = email.trim().toLowerCase()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) throw new Error('Enter a valid email address.')
    try {
      await be.set('newsletter', e, { email: e, name: (name || '').slice(0, 80), createdAt: nowISO() })
    } catch {
      // Already subscribed: the rules refuse the overwrite, which is fine.
    }
    return { ok: true }
  },
  async getSubscribers() {
    return (await be.list('newsletter')).map((r) => r as unknown as { id: string; email: string; name: string; createdAt: string })
  },
  async deleteSubscriber(id: string) {
    await be.remove('newsletter', id)
    return { ok: true }
  },

  // ── Dashboard stats ──────────────────────────────────
  async getStats(range?: string) {
    const [products, orders, sales, reviews, subscribers, recipes] = await Promise.all([
      this.getProducts({ admin: '1' }), this.getOrders(), this.getSales(),
      this.getAllReviews(), this.getSubscribers(), this.getRecipes({ admin: '1' }),
    ])
    const rangeDays = range === '30d' ? 30 : range === '90d' ? 90 : range === 'all' ? 365 : 7
    const start = new Date(); start.setHours(0, 0, 0, 0); start.setDate(start.getDate() - (rangeDays - 1))
    const liveOrders = orders.filter((o) => new Date(o.createdAt) >= start && o.status !== 'cancelled')
    const liveSales = sales.filter((s) => new Date(s.date) >= start)

    const days: { date: string; label: string; orders: number; sales: number }[] = []
    for (let i = 0; i < rangeDays; i++) {
      const d = new Date(start); d.setDate(start.getDate() + i)
      const key = d.toISOString().slice(0, 10)
      days.push({
        date: key,
        label: d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
        orders: liveOrders.filter((o) => o.createdAt.slice(0, 10) === key).reduce((s, o) => s + o.total, 0),
        sales: liveSales.filter((s) => s.date.slice(0, 10) === key).reduce((s, x) => s + x.total, 0),
      })
    }
    const byProduct = new Map<string, { name: string; qty: number; revenue: number }>()
    const byCategory = new Map<string, number>()
    const catOf = (id: string | null) => products.find((p) => p.id === id)?.category || 'Other'
    for (const o of liveOrders) for (const it of o.items) {
      const cur = byProduct.get(it.name) || { name: it.name, qty: 0, revenue: 0 }
      cur.qty += it.qty; cur.revenue += it.qty * it.price; byProduct.set(it.name, cur)
      byCategory.set(catOf(it.productId), (byCategory.get(catOf(it.productId)) || 0) + it.qty * it.price)
    }
    for (const s of liveSales) {
      const cur = byProduct.get(s.itemName) || { name: s.itemName, qty: 0, revenue: 0 }
      cur.qty += s.qty; cur.revenue += s.total; byProduct.set(s.itemName, cur)
      byCategory.set(catOf(s.productId), (byCategory.get(catOf(s.productId)) || 0) + s.total)
    }
    const onlineRevenue = liveOrders.reduce((s, o) => s + o.total, 0)
    const localRevenue = liveSales.reduce((s, o) => s + o.total, 0)
    return {
      totalProducts: products.length,
      lowStock: products.filter((p) => p.stock <= p.lowStockThreshold).length,
      outOfStock: products.filter((p) => p.stock <= 0).length,
      totalOrders: orders.length,
      pendingOrders: orders.filter((o) => o.status === 'pending' || o.status === 'confirmed').length,
      onlineRevenue, localRevenue, totalRevenue: onlineRevenue + localRevenue,
      reviews: reviews.length, pendingReviews: reviews.filter((r) => !r.approved).length,
      subscribers: subscribers.length, recipes: recipes.filter((r) => r.active).length,
      range: range || '7d', rangeDays, days,
      categoryBreakdown: [...byCategory].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value),
      topProducts: [...byProduct.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 5),
    }
  },

  // ── Admin auth ───────────────────────────────────────
  login: (email: string, password: string) => be.login(email, password),
  logout: () => be.logout(),
  session: () => be.session(),

  // ── Image upload ─────────────────────────────────────
  // Resizes in the browser and returns a compact data URL that is stored on
  // the product itself. No separate file storage needed. Keep product
  // photos to one per slot; each is ~60–140 KB after compression.
  async upload(file: File) {
    if (!file.type.startsWith('image/')) throw new Error('Choose an image file (JPG, PNG or WebP).')
    const bitmap = await createImageBitmap(file)
    const max = 1000
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height))
    const canvas = document.createElement('canvas')
    canvas.width = Math.round(bitmap.width * scale)
    canvas.height = Math.round(bitmap.height * scale)
    canvas.getContext('2d')!.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
    let quality = 0.82
    let url = canvas.toDataURL('image/webp', quality)
    while (url.length > 180_000 && quality > 0.5) { quality -= 0.08; url = canvas.toDataURL('image/webp', quality) }
    if (url.length > 400_000) throw new Error('That photo is too detailed to store. Try a smaller or simpler image.')
    return { url }
  },
}
