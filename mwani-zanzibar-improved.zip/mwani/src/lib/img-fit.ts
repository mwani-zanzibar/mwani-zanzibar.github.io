// Product images come in two kinds: real photos (fill the frame) and the same
// photos with the background removed ("-cut" / "-pouch" files), which sit
// inside the frame on the shell well with a soft contact shadow.

export const isCutout = (src?: string | null) => !!src && /-(cut|pouch)\.(webp|png)(\?|$)/i.test(src)

type Size = 'sm' | 'md' | 'lg'
const PAD: Record<Size, string> = { sm: 'p-[10%]', md: 'px-[9%] pt-[16%] pb-[7%]', lg: 'p-[9%]' }
const SHADOW: Record<Size, string> = {
  sm: 'drop-shadow-[0_3px_4px_rgba(31,7,14,0.18)]',
  md: 'drop-shadow-[0_14px_16px_rgba(31,7,14,0.18)]',
  lg: 'drop-shadow-[0_22px_26px_rgba(31,7,14,0.2)]',
}

/** Classes for a next/image with `fill`. */
export function fit(src: string | undefined | null, size: Size = 'md') {
  return isCutout(src) ? `object-contain ${PAD[size]} ${SHADOW[size]}` : 'object-cover'
}
