// Firestore implementation of the Backend contract.
// The Firebase SDK is imported lazily, so demo mode never loads it.

import type { Backend, Row, AdminSession } from './backend'
import { firebaseConfig } from './firebase-config'

type FS = typeof import('firebase/firestore')

let ready: Promise<{ fs: FS; db: import('firebase/firestore').Firestore; auth: import('firebase/auth').Auth }> | null = null

function init() {
  if (!ready) {
    ready = (async () => {
      const [{ initializeApp, getApps }, fs, { getAuth }] = await Promise.all([
        import('firebase/app'),
        import('firebase/firestore'),
        import('firebase/auth'),
      ])
      const app = getApps()[0] ?? initializeApp(firebaseConfig)
      const db = fs.getFirestore(app), auth = getAuth(app)
      // Developers only: point at the local Firebase emulators (never set on the live site).
      const emu = process.env.NEXT_PUBLIC_FIREBASE_EMULATOR_HOST
      if (emu) {
        const { connectAuthEmulator } = await import('firebase/auth')
        fs.connectFirestoreEmulator(db, emu, 8085)
        connectAuthEmulator(auth, `http://${emu}:9099`, { disableWarnings: true })
      }
      return { fs, db, auth }
    })()
  }
  return ready
}

const toRow = (d: { id: string; data: () => Record<string, unknown> }): Row => ({ id: d.id, ...d.data() })

const ADMIN_NAME = 'Wakulima Hai Admin'

// Only accounts whose email is a document id in the Firestore "admins"
// collection are staff. Signing in with any other account is refused.
async function isAdmin(email: string | null) {
  if (!email) return false
  const { fs, db } = await init()
  try { return (await fs.getDoc(fs.doc(db, 'admins', email.toLowerCase()))).exists() } catch { return false }
}

export const firebaseBackend: Backend = {
  kind: 'firebase',
  async list(col) {
    const { fs, db } = await init()
    const snap = await fs.getDocs(fs.collection(db, col))
    return snap.docs.map(toRow)
  },
  async where(col, filters) {
    const { fs, db } = await init()
    const q = fs.query(fs.collection(db, col), ...filters.map(([f, v]) => fs.where(f, '==', v)))
    const snap = await fs.getDocs(q)
    return snap.docs.map(toRow)
  },
  async get(col, id) {
    const { fs, db } = await init()
    const d = await fs.getDoc(fs.doc(db, col, id))
    return d.exists() ? toRow(d) : null
  },
  async add(col, data) {
    const { fs, db } = await init()
    const ref = await fs.addDoc(fs.collection(db, col), data)
    return ref.id
  },
  async set(col, id, data) {
    const { fs, db } = await init()
    await fs.setDoc(fs.doc(db, col, id), data)
  },
  async update(col, id, data) {
    const { fs, db } = await init()
    await fs.updateDoc(fs.doc(db, col, id), data)
  },
  async remove(col, id) {
    const { fs, db } = await init()
    await fs.deleteDoc(fs.doc(db, col, id))
  },
  async login(email, password) {
    const { auth } = await init()
    const { signInWithEmailAndPassword } = await import('firebase/auth')
    let cred
    try {
      cred = await signInWithEmailAndPassword(auth, email.trim(), password)
    } catch {
      throw new Error('That email and password did not match an admin account.')
    }
    if (!(await isAdmin(cred.user.email))) {
      const { signOut } = await import('firebase/auth')
      await signOut(auth)
      throw new Error('This account is not on the staff list. In Firebase → Firestore Database, add a document to the "admins" collection whose ID is this email (DEPLOYMENT.md, step 5).')
    }
    return { authenticated: true, admin: { id: cred.user.uid, username: cred.user.email || 'admin', name: ADMIN_NAME } }
  },
  async logout() {
    const { auth } = await init()
    const { signOut } = await import('firebase/auth')
    await signOut(auth)
  },
  async session() {
    const { auth } = await init()
    const { onAuthStateChanged } = await import('firebase/auth')
    return new Promise<AdminSession>((resolve) => {
      const stop = onAuthStateChanged(auth, async (user) => {
        stop()
        if (!user || !(await isAdmin(user.email))) return resolve({ authenticated: false })
        resolve({ authenticated: true, admin: { id: user.uid, username: user.email || 'admin', name: ADMIN_NAME } })
      })
    })
  },
}
