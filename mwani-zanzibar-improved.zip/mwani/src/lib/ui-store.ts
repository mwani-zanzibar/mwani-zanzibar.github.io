import { create } from 'zustand'
import type { ApiProduct } from './types'

// Which overlay is open. One source of truth so the nav, the mobile dock,
// the search palette and the cart pill can all open things.
type UI = {
  quick: ApiProduct | null
  setQuick: (p: ApiProduct | null) => void
  searchOpen: boolean
  setSearchOpen: (v: boolean) => void
  checkoutOpen: boolean
  setCheckoutOpen: (v: boolean) => void
  trackOpen: boolean
  trackPreset: string
  openTrack: (orderNumber?: string) => void
  setTrackOpen: (v: boolean) => void
  myOrdersOpen: boolean
  setMyOrdersOpen: (v: boolean) => void
  menuOpen: boolean
  setMenuOpen: (v: boolean) => void
  /** Centre of the button that opened the menu, so the menu can grow out of it. */
  menuOrigin: { x: number; y: number } | null
  openMenu: (from?: Element | null) => void
}

export const useUI = create<UI>()((set) => ({
  quick: null,
  setQuick: (quick) => set({ quick }),
  searchOpen: false,
  setSearchOpen: (searchOpen) => set({ searchOpen }),
  checkoutOpen: false,
  setCheckoutOpen: (checkoutOpen) => set({ checkoutOpen }),
  trackOpen: false,
  trackPreset: '',
  openTrack: (orderNumber = '') => set({ trackOpen: true, trackPreset: orderNumber }),
  setTrackOpen: (trackOpen) => set((s) => ({ trackOpen, trackPreset: trackOpen ? s.trackPreset : '' })),
  myOrdersOpen: false,
  setMyOrdersOpen: (myOrdersOpen) => set({ myOrdersOpen }),
  menuOpen: false,
  setMenuOpen: (menuOpen) => set({ menuOpen }),
  menuOrigin: null,
  openMenu: (from) => {
    const r = from?.getBoundingClientRect()
    set({ menuOpen: true, menuOrigin: r ? { x: r.left + r.width / 2, y: r.top + r.height / 2 } : null })
  },
}))
