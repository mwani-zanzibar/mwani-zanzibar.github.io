'use client'

import { useCurrency, formatMoney } from '@/lib/currency-store'

// Hook to format an amount (in TSh) using the active currency.
export function useMoney() {
  const { currency, rate } = useCurrency()
  return (amountTSh: number) => formatMoney(amountTSh, currency, rate)
}
