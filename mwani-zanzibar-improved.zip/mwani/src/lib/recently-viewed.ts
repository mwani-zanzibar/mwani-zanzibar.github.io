import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type ViewedItem = {
  id: string
  name: string
  price: number
  image: string
  category: string
}

type State = {
  items: ViewedItem[]
  add: (item: ViewedItem) => void
  clear: () => void
}

export const useRecentlyViewed = create<State>()(
  persist(
    (set) => ({
      items: [],
      add: (item) =>
        set((s) => ({
          items: [item, ...s.items.filter((i) => i.id !== item.id)].slice(0, 8),
        })),
      clear: () => set({ items: [] }),
    }),
    { name: 'mwani-recently-viewed' }
  )
)
