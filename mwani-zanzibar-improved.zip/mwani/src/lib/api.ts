// Public API used by every component. Backed by lib/data.ts, which runs on
// Firestore when the Firebase config is set, or on the in-browser demo
// store until then.

import { data, backendKind } from './data'
import type {
  ApiProduct, ApiReview, ApiOrder, ApiOrderItem, ApiSale, ApiRecipe,
  ApiPromoCode, ApiRestockLog, ApiSettings,
} from './types'

export type {
  ApiProduct, ApiReview, ApiOrder, ApiOrderItem, ApiSale, ApiRecipe,
  ApiPromoCode, ApiRestockLog, ApiSettings,
}

export const isDemo = backendKind === 'demo'

export const api = {
  // Products
  products: (params?: Record<string, string>) => data.getProducts(params).then((products) => ({ products })),
  product: (id: string) => data.getProduct(id).then((product) => ({ product: product! })),
  createProduct: (body: Partial<ApiProduct>) => data.createProduct(body),
  updateProduct: (id: string, body: Partial<ApiProduct>) => data.updateProduct(id, body),
  deleteProduct: (id: string) => data.deleteProduct(id),
  restock: (id: string, quantity: number) => data.restock(id, quantity),

  // Reviews
  reviews: (productId: string) => data.getApprovedReviews(productId).then((reviews) => ({ reviews })),
  approvedReviews: () => data.getApprovedReviews().then((reviews) => ({ reviews })),
  allReviews: () => data.getAllReviews().then((reviews) => ({ reviews })),
  addReview: (body: { productId: string; name: string; location: string; rating: number; comment: string }) =>
    data.addReview(body).then((review) => ({ review })),
  approveReview: (id: string, approved: boolean) => data.approveReview(id, approved),
  deleteReview: (id: string) => data.deleteReview(id),

  // Orders
  createOrder: (body: {
    customerName: string; customerPhone: string; customerLocation: string
    deliveryChannel: string; notes?: string; promoCode?: string
    items: ApiOrderItem[]
  }) => data.createOrder(body).then((order) => ({ order })),
  orders: () => data.getOrders().then((orders) => ({ orders })),
  updateOrder: (id: string, body: Record<string, unknown>) => data.updateOrder(id, body),
  track: (orderNumber: string) =>
    data.trackOrder(orderNumber).then((order) => {
      if (!order) throw new Error('No order has that number. Check it against your WhatsApp message.')
      return { order }
    }),
  myOrders: () => data.getMyOrders().then((orders) => ({ orders })),

  // Sales
  sales: () => data.getSales().then((sales) => ({ sales })),
  createSale: (body: Partial<ApiSale>) => {
    if (!body.itemName || !body.qty || body.price === undefined) throw new Error('Add an item, quantity and price.')
    return data.createSale(body as Partial<ApiSale> & { itemName: string; qty: number; price: number })
  },
  deleteSale: (id: string) => data.deleteSale(id),

  // Recipes
  recipes: (params?: Record<string, string>) => data.getRecipes(params).then((recipes) => ({ recipes })),
  createRecipe: (body: Partial<ApiRecipe>) => data.createRecipe(body),
  updateRecipe: (id: string, body: Partial<ApiRecipe>) => data.updateRecipe(id, body),
  deleteRecipe: (id: string) => data.deleteRecipe(id),

  // Promo codes
  promoCodes: () => data.getPromoCodes().then((codes) => ({ codes })),
  createPromo: (body: Partial<ApiPromoCode>) => data.createPromo(body),
  updatePromo: (id: string, body: Partial<ApiPromoCode>) => data.updatePromo(id, body),
  deletePromo: (id: string) => data.deletePromo(id),
  validatePromo: (code: string, subtotal: number) => data.validatePromo(code, subtotal),

  // Newsletter
  subscribe: (email: string, name?: string) => data.subscribe(email, name),
  subscribers: () => data.getSubscribers().then((subscribers) => ({ subscribers })),
  deleteSubscriber: (id: string) => data.deleteSubscriber(id),

  // First run
  isEmpty: () => data.isEmpty(),
  loadStarterData: () => data.loadStarterData(),

  // Settings
  settings: () => data.getSettings().then((settings) => ({ settings })),
  updateSettings: (body: Partial<ApiSettings>) => data.updateSettings(body),
  updateContent: (patch: Parameters<typeof data.updateContent>[0]) => data.updateContent(patch),

  // Stats and logs
  stats: (range?: string) => data.getStats(range),
  restockLogs: () => data.getRestockLogs().then((logs) => ({ logs })),

  // Admin auth
  login: (email: string, password: string) => data.login(email, password),
  logout: () => data.logout(),
  session: () => data.session(),

  // Image upload (compressed in the browser, stored on the product)
  upload: (file: File) => data.upload(file),
}
