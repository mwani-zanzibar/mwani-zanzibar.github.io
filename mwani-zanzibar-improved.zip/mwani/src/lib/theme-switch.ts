import { flushSync } from 'react-dom'
import { reducedMotion } from './perf'

export type ThemeChoice = 'light' | 'dark' | 'system'

type VTDoc = Document & { startViewTransition?: (cb: () => void) => { finished: Promise<void> } }

/**
 * Change the theme. When the page actually changes colour, the new theme opens
 * as a circle from the control that was pressed (View Transitions API), and
 * falls back to an instant switch where that isn't supported.
 */
export function switchTheme(choice: ThemeChoice, setTheme: (t: string) => void, from?: Element | null) {
  const root = document.documentElement
  const dark = choice === 'dark' || (choice === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)
  const apply = () => {
    flushSync(() => setTheme(choice))
    root.classList.toggle('dark', dark)
    root.classList.toggle('light', !dark)
    root.style.colorScheme = dark ? 'dark' : 'light'
  }
  const doc = document as VTDoc
  if (root.classList.contains('dark') === dark || !doc.startViewTransition || reducedMotion()) { apply(); return }
  const r = from?.getBoundingClientRect()
  const x = r ? r.left + r.width / 2 : window.innerWidth / 2
  const y = r ? r.top + r.height / 2 : 0
  const rad = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y))
  root.style.setProperty('--vt-x', `${x}px`)
  root.style.setProperty('--vt-y', `${y}px`)
  root.style.setProperty('--vt-r', `${Math.ceil(rad)}px`)
  doc.startViewTransition(apply)
}
