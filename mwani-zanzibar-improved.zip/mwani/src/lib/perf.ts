// Device tiers, so weaker phones get a lighter site.
//   0: prefers reduced motion. Final states only, no scrub, no 3D.
//   1: low-end (≤4 GB RAM, ≤4 cores, Save-Data or 2G). No 3D, no smooth scroll, no blur.
//   2: everything.
export type Tier = 0 | 1 | 2
let cached: Tier | null = null

export function reducedMotion(): boolean {
  return typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}
export function isTouch(): boolean {
  return typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches
}
export function getTier(): Tier {
  if (cached !== null) return cached
  if (typeof window === 'undefined') return 2
  if (reducedMotion()) return (cached = 0)
  const n = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean; effectiveType?: string } }
  const low = (n.deviceMemory !== undefined && n.deviceMemory <= 4) || (n.hardwareConcurrency !== undefined && n.hardwareConcurrency <= 4)
    || !!n.connection?.saveData || /2g/.test(n.connection?.effectiveType || '')
  return (cached = low ? 1 : 2)
}
export function webglOK(): boolean {
  if (typeof document === 'undefined') return false
  try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')) } catch { return false }
}
