// The "physical" add-to-bag from the reference video: the product image
// lifts out of its card, arcs up and over, and drops into whichever cart
// target is visible (desktop cart pill, mobile dock, or the nav bag).

import { reducedMotion } from './perf'

type Target = { el: HTMLElement; priority: number }
const targets = new Set<Target>()

export function registerCartTarget(el: HTMLElement, priority = 0) {
  const t = { el, priority }
  targets.add(t)
  return () => { targets.delete(t) }
}

function visibleTarget(): HTMLElement | null {
  const list = [...targets].filter(({ el }) => {
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el)
    return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' && r.bottom > 0 && r.top < window.innerHeight
  })
  list.sort((a, b) => b.priority - a.priority)
  return list[0]?.el ?? null
}

export function bumpCart() {
  const el = visibleTarget()
  el?.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.08)' }, { transform: 'scale(0.98)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(.22,1,.36,1)' })
  window.dispatchEvent(new CustomEvent('cart:landed'))
}

// Flies the image inside `from` to the cart. The source image dims while it
// is "out of the card" and settles back once it has landed.
export function flyToCart(from: HTMLElement | null, opts: { hideSource?: boolean } = {}) {
  if (typeof window === 'undefined' || !from) return
  const img = from.querySelector('img') as HTMLImageElement | null
  if (reducedMotion() || !img) { bumpCart(); return }
  // Wait a frame so a pill that appears for the first item has mounted.
  requestAnimationFrame(() => requestAnimationFrame(() => launch(from, img, opts)))
}

function launch(from: HTMLElement, img: HTMLImageElement, { hideSource = true }: { hideSource?: boolean }) {
  const target = visibleTarget()
  const a = img.getBoundingClientRect()
  if (!target || a.width === 0) { bumpCart(); return }
  const b = target.getBoundingClientRect()
  const size = Math.min(Math.max(a.width, a.height), 220)
  const sx = a.left + a.width / 2, sy = a.top + a.height / 2
  const tx = b.left + Math.min(b.width, 56) / 2 + 8, ty = b.top + b.height / 2
  const dx = tx - sx, dy = ty - sy
  const lift = Math.min(140, Math.max(70, Math.abs(dy) * 0.35))

  // Outer moves horizontally (ease-in-out), inner vertically in an arc, so the
  // path curves naturally without a motion-path plugin.
  const outer = document.createElement('div')
  const inner = document.createElement('div')
  const ghost = img.cloneNode(true) as HTMLImageElement
  ghost.removeAttribute('srcset'); ghost.removeAttribute('sizes'); ghost.removeAttribute('loading')
  Object.assign(outer.style, { position: 'fixed', left: `${sx - size / 2}px`, top: `${sy - size / 2}px`, width: `${size}px`, height: `${size}px`, zIndex: '9999', pointerEvents: 'none' })
  Object.assign(inner.style, { width: '100%', height: '100%' })
  Object.assign(ghost.style, { position: 'static', inset: 'auto', width: '100%', height: '100%', objectFit: 'contain', filter: 'drop-shadow(0 18px 24px rgb(31 7 14 / .28))', transformOrigin: '50% 50%' })
  inner.appendChild(ghost); outer.appendChild(inner); document.body.appendChild(outer)

  if (hideSource) img.animate([{ opacity: 1, filter: 'blur(0px)' }, { opacity: 0.08, filter: 'blur(6px)' }], { duration: 220, fill: 'forwards', easing: 'ease-out' })

  const D = 820
  outer.animate([{ transform: 'translateX(0)' }, { transform: `translateX(${dx}px)` }], { duration: D, easing: 'cubic-bezier(.45,0,.25,1)', fill: 'forwards' })
  inner.animate([
    { transform: 'translateY(0)', easing: 'cubic-bezier(.2,.7,.3,1)' },
    { transform: `translateY(${Math.min(0, dy) * 0.25 - lift}px)`, offset: 0.38, easing: 'cubic-bezier(.55,0,.8,.4)' },
    { transform: `translateY(${dy}px)` },
  ], { duration: D, fill: 'forwards' })
  const land = ghost.animate([
    { transform: 'scale(1) rotate(0deg)', opacity: 1 },
    { transform: 'scale(0.78) rotate(-8deg)', opacity: 1, offset: 0.4 },
    { transform: 'scale(0.16) rotate(6deg)', opacity: 0.85 },
  ], { duration: D, fill: 'forwards', easing: 'cubic-bezier(.4,0,.6,1)' })
  land.onfinish = () => {
    outer.remove()
    bumpCart()
    if (hideSource) {
      setTimeout(() => {
        img.animate([{ opacity: 0.08, filter: 'blur(6px)' }, { opacity: 1, filter: 'blur(0px)' }], { duration: 480, fill: 'forwards', easing: 'cubic-bezier(.22,1,.36,1)' })
          .onfinish = (e) => { (e.target as Animation).cancel() }
      }, 260)
    }
  }
}
