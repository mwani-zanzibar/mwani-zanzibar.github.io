// In-browser demo backend. Active while the Firebase config is not set. Data lives in localStorage on this device only, so
// the whole shop (browse, bag, checkout, tracking, admin) can be tried
// without a database. Admin password in demo mode: mwani-demo

import type { Backend, Row } from './backend'
import { SEED_PRODUCTS, SEED_RECIPES, SEED_PROMOS } from './seed-data'

const KEY = 'mwani-demo-db-v3'
const SESSION_KEY = 'mwani-demo-admin'
export const DEMO_ADMIN_PASSWORD = 'mwani-demo'

type Db = Record<string, Record<string, Record<string, unknown>>>

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')

function seed(): Db {
  const now = Date.now()
  const db: Db = { products: {}, recipes: {}, promoCodes: {}, settings: {}, reviews: {}, orders: {}, orderTracking: {}, sales: {}, newsletter: {}, restockLogs: {} }
  SEED_PRODUCTS.forEach((p, i) => {
    const at = new Date(now - i * 60_000).toISOString()
    db.products['p-' + slug(p.name)] = {
      ...p, featured: !!p.featured, slug: slug(p.name),
      benefits: JSON.stringify(p.benefits), ingredients: JSON.stringify(p.ingredients), gallery: JSON.stringify(p.gallery),
      createdAt: at, updatedAt: at,
    }
  })
  SEED_RECIPES.forEach((r, i) => {
    const at = new Date(now - i * 60_000).toISOString()
    db.recipes['r-' + slug(r.title)] = {
      ...r, featured: !!r.featured, slug: slug(r.title),
      ingredients: JSON.stringify(r.ingredients), steps: JSON.stringify(r.steps), createdAt: at, updatedAt: at,
    }
  })
  SEED_PROMOS.forEach((p) => { db.promoCodes[p.code] = { ...p, expiresAt: null, createdAt: new Date(now).toISOString() } })
  return db
}

let mem: Db | null = null

function load(): Db {
  if (mem) return mem
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(KEY) : null
    mem = raw ? (JSON.parse(raw) as Db) : seed()
  } catch {
    mem = seed()
  }
  return mem
}

function save() {
  try { localStorage.setItem(KEY, JSON.stringify(mem)) } catch { /* storage full or blocked: keep in memory */ }
}

const pause = () => new Promise((r) => setTimeout(r, 90))
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v))
const table = (col: string) => { const db = load(); return (db[col] ||= {}) }

export const demoBackend: Backend = {
  kind: 'demo',
  async list(col) {
    await pause()
    return Object.entries(table(col)).map(([id, d]) => ({ id, ...clone(d) }) as Row)
  },
  async where(col, filters) {
    const rows = await this.list(col)
    return rows.filter((r) => filters.every(([f, v]) => r[f] === v))
  },
  async get(col, id) {
    await pause()
    const d = table(col)[id]
    return d ? ({ id, ...clone(d) } as Row) : null
  },
  async add(col, data) {
    await pause()
    const id = Math.random().toString(36).slice(2, 12)
    table(col)[id] = clone(data)
    save()
    return id
  },
  async set(col, id, data) {
    await pause()
    table(col)[id] = clone(data)
    save()
  },
  async update(col, id, data) {
    await pause()
    const t = table(col)
    if (!t[id]) throw new Error('Not found')
    t[id] = { ...t[id], ...clone(data) }
    save()
  },
  async remove(col, id) {
    await pause()
    delete table(col)[id]
    save()
  },
  async login(email, password) {
    await pause()
    if (password !== DEMO_ADMIN_PASSWORD) throw new Error('Demo mode: the admin password is mwani-demo')
    try { sessionStorage.setItem(SESSION_KEY, email || 'demo') } catch { /* ignore */ }
    return { authenticated: true, admin: { id: 'demo', username: email || 'demo', name: 'Demo admin' } }
  },
  async logout() {
    try { sessionStorage.removeItem(SESSION_KEY) } catch { /* ignore */ }
  },
  async session() {
    let who: string | null = null
    try { who = sessionStorage.getItem(SESSION_KEY) } catch { /* ignore */ }
    return who ? { authenticated: true, admin: { id: 'demo', username: who, name: 'Demo admin' } } : { authenticated: false }
  },
}
