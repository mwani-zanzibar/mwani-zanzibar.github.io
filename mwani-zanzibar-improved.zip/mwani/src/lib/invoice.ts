import type { ApiOrder, ApiSettings } from '@/lib/api'
import { asset } from '@/lib/asset'
import { formatTZS, statusLabel, normalizePhone } from '@/lib/format'

const BRAND = {
  name: 'Mwani Zanzibar Seaweed',
  parent: 'Wakulima Hai Co-operative Society',
  tagline: 'Pure ocean goodness, harvested by Zanzibari women farmers.',
}

export function generateInvoiceHTML(order: ApiOrder, settings: ApiSettings | null): string {
  const date = new Date(order.createdAt)
  const itemsRows = order.items
    .map(
      (it, i) => `
        <tr>
          <td class="idx">${i + 1}</td>
          <td class="name">${it.name}<span class="unit">${it.unit}</span></td>
          <td class="num">${it.qty}</td>
          <td class="num">${formatTZS(it.price)}</td>
          <td class="num bold">${formatTZS(it.price * it.qty)}</td>
        </tr>`
    )
    .join('')

  const channelLabel =
    order.deliveryChannel === 'ferry'
      ? 'Azam Ferry (Mainland)'
      : order.deliveryChannel === 'pickup'
      ? 'Pickup in Zanzibar'
      : 'Local delivery — Zanzibar'

  const logoUrl =
    typeof window !== 'undefined' ? `${window.location.origin}${asset('/mwani-logo.png')}` : '/mwani-logo.png'
  const wakulimaUrl =
    typeof window !== 'undefined' ? `${window.location.origin}${asset('/wakulima-hai-logo.png')}` : '/wakulima-hai-logo.png'

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Invoice ${order.orderNumber} — ${BRAND.name}</title>
<style>
  @page { size: A4; margin: 16mm 14mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Plus Jakarta Sans', 'Inter', system-ui, -apple-system, sans-serif; color: #2a1a1f; margin: 0; padding: 24px; background: #fff; }
  .brand-row { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding-bottom: 18px; border-bottom: 2px solid #7a1f2b; }
  .brand { display: flex; align-items: center; gap: 12px; }
  .brand img { width: 56px; height: 56px; border-radius: 50%; object-fit: contain; border: 1px solid #e5d9d9; }
  .brand-name { font-family: 'Fraunces', Georgia, serif; font-size: 20px; font-weight: 800; color: #7a1f2b; line-height: 1.1; }
  .brand-sub { font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: #8a7272; }
  .invoice-badge { text-align: right; }
  .invoice-badge h1 { font-family: 'Fraunces', Georgia, serif; font-size: 28px; font-weight: 800; color: #7a1f2b; margin: 0; letter-spacing: 0.02em; }
  .invoice-badge .no { font-size: 12px; color: #6b5555; margin-top: 2px; }
  .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 24px; }
  .card { background: #faf6f3; border: 1px solid #ecdfdf; border-radius: 12px; padding: 14px 16px; }
  .card h3 { font-size: 10px; text-transform: uppercase; letter-spacing: 0.16em; color: #c2634a; margin: 0 0 8px; }
  .card p { margin: 2px 0; font-size: 12px; line-height: 1.5; }
  .card p.lbl { color: #8a7272; }
  .items { margin-top: 24px; width: 100%; border-collapse: collapse; }
  .items th { text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: 0.14em; color: #8a7272; padding: 8px 10px; border-bottom: 2px solid #7a1f2b; }
  .items th.num { text-align: right; }
  .items td { font-size: 12px; padding: 10px; border-bottom: 1px solid #f0e8e8; vertical-align: top; }
  .items td.num { text-align: right; }
  .items td.bold { font-weight: 700; color: #2a1a1f; }
  .items td.idx { text-align: center; width: 24px; color: #b8a0a0; }
  .items td.name { font-weight: 600; }
  .items td .unit { display: block; font-weight: 400; font-size: 10px; color: #8a7272; margin-top: 2px; }
  .totals { margin-top: 18px; margin-left: auto; width: 280px; }
  .totals .row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 12px; }
  .totals .row.discount { color: #2e8b57; }
  .totals .total { border-top: 2px solid #7a1f2b; margin-top: 6px; padding-top: 10px; font-family: 'Fraunces', Georgia, serif; font-size: 18px; font-weight: 800; color: #7a1f2b; }
  .status-row { display: flex; align-items: center; gap: 8px; margin-top: 18px; }
  .pill { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 999px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; }
  .pill.pending { background: #fef3c7; color: #92400e; }
  .pill.confirmed { background: #dbeafe; color: #1e40af; }
  .pill.processing { background: #cffafe; color: #155e75; }
  .pill.shipped, .pill.ready_for_pickup { background: #fde2e4; color: #7a1f2b; }
  .pill.delivered { background: #dcfce7; color: #166534; }
  .pill.cancelled { background: #fee2e2; color: #991b1b; }
  .pill.paid { background: #dcfce7; color: #166534; }
  .pill.unpaid { background: #fef3c7; color: #92400e; }
  .footer { margin-top: 36px; padding-top: 16px; border-top: 1px solid #ecdfdf; text-align: center; }
  .footer .tagline { font-family: 'Fraunces', Georgia, serif; font-style: italic; color: #7a1f2b; font-size: 12px; }
  .footer .contact { font-size: 11px; color: #8a7272; margin-top: 6px; line-height: 1.6; }
  .footer .logos { display: flex; justify-content: center; gap: 10px; margin-top: 12px; }
  .footer .logos img { width: 36px; height: 36px; border-radius: 50%; object-fit: contain; border: 1px solid #ecdfdf; }
  .thanks { font-family: 'Fraunces', Georgia, serif; font-size: 14px; color: #7a1f2b; font-style: italic; margin-top: 12px; text-align: center; }
  @media print { body { padding: 0; } .no-print { display: none !important; } }
  .toolbar { position: sticky; top: 0; background: #7a1f2b; color: #fff; padding: 10px 16px; display: flex; align-items: center; justify-content: space-between; border-radius: 10px; margin-bottom: 16px; }
  .toolbar button { background: #fff; color: #7a1f2b; border: none; padding: 8px 16px; border-radius: 8px; font-weight: 700; font-size: 12px; cursor: pointer; }
  .toolbar button:hover { background: #fde2e4; }
  .toolbar .orderno { font-family: monospace; font-weight: 700; }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <span>Invoice preview</span>
    <span class="orderno">${order.orderNumber}</span>
    <button onclick="window.print()">🖨 Print / Save PDF</button>
  </div>

  <div class="brand-row">
    <div class="brand">
      <img src="${logoUrl}" alt="Mwani Zanzibar Seaweed" />
      <div>
        <div class="brand-name">${settings?.shopName || BRAND.name}</div>
        <div class="brand-sub">${BRAND.parent}</div>
      </div>
    </div>
    <div class="invoice-badge">
      <h1>INVOICE</h1>
      <div class="no">${order.orderNumber}</div>
    </div>
  </div>

  <div class="meta-grid">
    <div class="card">
      <h3>Bill to</h3>
      <p style="font-weight:700;font-size:13px;">${order.customerName}</p>
      <p>${order.customerPhone}</p>
      <p>${order.customerLocation}</p>
      <p class="lbl">Delivery: ${channelLabel}</p>
      ${order.notes ? `<p class="lbl">Notes: ${order.notes}</p>` : ''}
    </div>
    <div class="card">
      <h3>Order details</h3>
      <p><span class="lbl">Date:</span> ${date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</p>
      <p><span class="lbl">Time:</span> ${date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</p>
      <p><span class="lbl">Payment:</span> <span class="pill ${order.paymentStatus}" style="padding:2px 8px;">${order.paymentStatus}</span></p>
      <p><span class="lbl">Status:</span> <span class="pill ${order.status}" style="padding:2px 8px;">${statusLabel(order.status)}</span></p>
    </div>
  </div>

  <table class="items">
    <thead>
      <tr>
        <th>#</th>
        <th>Item</th>
        <th class="num">Qty</th>
        <th class="num">Unit Price</th>
        <th class="num">Amount</th>
      </tr>
    </thead>
    <tbody>
      ${itemsRows}
    </tbody>
  </table>

  <div class="totals">
    <div class="row"><span>Subtotal</span><span>${formatTZS(order.subtotal)}</span></div>
    <div class="row"><span>Shipping</span><span>${order.shipping > 0 ? formatTZS(order.shipping) : '—'}</span></div>
    ${order.discount > 0 ? `<div class="row discount"><span>Discount (${order.promoCode})</span><span>−${formatTZS(order.discount)}</span></div>` : ''}
    <div class="row total"><span>Total</span><span>${formatTZS(order.total)}</span></div>
  </div>

  <div class="status-row no-print">
    <span style="font-size:11px;color:#8a7272;">Status:</span>
    <span class="pill ${order.status}">${statusLabel(order.status)}</span>
    <span class="pill ${order.paymentStatus}">${order.paymentStatus}</span>
  </div>

  <div class="thanks">Asante sana for your order, ${order.customerName.split(' ')[0]}! 🌊</div>

  <div class="footer">
    <div class="tagline">${settings?.tagline || BRAND.tagline}</div>
    <div class="contact">
      ${settings?.phonePrimary || '+255 774 870 703'} · ${settings?.email || 'Info@Wakulimahai.org'}<br/>
      ${settings?.address || 'P.O.Box 3943, Mbwenibotanga, Zanzibar'} · ${settings?.website || 'www.wakulimahai.org'}
    </div>
    <div class="logos">
      <img src="${logoUrl}" alt="Mwani" />
      <img src="${wakulimaUrl}" alt="Wakulima Hai" />
    </div>
    <div style="font-size:10px;color:#b8a0a0;margin-top:8px;">Keep Zanzibar green · © ${date.getFullYear()} ${BRAND.parent}</div>
  </div>

  <script>
    // auto-open print dialog after load
    window.addEventListener('load', function() { setTimeout(function(){ window.print(); }, 400); });
  </script>
</body>
</html>`
}

export function openInvoice(order: ApiOrder, settings: ApiSettings | null) {
  const html = generateInvoiceHTML(order, settings)
  const w = window.open('', '_blank', 'width=820,height=1000')
  if (!w) {
    alert('Please allow pop-ups to view the invoice.')
    return
  }
  w.document.open()
  w.document.write(html)
  w.document.close()
}
