// ─────────────────────────────────────────────────────────
// FIREBASE CONNECTION
// ─────────────────────────────────────────────────────────
// The shop's own project (mwanizanzi) is filled in below, so GitHub Pages
// needs no extra setting. To point a copy at a different project instead,
// paste the whole config snippet Firebase shows you
//   const firebaseConfig = { apiKey: "...", authDomain: "...", ... };
// into ONE GitHub repository variable called FIREBASE_CONFIG
// (see DEPLOYMENT.md). The build passes it in as NEXT_PUBLIC_FIREBASE_CONFIG.
// The six separate NEXT_PUBLIC_FIREBASE_* variables also work.
//
// These values are public by design; security comes from firestore.rules.
//
// ─────────────────────────────────────────────────────────

// Mwani Zanzibar's Firebase project (public web config).
const MWANI = {
  apiKey: 'AIzaSyBu_Sbu4ATBYQ2-Eqf0_XgcI73kHZtDFFs',
  authDomain: 'mwanizanzi.firebaseapp.com',
  projectId: 'mwanizanzi',
  storageBucket: 'mwanizanzi.firebasestorage.app',
  messagingSenderId: '915276150549',
  appId: '1:915276150549:web:aa0938142a2e233d485b1c',
}

const blob = process.env.NEXT_PUBLIC_FIREBASE_CONFIG || ''
// Reads `key: "value"` (or "key": "value") out of the pasted snippet.
const pick = (key: string) => blob.match(new RegExp(`["']?${key}["']?\\s*:\\s*["']([^"']+)["']`))?.[1] || ''

export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || pick('apiKey') || MWANI.apiKey,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || pick('authDomain') || MWANI.authDomain,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || pick('projectId') || MWANI.projectId,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || pick('storageBucket') || MWANI.storageBucket,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || pick('messagingSenderId') || MWANI.messagingSenderId,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || pick('appId') || MWANI.appId,
}

// NEXT_PUBLIC_DEMO=1 forces the in-browser demo (used by the design preview).
export const isFirebaseConfigured = process.env.NEXT_PUBLIC_DEMO !== '1' && !!firebaseConfig.apiKey && !!firebaseConfig.projectId
