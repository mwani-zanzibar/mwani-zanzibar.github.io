'use client'

import { createElement, useRef } from 'react'
import { gsap, SplitText, useGSAP } from '@/lib/gsap'
import { reducedMotion } from '@/lib/perf'
import { cn } from '@/lib/utils'

type Tag = 'h1' | 'h2' | 'h3' | 'p' | 'span' | 'div'

// Headline that rises line by line from behind its own mask (GSAP SplitText).
// Re-splits on resize and late font loads. Content stays plain text for
// screen readers; reduced motion shows it still.
export function SplitReveal({
  as = 'h2', text, className, delay = 0, stagger = 0.09, immediate = false, start = 'top 86%', by = 'lines',
}: { as?: Tag; text: string; className?: string; delay?: number; stagger?: number; immediate?: boolean; start?: string; by?: 'lines' | 'words' }) {
  const ref = useRef<HTMLElement>(null)
  useGSAP(() => {
    const el = ref.current
    if (!el) return
    if (reducedMotion()) { el.classList.add('is-split'); return }
    SplitText.create(el, {
      type: by === 'words' ? 'lines,words' : 'lines',
      mask: 'lines',
      linesClass: 'split-line',
      autoSplit: true,
      onSplit(self) {
        el.classList.add('is-split')
        return gsap.from(by === 'words' ? self.words : self.lines, {
          yPercent: 115,
          rotate: 2.5,
          transformOrigin: '0% 100%',
          duration: 1.05,
          ease: 'expo.out',
          stagger,
          delay,
          scrollTrigger: immediate ? undefined : { trigger: el, start, once: true },
        })
      },
    })
  }, { scope: ref, dependencies: [text] })
  return createElement(as, { ref, key: text, className: cn('split-reveal', className), 'data-split': '' }, text)
}
