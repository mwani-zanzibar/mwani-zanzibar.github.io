'use client'

import { motion, useReducedMotion } from 'framer-motion'
import { cn } from '@/lib/utils'

// Odometer-style number: each digit column rolls to its new value.
export function NumberRoll({ value, className }: { value: string; className?: string }) {
  const reduce = useReducedMotion()
  const chars = value.split('')
  let digitIndex = chars.filter((c) => /\d/.test(c)).length
  return (
    <span className={cn('tabular inline-flex overflow-hidden leading-none', className)} aria-label={value}>
      {chars.map((c, i) => {
        if (!/\d/.test(c)) return <span key={`s${i}-${c}`} aria-hidden className="whitespace-pre">{c}</span>
        const key = `d${digitIndex--}` // keyed from the right so columns persist as numbers grow
        const d = Number(c)
        return (
          <span key={key} aria-hidden className="relative inline-block h-[1em] overflow-hidden" style={{ width: '0.62em' }}>
            <motion.span
              className="absolute inset-x-0 top-0 flex flex-col items-center"
              initial={false}
              animate={{ y: `${-d * 10}%` }}
              transition={reduce ? { duration: 0 } : { type: 'spring', stiffness: 260, damping: 28, mass: 0.7 }}
            >
              {Array.from({ length: 10 }).map((_, n) => <span key={n} className="block h-[1em] leading-none">{n}</span>)}
            </motion.span>
          </span>
        )
      })}
    </span>
  )
}
