'use client'

import { useEffect } from 'react'
import Lenis from 'lenis'
import { gsap, ScrollTrigger } from '@/lib/gsap'
import { getTier, isTouch } from '@/lib/perf'

declare global { interface Window { __lenis?: Lenis } }

// Smooth scrolling on capable desktops only; phones keep native scroll.
// Also keeps ScrollTrigger measurements right after fonts and images load.
export function SmoothScroll() {
  useEffect(() => {
    let refreshT = 0
    const refresh = () => { clearTimeout(refreshT); refreshT = window.setTimeout(() => ScrollTrigger.refresh(), 150) }
    document.fonts?.ready.then(refresh)
    window.addEventListener('load', refresh)
    const onImg = (e: Event) => { if ((e.target as HTMLElement)?.tagName === 'IMG') refresh() }
    document.addEventListener('load', onImg, true)

    let lenis: Lenis | undefined
    let tick: ((t: number) => void) | undefined
    let mo: MutationObserver | undefined
    if (getTier() === 2 && !isTouch()) {
      lenis = new Lenis({
        lerp: 0.1,
        wheelMultiplier: 1,
        anchors: { offset: -84 },
        prevent: (node: HTMLElement) => !!node.closest?.('[role="dialog"], [data-lenis-prevent], [data-vaul-drawer]'),
      })
      window.__lenis = lenis
      lenis.on('scroll', ScrollTrigger.update)
      tick = (t: number) => lenis!.raf(t * 1000)
      gsap.ticker.add(tick)
      gsap.ticker.lagSmoothing(0)
      // Pause while a dialog or sheet has locked the page.
      mo = new MutationObserver(() => {
        const b = document.body
        const locked = b.hasAttribute('data-scroll-locked') || b.style.overflow === 'hidden'
        if (locked) lenis!.stop(); else lenis!.start()
      })
      mo.observe(document.body, { attributes: true, attributeFilter: ['style', 'data-scroll-locked'] })
    }
    return () => {
      clearTimeout(refreshT)
      window.removeEventListener('load', refresh)
      document.removeEventListener('load', onImg, true)
      mo?.disconnect()
      if (tick) gsap.ticker.remove(tick)
      lenis?.destroy()
      window.__lenis = undefined
    }
  }, [])
  return null
}

export function scrollToId(id: string, offset = -84) {
  const el = document.getElementById(id)
  if (!el) return
  if (window.__lenis) window.__lenis.scrollTo(el, { offset, duration: 1.1 })
  else window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY + offset, behavior: 'smooth' })
}
