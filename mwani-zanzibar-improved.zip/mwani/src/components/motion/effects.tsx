'use client'

// Small, distinct interaction effects used across the storefront. Each one
// answers something the visitor did, stays short, and switches off for
// reduced motion. Pointer-driven ones only run with a real mouse.

import { useEffect, useRef, useState, type ReactNode } from 'react'
import { AnimatePresence, motion, useMotionValue, useReducedMotion, useScroll, useSpring, useTransform } from 'framer-motion'
import { ArrowUp } from 'lucide-react'
import { getTier, isTouch } from '@/lib/perf'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { cn } from '@/lib/utils'

const finePointer = () => typeof window !== 'undefined' && !isTouch() && getTier() === 2

/** Primary buttons lean towards the cursor a little, then spring back. */
export function Magnetic({ children, strength = 0.28, className }: { children: ReactNode; strength?: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const x = useMotionValue(0), y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 260, damping: 18, mass: 0.4 }), sy = useSpring(y, { stiffness: 260, damping: 18, mass: 0.4 })
  const [on, setOn] = useState(false)
  useEffect(() => setOn(finePointer()), [])
  const move = (e: React.PointerEvent) => {
    if (!on || e.pointerType !== 'mouse' || !ref.current) return
    const r = ref.current.getBoundingClientRect()
    x.set((e.clientX - (r.left + r.width / 2)) * strength)
    y.set((e.clientY - (r.top + r.height / 2)) * strength)
  }
  const leave = () => { x.set(0); y.set(0) }
  return (
    <motion.span ref={ref} onPointerMove={move} onPointerLeave={leave} style={on ? { x: sx, y: sy } : undefined} className={cn('inline-flex', className)}>
      {children}
    </motion.span>
  )
}

type Bubble = { id: number; x: number; size: number; delay: number; drift: number; rise: number; hue: string }
const HUES = ['var(--lagoon)', 'var(--surface)', 'var(--rose)', 'var(--lagoon)']

/**
 * A short burst of bubbles that rise and pop. Change `fire` (any number) to
 * trigger a new burst; the burst cleans itself up.
 */
export function BubbleBurst({ fire, count = 12, className, spread = 70 }: { fire: number; count?: number; className?: string; spread?: number }) {
  const reduce = useReducedMotion()
  const [bursts, setBursts] = useState<{ key: number; bubbles: Bubble[] }[]>([])
  const first = useRef(true)
  useEffect(() => {
    if (first.current) { first.current = false; return }
    if (reduce || getTier() === 0) return
    const n = getTier() === 1 ? Math.ceil(count / 2) : count
    const bubbles = Array.from({ length: n }, (_, i) => ({
      id: i,
      x: 50 + (Math.random() - 0.5) * spread,
      size: 6 + Math.random() * 14,
      delay: Math.random() * 0.25,
      drift: (Math.random() - 0.5) * 40,
      rise: 160 + Math.random() * 140,
      hue: HUES[i % HUES.length],
    }))
    const key = fire
    setBursts((b) => [...b.slice(-1), { key, bubbles }])
    const id = window.setTimeout(() => setBursts((b) => b.filter((x) => x.key !== key)), 1800)
    return () => clearTimeout(id)
  }, [fire, count, spread, reduce])
  return (
    <span aria-hidden className={cn('pointer-events-none absolute inset-0 overflow-visible', className)}>
      {bursts.map((b) => b.bubbles.map((bb) => (
        <motion.span
          key={`${b.key}-${bb.id}`}
          className="absolute bottom-[18%] rounded-full border border-[var(--hairline)]"
          style={{ left: `${bb.x}%`, width: bb.size, height: bb.size, background: `radial-gradient(circle at 32% 30%, rgb(255 255 255 / 0.9), ${bb.hue} 55%, transparent 72%)` }}
          initial={{ y: 0, x: 0, opacity: 0, scale: 0.4 }}
          animate={{ y: -bb.rise, x: bb.drift, opacity: [0, 0.95, 0.9, 0], scale: [0.4, 1, 1, 1.35] }}
          transition={{ duration: 1.35, delay: bb.delay, ease: [0.22, 1, 0.36, 1], times: [0, 0.2, 0.8, 1] }}
        />
      )))}
    </span>
  )
}

/** "+1" that floats off a button when something is added. */
export function PlusOne({ fire, label = '+1', className }: { fire: number; label?: string; className?: string }) {
  const reduce = useReducedMotion()
  return (
    <span aria-hidden className={cn('pointer-events-none absolute inset-x-0 -top-1 flex justify-center', className)}>
      <AnimatePresence>
        {fire > 0 && !reduce && (
          <motion.span key={fire} className="tabular rounded-full bg-lagoon-deep px-2 py-0.5 text-[0.75rem] font-bold text-white shadow-1"
            initial={{ y: 4, opacity: 0, scale: 0.6 }}
            animate={{ y: -30, opacity: [0, 1, 1, 0], scale: 1 }}
            transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], times: [0, 0.15, 0.7, 1] }}
          >
            {label}
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  )
}

/**
 * Desktop: a round "back to top" button whose ring fills as you read down the
 * page. Appears after the first screen.
 */
export function ScrollTopRing({ label = 'Back to top' }: { label?: string }) {
  const { scrollYProgress, scrollY } = useScroll()
  const ring = useSpring(scrollYProgress, { stiffness: 140, damping: 28, mass: 0.4 })
  const dash = useTransform(ring, (v) => 125.66 * (1 - v))
  const [show, setShow] = useState(false)
  useEffect(() => scrollY.on('change', (y) => setShow(y > window.innerHeight * 0.9)), [scrollY])
  return (
    <AnimatePresence>
      {show && (
        <motion.button
          type="button"
          onClick={() => scrollToId('top', 0)}
          aria-label={label}
          className="group fixed bottom-6 left-6 z-[54] hidden h-14 w-14 place-items-center rounded-full bg-surface text-plum shadow-3 md:grid"
          initial={{ opacity: 0, scale: 0.6, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.6, y: 20 }}
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.94 }}
          transition={{ type: 'spring', stiffness: 420, damping: 26 }}
        >
          <svg viewBox="0 0 48 48" className="absolute inset-1 -rotate-90" aria-hidden>
            <circle cx="24" cy="24" r="20" fill="none" stroke="currentColor" strokeOpacity="0.12" strokeWidth="2.5" />
            <motion.circle cx="24" cy="24" r="20" fill="none" stroke="var(--coral)" strokeWidth="2.5" strokeLinecap="round" strokeDasharray="125.66" style={{ strokeDashoffset: dash }} />
          </svg>
          <ArrowUp className="relative h-5 w-5 transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-translate-y-0.5" aria-hidden />
        </motion.button>
      )}
    </AnimatePresence>
  )
}

/**
 * Pointer tilt for cards: returns motion values and handlers. The card turns a
 * few degrees towards the cursor and a soft light follows it (via CSS vars).
 */
export function useTilt(max = 5) {
  const rx = useMotionValue(0), ry = useMotionValue(0)
  const srx = useSpring(rx, { stiffness: 220, damping: 20 }), sry = useSpring(ry, { stiffness: 220, damping: 20 })
  const [on, setOn] = useState(false)
  useEffect(() => setOn(finePointer()), [])
  const onPointerMove = (e: React.PointerEvent<HTMLElement>) => {
    if (!on || e.pointerType !== 'mouse') return
    const el = e.currentTarget, r = el.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height
    ry.set((px - 0.5) * 2 * max); rx.set(-(py - 0.5) * 2 * max)
    el.style.setProperty('--mx', `${px * 100}%`); el.style.setProperty('--my', `${py * 100}%`)
  }
  const onPointerLeave = () => { rx.set(0); ry.set(0) }
  return { on, style: on ? { rotateX: srx, rotateY: sry, transformPerspective: 900 } : undefined, onPointerMove, onPointerLeave }
}
