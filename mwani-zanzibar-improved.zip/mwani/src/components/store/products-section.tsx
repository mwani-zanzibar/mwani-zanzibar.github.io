'use client'

import { useDeferredValue, useEffect, useMemo, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, LayoutGroup, motion, useReducedMotion } from 'framer-motion'
import { ChevronDown, Search, X } from 'lucide-react'
import { ProductCard } from '@/components/store/product-card'
import { SplitReveal } from '@/components/motion/split-reveal'
import { NumberRoll } from '@/components/motion/number-roll'
import { Reveal, EASE_OUT, SPRING_SNAPPY } from '@/components/shared/reveal'
import { useI18n } from '@/lib/i18n'
import type { ApiProduct } from '@/lib/api'
import { cn } from '@/lib/utils'
import { useImg } from '@/lib/content-store'

export const CAT_SW: Record<string, string> = {
  'Food & Beverage': 'Chakula na vinywaji',
  'Health & Wellness': 'Afya',
  'Skin Care': 'Ngozi',
  'Hair Care': 'Nywele',
}
const CAT_ORDER = ['Food & Beverage', 'Health & Wellness', 'Skin Care', 'Hair Care']
const rank = (c: string) => { const i = CAT_ORDER.indexOf(c); return i < 0 ? 99 : i }

type Sort = 'featured' | 'priceAsc' | 'priceDesc' | 'name'
const LAYOUT_SPRING = { type: 'spring', stiffness: 380, damping: 34 } as const

export function ProductsSection({ products, loading, category, setCategory }: {
  products: ApiProduct[]; loading: boolean; category: string; setCategory: (c: string) => void
}) {
  const markSrc = useImg('brand.mark', '/brand/mwani-mark.png')
  const { t, lang } = useI18n()
  const reduce = useReducedMotion()
  const [q, setQ] = useState('')
  const [sort, setSort] = useState<Sort>('featured')
  const query = useDeferredValue(q.trim())
  const catLabel = (c: string) => (c === 'all' ? t('shop.all') : lang === 'sw' ? CAT_SW[c] || c : c)

  const cats = useMemo(() => {
    const m = new Map<string, number>()
    for (const p of products) m.set(p.category, (m.get(p.category) || 0) + 1)
    return [...m.entries()].sort((a, b) => rank(a[0]) - rank(b[0]))
  }, [products])

  const list = useMemo(() => {
    let l = category === 'all' ? products : products.filter((p) => p.category === category)
    const s = query.toLowerCase()
    if (s) l = l.filter((p) => `${p.name} ${p.tagline} ${p.description} ${p.category} ${CAT_SW[p.category] || ''} ${p.unit}`.toLowerCase().includes(s))
    l = [...l]
    const stock = (p: ApiProduct) => Number(p.stock > 0)
    if (sort === 'priceAsc') l.sort((a, b) => stock(b) - stock(a) || a.price - b.price)
    else if (sort === 'priceDesc') l.sort((a, b) => stock(b) - stock(a) || b.price - a.price)
    else if (sort === 'name') l.sort((a, b) => a.name.localeCompare(b.name))
    // Recommended: featured first, then in stock (sold out always last).
    else l.sort((a, b) => stock(b) - stock(a) || Number(b.featured) - Number(a.featured))
    return l
  }, [products, category, query, sort])

  // Keep the active chip in view on phones (e.g. after picking a range).
  const rowRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const row = rowRef.current
    const chip = row?.querySelector<HTMLElement>('[aria-pressed="true"]')
    if (!row || !chip || row.scrollWidth <= row.clientWidth) return
    row.scrollTo({ left: chip.offsetLeft - row.clientWidth / 2 + chip.offsetWidth / 2, behavior: reduce ? 'auto' : 'smooth' })
  }, [category, cats.length, reduce])

  const filtered = category !== 'all' || !!query
  const clear = () => { setQ(''); setCategory('all') }

  return (
    <section id="shop" className="mx-auto max-w-[88rem] scroll-mt-24 px-5 pt-14 sm:px-8 sm:pt-20 lg:px-12">
      <div className="flex flex-wrap items-end justify-between gap-x-10 gap-y-5">
        <div className="max-w-2xl">
          <SplitReveal as="h2" text={t('shop.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-none text-plum" />
          <Reveal delay={0.1}>
            <p className="mt-4 max-w-md text-[1.02rem] text-foreground/70">{t('shop.sub')}</p>
          </Reveal>
        </div>
        {!loading && (
          <Reveal delay={0.15}>
            <p className="flex items-baseline gap-2 text-plum">
              <NumberRoll value={String(list.length)} className="font-display text-[2.6rem]" />
              <span className="text-[0.95rem] text-muted-foreground">{list.length === 1 ? t('shop.product') : t('shop.products')}</span>
            </p>
          </Reveal>
        )}
      </div>
      <p className="sr-only" aria-live="polite">{loading ? '' : t('shop.results', { n: list.length })}</p>

      {/* Filter bar: deliberately not sticky, so it never covers products on phones. */}
      <Reveal delay={0.1} className="mt-9 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between lg:gap-6">
        <LayoutGroup id="shop-chips">
          <div
            ref={rowRef}
            role="group"
            aria-label={t('shop.filterLabel')}
            className="no-scrollbar -mx-5 -my-2 flex gap-2 overflow-x-auto px-5 py-2 sm:-mx-8 sm:px-8 lg:mx-0 lg:flex-wrap lg:overflow-visible lg:px-0"
          >
            {[['all', products.length] as const, ...cats].map(([c, n]) => {
              const active = category === c
              return (
                <button
                  key={c}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setCategory(c)}
                  className={cn(
                    'press relative flex h-10 shrink-0 items-center gap-2 rounded-full px-4 text-[0.88rem] font-medium after:absolute after:inset-x-0 after:-inset-y-0.5 after:content-[\'\']',
                    active ? 'text-porcelain' : 'bg-surface text-plum shadow-1 hover:bg-shell',
                  )}
                >
                  {active && (
                    <motion.span layoutId="shop-chip-active" transition={SPRING_SNAPPY} className="absolute inset-0 rounded-full bg-plum shadow-2" aria-hidden />
                  )}
                  <span className="relative whitespace-nowrap">{catLabel(c)}</span>
                  {!loading && (
                    <span className={cn('tabular relative text-[0.76rem] font-semibold transition-colors duration-200', active ? 'text-porcelain/65' : 'text-plum/45')}>{n}</span>
                  )}
                </button>
              )
            })}
          </div>
        </LayoutGroup>

        <div className="flex gap-2 lg:w-[27rem] lg:shrink-0">
          <label className="relative min-w-0 flex-1">
            <span className="sr-only">{t('shop.search')}</span>
            <Search className="pointer-events-none absolute left-4 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-plum/55" aria-hidden />
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Escape' && q) { e.stopPropagation(); setQ('') } }}
              placeholder={t('shop.search')}
              enterKeyHint="search"
              className="h-12 w-full rounded-full bg-surface pl-11 pr-10 text-[0.95rem] text-foreground shadow-1 outline-none transition-shadow duration-200 placeholder:text-foreground/45 focus-visible:outline-none focus:ring-2 focus:ring-plum [&::-webkit-search-cancel-button]:hidden"
            />
            <AnimatePresence>
              {q && (
                <motion.button
                  type="button"
                  onClick={() => setQ('')}
                  aria-label={t('shop.clearSearch')}
                  initial={{ opacity: 0, scale: 0.6 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.6 }}
                  transition={{ duration: 0.18, ease: EASE_OUT }}
                  className="absolute right-0.5 top-0.5 grid h-11 w-11 place-items-center rounded-full"
                >
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-shell text-plum transition-colors duration-150 hover:bg-sand">
                    <X className="h-3.5 w-3.5" strokeWidth={2.5} aria-hidden />
                  </span>
                </motion.button>
              )}
            </AnimatePresence>
          </label>
          <label className="relative shrink-0">
            <span className="sr-only">{t('shop.sort')}</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as Sort)}
              className="h-12 max-w-[10rem] appearance-none truncate rounded-full bg-surface pl-3.5 pr-9 text-[0.88rem] sm:pl-4 sm:pr-10 sm:text-[0.92rem] font-medium text-plum shadow-1 outline-none focus-visible:outline-none focus:ring-2 focus:ring-plum sm:max-w-none"
            >
              <option value="featured">{t('shop.sort.featured')}</option>
              <option value="priceAsc">{t('shop.sort.priceAsc')}</option>
              <option value="priceDesc">{t('shop.sort.priceDesc')}</option>
              <option value="name">{t('shop.sort.name')}</option>
            </select>
            <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-plum/60" aria-hidden />
          </label>
        </div>
      </Reveal>

      {/* Removable summary chips (N99). */}
      <AnimatePresence initial={false}>
        {filtered && (
          <motion.div
            key="summary"
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6, transition: { duration: 0.16 } }}
            transition={{ duration: 0.22, ease: EASE_OUT }}
            className="mt-4 flex flex-wrap items-center gap-2"
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {category !== 'all' && (
                <SummaryChip key="cat" label={catLabel(category)} aria={t('shop.removeFilter', { x: catLabel(category) })} onRemove={() => setCategory('all')} />
              )}
              {query && (
                <SummaryChip key="q" label={`“${query}”`} aria={t('shop.removeFilter', { x: query })} onRemove={() => setQ('')} />
              )}
              <motion.button
                key="clear"
                layout
                type="button"
                onClick={clear}
                transition={{ layout: SPRING_SNAPPY }}
                className="link-draw ml-1 h-9 text-[0.88rem] font-medium text-plum"
              >
                {t('shop.clearAll')}
              </motion.button>
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-7 pb-4 sm:mt-9">
        {loading ? (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4 lg:grid-cols-4 lg:gap-5" aria-busy>
            {Array.from({ length: 8 }).map((_, n) => <SkeletonCard key={n} />)}
          </div>
        ) : list.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: EASE_OUT }}
            className="mx-auto flex max-w-lg flex-col items-center rounded-[28px] bg-surface px-6 py-12 text-center shadow-2"
          >
            <span className="relative grid h-20 w-20 place-items-center rounded-full bg-shell">
              <Image src={markSrc} alt="" width={48} height={48} className="h-12 w-12 object-contain" />
            </span>
            <p className="mt-5 font-display text-[1.7rem] leading-tight text-plum">
              {query ? t('shop.emptyQ', { q: query }) : t('shop.empty')}
            </p>
            <p className="mt-2 max-w-xs text-foreground/65">{t('shop.emptyBody')}</p>
            <button type="button" onClick={clear} className="press mt-6 h-12 rounded-full bg-plum px-6 text-[0.95rem] font-semibold text-porcelain hover:bg-plum-2">
              {t('shop.clearFilters')}
            </button>
          </motion.div>
        ) : (
          <div className="relative grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-4 lg:grid-cols-4 lg:gap-5">
            <AnimatePresence mode="popLayout">
              {list.map((p, i) => (
                <motion.div
                  key={p.id}
                  layout={!reduce}
                  initial={reduce ? false : { opacity: 0, y: 28, scale: 0.97 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true, margin: '0px 0px -6% 0px' }}
                  exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.18, ease: EASE_OUT } }}
                  transition={{ duration: 0.7, ease: EASE_OUT, delay: (i % 4) * 0.06, layout: LAYOUT_SPRING }}
                  className="min-w-0"
                >
                  <ProductCard product={p} priority={i < 4} hint={i === 0} />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </section>
  )
}

function SummaryChip({ label, aria, onRemove, ref }: { label: string; aria: string; onRemove: () => void; ref?: React.Ref<HTMLSpanElement> }) {
  return (
    <motion.span
      ref={ref}
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
      transition={{ duration: 0.22, ease: EASE_OUT, layout: SPRING_SNAPPY }}
      className="flex h-9 items-center gap-1 rounded-full bg-shell pl-3.5 pr-0.5 text-[0.86rem] font-medium text-plum"
    >
      <span className="max-w-[14rem] truncate">{label}</span>
      <button type="button" onClick={onRemove} aria-label={aria} className="grid h-11 w-9 place-items-center">
        <span className="grid h-7 w-7 place-items-center rounded-full bg-surface/80 transition-colors duration-150 hover:bg-surface">
          <X className="h-3.5 w-3.5" strokeWidth={2.5} aria-hidden />
        </span>
      </button>
    </motion.span>
  )
}

function SkeletonCard() {
  return (
    <div className="rounded-[28px] bg-surface p-2 shadow-2">
      <div className="shimmer aspect-square rounded-[22px]" />
      <div className="px-2 pb-2 pt-3">
        <div className="shimmer h-4 w-4/5 rounded-full" />
        <div className="shimmer mt-2 h-3 w-2/5 rounded-full" />
        <div className="mt-5 flex items-center justify-between">
          <div className="shimmer h-4 w-1/3 rounded-full" />
          <div className="shimmer h-11 w-11 rounded-full md:w-20" />
        </div>
      </div>
    </div>
  )
}
