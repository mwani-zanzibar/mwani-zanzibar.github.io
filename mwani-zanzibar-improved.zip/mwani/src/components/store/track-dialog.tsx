'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion, useReducedMotion } from 'framer-motion'
import {
  AlertCircle, CalendarClock, Check, CheckCircle2, Clock, FileText, Loader2, Package, Search, Ship, Store, Truck, XCircle,
} from 'lucide-react'
import { ResponsiveSheet, useIsDesktop } from '@/components/store/overlay-shell'
import { EASE_OUT } from '@/components/shared/reveal'
import { api, type ApiOrder } from '@/lib/api'
import { deliveryEta, formatTZS, statusLabel, statusOrder } from '@/lib/format'
import { openInvoice } from '@/lib/invoice'
import { useI18n } from '@/lib/i18n'
import { useUI } from '@/lib/ui-store'
import { cn } from '@/lib/utils'

/* ───────────── shared helpers (also used by my-orders-dialog) ───────────── */

// statusOrder() lists both "shipped via Azam" and "ready for pickup"; each
// order only ever passes through the one that matches its delivery channel.
export function orderSteps(channel: string, status: string): string[] {
  return statusOrder().filter((s) => {
    if (s === status) return true
    if (s === 'shipped') return channel === 'ferry'
    if (s === 'ready_for_pickup') return channel === 'pickup'
    return true
  })
}

export function useStatusText() {
  const { t } = useI18n()
  return (status: string) => {
    const k = `track.status.${status}`
    const v = t(k)
    return v === k ? statusLabel(status) : v
  }
}

export function StatusChip({ status, className }: { status: string; className?: string }) {
  const label = useStatusText()(status)
  const tone =
    status === 'cancelled' ? 'bg-destructive/10 text-destructive'
      : status === 'delivered' || status === 'ready_for_pickup' ? 'bg-lagoon-deep/10 text-lagoon-deep'
        : status === 'pending' ? 'bg-amber-100 text-amber-900'
          : 'bg-plum/[0.08] text-plum'
  return (
    <span className={cn('inline-flex h-8 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-3 text-[0.84rem] font-semibold', tone, className)}>
      <span aria-hidden className="h-1.5 w-1.5 rounded-full bg-current" />
      {label}
    </span>
  )
}

/* ─────────────────────────────── dialog ─────────────────────────────── */

export function TrackDialog() {
  const open = useUI((s) => s.trackOpen)
  const preset = useUI((s) => s.trackPreset)
  const setOpen = useUI((s) => s.setTrackOpen)
  const { t } = useI18n()
  const desktop = useIsDesktop()

  const [orderNumber, setOrderNumber] = useState('')
  const [order, setOrder] = useState<ApiOrder | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const seq = useRef(0)

  const lookup = async (raw: string) => {
    const n = raw.trim().toUpperCase()
    if (!n) { setError(t('track.enterOrder')); setOrder(null); inputRef.current?.focus(); return }
    const mine = ++seq.current
    setLoading(true); setError(''); setOrder(null)
    try {
      const r = await api.track(n)
      if (mine === seq.current) setOrder(r.order)
    } catch (e) {
      if (mine !== seq.current) return
      const msg = (e as Error).message || ''
      setError(msg.startsWith('No order') ? t('track.notFound') : t('track.error'))
    } finally {
      if (mine === seq.current) setLoading(false)
    }
  }

  // Opened with an order number (from checkout or My orders): look it up at once.
  useEffect(() => {
    if (open && preset) {
      setOrderNumber(preset)
      lookup(preset)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, preset])

  // Start fresh a beat after closing.
  useEffect(() => {
    if (open) return
    const id = window.setTimeout(() => { seq.current++; setOrderNumber(''); setOrder(null); setError(''); setLoading(false) }, 300)
    return () => window.clearTimeout(id)
  }, [open])

  // Desktop: put the caret in the field when there's nothing to look up yet.
  useEffect(() => {
    if (!open || !desktop || preset) return
    const id = window.setTimeout(() => inputRef.current?.focus(), 60)
    return () => window.clearTimeout(id)
  }, [open, desktop, preset])

  return (
    <ResponsiveSheet open={open} onOpenChange={setOpen} title={t('track.title')} description={t('track.sub')} size="md">
      <MotionConfig reducedMotion="user">
        <form
          noValidate
          onSubmit={(e) => { e.preventDefault(); lookup(orderNumber) }}
          role="search"
        >
          <label htmlFor="track-no" className="mb-1.5 block text-[0.92rem] font-medium text-foreground">{t('track.label')}</label>
          <div className="flex gap-2">
            <input
              ref={inputRef}
              id="track-no"
              value={orderNumber}
              onChange={(e) => { setOrderNumber(e.target.value); if (error) setError('') }}
              placeholder={t('track.ph')}
              autoCapitalize="characters"
              autoComplete="off"
              spellCheck={false}
              aria-invalid={!!error}
              aria-describedby={error ? 'track-err' : undefined}
              className="h-12 min-w-0 flex-1 rounded-[14px] border border-input bg-surface px-4 text-base uppercase tracking-wide text-foreground outline-none transition-[border-color,box-shadow] duration-200 placeholder:normal-case placeholder:tracking-normal placeholder:text-muted-foreground/75 focus:border-transparent focus:ring-2 focus:ring-plum aria-[invalid=true]:border-destructive aria-[invalid=true]:focus:ring-destructive"
            />
            <button
              type="submit"
              disabled={loading}
              aria-busy={loading}
              className="press inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-full bg-plum px-5 font-semibold text-porcelain shadow-1 hover:bg-plum-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum focus-visible:ring-offset-2 disabled:cursor-progress"
            >
              {loading ? <Loader2 className="h-[18px] w-[18px] animate-spin" aria-hidden /> : <Search className="h-[18px] w-[18px]" aria-hidden />}
              {t('track.search')}
            </button>
          </div>
          <AnimatePresence initial={false}>
            {error && (
              <motion.p
                key={error}
                id="track-err"
                role="alert"
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2, ease: EASE_OUT }}
                className="mt-2 flex items-start gap-1.5 text-sm leading-snug text-destructive"
              >
                <AlertCircle className="mt-[2px] h-4 w-4 shrink-0" aria-hidden /> {error}
              </motion.p>
            )}
          </AnimatePresence>
        </form>

        <AnimatePresence mode="wait">
          {loading && !order ? (
            <motion.div key="skeleton" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="mt-6 space-y-3" aria-hidden>
              <div className="shimmer h-24 rounded-[24px]" />
              <div className="shimmer h-56 rounded-[24px]" />
            </motion.div>
          ) : order ? (
            <motion.div
              key={order.orderNumber}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.45, ease: EASE_OUT }}
              className="mt-6"
            >
              <OrderResult order={order} />
            </motion.div>
          ) : null}
        </AnimatePresence>
      </MotionConfig>
    </ResponsiveSheet>
  )
}

/* ─────────────────────────────── result ─────────────────────────────── */

function iconFor(st: string) {
  if (st === 'pending') return Clock
  if (st === 'confirmed') return CheckCircle2
  if (st === 'processing') return Package
  if (st === 'shipped') return Truck
  if (st === 'ready_for_pickup') return Package
  if (st === 'delivered') return CheckCircle2
  return XCircle
}

function useEtaText() {
  const { t } = useI18n()
  return (label: string) => {
    const fixed: Record<string, string> = {
      'Delivered': 'track.eta.delivered',
      'Cancelled': 'track.eta.cancelled',
      'Ready for pickup now': 'track.eta.readyNow',
      'Awaiting confirmation': 'track.eta.awaiting',
      'Arriving at Azam office soon': 'track.eta.azamSoon',
      'Ferry date shared after confirmation': 'track.eta.ferryAfter',
      'Being packed for the ferry': 'track.eta.ferryPacking',
      'Being prepared for pickup': 'track.eta.pickupDay',
      'Ready for pickup after confirmation': 'track.eta.pickupAfter',
      'On the way to you': 'track.eta.localWay',
      'Being prepared for delivery': 'track.eta.localDays',
      'Delivery arranged after confirmation': 'track.eta.localAfter',
    }
    if (fixed[label]) return t(fixed[label])
    return label
  }
}

function OrderResult({ order }: { order: ApiOrder }) {
  const { t, lang } = useI18n()
  const statusText = useStatusText()
  const etaText = useEtaText()
  const reduce = useReducedMotion()
  const locale = lang === 'sw' ? 'sw-TZ' : 'en-GB'
  const fmtDate = (iso: string) => new Date(iso).toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' })
  const fmtStamp = (iso: string) => new Date(iso).toLocaleString(locale, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

  const cancelled = order.status === 'cancelled'
  const all = orderSteps(order.deliveryChannel, order.status)
  const reachedIdx = (s: string) => all.indexOf(s)
  // For a cancelled order, show the steps it did reach, then the cancellation.
  const lastReached = cancelled
    ? Math.max(0, ...order.statusHistory.map((h) => reachedIdx(h.status)).filter((i) => i >= 0))
    : all.indexOf(order.status)
  const steps = cancelled ? [...all.slice(0, lastReached + 1), 'cancelled'] : all
  const current = cancelled ? steps.length - 1 : lastReached
  const pulse = !reduce && (order.status === 'pending' || order.status === 'processing')

  const stampFor = (s: string) => {
    const hits = order.statusHistory.filter((h) => h.status === s)
    return hits[hits.length - 1]
  }

  const eta = deliveryEta(order.deliveryChannel, order.status, order.createdAt)
  const etaTone =
    eta?.tone === 'green' ? 'bg-lagoon-deep/10 text-lagoon-deep'
      : eta?.tone === 'blue' ? 'bg-plum/[0.07] text-plum'
        : eta?.tone === 'amber' ? 'bg-amber-100 text-amber-900'
          : 'bg-muted text-muted-foreground'
  const ChannelIcon = order.deliveryChannel === 'ferry' ? Ship : order.deliveryChannel === 'pickup' ? Store : Truck
  const channelText = t(order.deliveryChannel === 'ferry' ? 'track.ch.ferry' : order.deliveryChannel === 'pickup' ? 'track.ch.pickup' : 'track.ch.local')

  return (
    <div className="space-y-4">
      {/* header card */}
      <div className="rounded-[24px] bg-shell p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-sm text-muted-foreground">{t('track.label')}</div>
            <div className="mt-0.5 text-[1.15rem] font-semibold tracking-wide text-plum tabular">{order.orderNumber}</div>
            <div className="mt-1 text-sm text-muted-foreground">{t('track.placedOn', { date: fmtDate(order.createdAt) })}</div>
          </div>
          <StatusChip status={order.status} />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="inline-flex h-9 items-center gap-2 rounded-full bg-surface px-3.5 text-[0.88rem] font-medium text-foreground shadow-1">
            <ChannelIcon className="h-4 w-4 text-plum" aria-hidden /> {channelText}
          </span>
          {eta && (
            <span className={cn('inline-flex h-9 items-center gap-2 rounded-full px-3.5 text-[0.88rem] font-semibold', etaTone)}>
              <CalendarClock className="h-4 w-4" aria-hidden /> {etaText(eta.label)}
            </span>
          )}
        </div>
      </div>

      {/* timeline */}
      <section aria-labelledby="track-progress" className="rounded-[24px] bg-surface p-5 shadow-1 ring-1 ring-border">
        <h3 id="track-progress" className="font-display text-[1.2rem] leading-tight text-plum">{t('track.progress')}</h3>
        <ol className="mt-5">
          {steps.map((st, i) => {
            const done = i < current
            const isCurrent = i === current
            const future = i > current
            const isCancel = st === 'cancelled'
            const Icon = iconFor(st)
            const stamp = !future ? stampFor(st) : undefined
            return (
              <li key={st} className={cn('relative flex gap-4', i < steps.length - 1 && 'pb-6')} aria-current={isCurrent ? 'step' : undefined}>
                {i < steps.length - 1 && (
                  <span aria-hidden className="absolute bottom-0 left-[15px] top-8 w-[2px] overflow-hidden rounded-full bg-sand">
                    <motion.span
                      className="absolute inset-0 origin-top rounded-full bg-plum"
                      initial={{ scaleY: 0 }}
                      animate={{ scaleY: i < current ? 1 : 0 }}
                      transition={{ duration: 0.4, ease: EASE_OUT, delay: 0.25 + i * 0.14 }}
                    />
                  </span>
                )}
                <span className="relative z-[1] grid h-8 w-8 shrink-0 place-items-center">
                  {isCurrent && pulse && (
                    <motion.span
                      aria-hidden
                      className="absolute inset-0 rounded-full ring-2 ring-plum/50"
                      initial={{ scale: 1, opacity: 0.9 }}
                      animate={{ scale: 1.7, opacity: 0 }}
                      transition={{ duration: 1.5, ease: EASE_OUT, repeat: 1, delay: 0.3 + i * 0.14 }}
                    />
                  )}
                  <motion.span
                    initial={{ scale: 0.7, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.35, ease: EASE_OUT, delay: 0.15 + i * 0.14 }}
                    className={cn(
                      'grid h-8 w-8 place-items-center rounded-full',
                      isCancel ? 'bg-destructive text-white'
                        : done ? 'bg-plum text-porcelain'
                          : isCurrent ? 'bg-plum text-porcelain shadow-2'
                            : 'bg-surface text-muted-foreground ring-2 ring-sand',
                    )}
                  >
                    {done ? <Check className="h-4 w-4" strokeWidth={3} aria-hidden />
                      : future ? <span className="h-1.5 w-1.5 rounded-full bg-current opacity-60" aria-hidden />
                        : <Icon className="h-4 w-4" aria-hidden />}
                  </motion.span>
                </span>
                <div className="min-w-0 pt-1">
                  <div className={cn('font-semibold leading-tight', future ? 'text-muted-foreground' : isCancel ? 'text-destructive' : 'text-foreground')}>
                    {statusText(st)}
                  </div>
                  {stamp && <div className="mt-1 text-sm text-muted-foreground tabular">{fmtStamp(stamp.at)}</div>}
                  {stamp?.note && <p className="mt-1 text-sm text-foreground/80">{stamp.note}</p>}
                </div>
              </li>
            )
          })}
        </ol>
        {cancelled && (
          <p className="mt-5 flex items-start gap-2 rounded-[14px] bg-destructive/[0.07] px-3.5 py-2.5 text-sm text-destructive">
            <XCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /> {t('track.cancelledNote')}
          </p>
        )}
      </section>

      {/* items */}
      <section aria-labelledby="track-items" className="rounded-[24px] bg-surface p-5 shadow-1 ring-1 ring-border">
        <h3 id="track-items" className="font-display text-[1.2rem] leading-tight text-plum">{t('track.items')}</h3>
        <ul className="mt-4 space-y-3">
          {order.items.map((it) => (
            <li key={it.productId} className="flex items-center gap-3">
              <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-[12px] bg-shell">
                {it.image ? <Image src={it.image} alt="" fill sizes="48px" className="object-cover" /> : <Package className="m-3 h-6 w-6 text-plum/50" aria-hidden />}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate font-medium leading-tight text-foreground">{it.name}</span>
                <span className="mt-0.5 block text-sm text-muted-foreground">{it.qty} × {formatTZS(it.price)}{it.unit ? ` · ${it.unit}` : ''}</span>
              </span>
              <span className="shrink-0 text-[0.95rem] font-semibold tabular">{formatTZS(it.price * it.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex items-baseline justify-between border-t border-border pt-4">
          <span className="font-semibold">{t('track.total')}</span>
          <span className="font-display text-[1.5rem] leading-none text-plum tabular">{formatTZS(order.total)}</span>
        </div>
        <button
          type="button"
          onClick={() => openInvoice(order, null)}
          className="press mt-5 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-surface font-semibold text-plum shadow-1 ring-1 ring-border hover:bg-shell focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum"
        >
          <FileText className="h-[18px] w-[18px]" aria-hidden /> {t('track.invoice')}
        </button>
      </section>
    </div>
  )
}
