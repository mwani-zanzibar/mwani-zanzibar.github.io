'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { motion, useMotionValueEvent, useScroll } from 'framer-motion'
import { Search, ShoppingBag } from 'lucide-react'
import { Burger, RollText } from '@/components/store/side-nav'
import { useCart } from '@/lib/cart-store'
import { useUI } from '@/lib/ui-store'
import { useI18n } from '@/lib/i18n'
import { registerCartTarget } from '@/lib/cart-fx'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { NumberRoll } from '@/components/motion/number-roll'
import { SPRING_SNAPPY } from '@/components/shared/reveal'
import type { ApiSettings } from '@/lib/api'
import { useImg } from '@/lib/content-store'

const LINKS = [
  { id: 'shop', key: 'nav.shop' },
  { id: 'duo', key: 'nav.duo' },
  { id: 'story', key: 'nav.story' },
  { id: 'recipes', key: 'nav.recipes' },
  { id: 'how', key: 'nav.ordering' },
] as const

export function Navbar(_: { settings: ApiSettings | null }) {
  const markSrc = useImg('brand.mark', '/brand/mwani-mark.png')
  const { t, lang, setLang } = useI18n()
  const count = useCart((s) => s.items.reduce((n, i) => n + i.qty, 0))
  const setCartOpen = useCart((s) => s.setOpen)
  const setSearchOpen = useUI((s) => s.setSearchOpen)
  const openMenu = useUI((s) => s.openMenu)
  const menuOpen = useUI((s) => s.menuOpen)
  const { scrollY } = useScroll()
  const [floating, setFloating] = useState(false)
  const [hidden, setHidden] = useState(false)
  const [hover, setHover] = useState<string | null>(null)
  const bag = useRef<HTMLButtonElement>(null)

  useMotionValueEvent(scrollY, 'change', (y) => {
    const prev = scrollY.getPrevious() ?? 0
    setFloating(y > 40)
    // Phones keep the bar on screen: it is the only navigation there.
    if (window.innerWidth < 768) { setHidden(false); return }
    if (y > 600 && y > prev + 4) setHidden(true)
    else if (y < prev - 4 || y < 600) setHidden(false)
  })
  useEffect(() => (bag.current ? registerCartTarget(bag.current, 1) : undefined), [])
  useEffect(() => {
    const show = () => setHidden(false)
    window.addEventListener('cart:landed', show)
    return () => window.removeEventListener('cart:landed', show)
  }, [])

  return (
    <motion.header
      className="pointer-events-none fixed inset-x-0 top-0 z-50 px-3 sm:px-5"
      initial={{ y: -90 }}
      animate={{ y: hidden ? -110 : 0, paddingTop: floating ? 10 : 16 }}
      transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
    >
      <nav
        aria-label="Main"
        className={`pointer-events-auto mx-auto flex h-16 max-w-[84rem] items-center gap-2 rounded-full pl-3 pr-2 transition-[background-color,box-shadow] duration-300 sm:pl-4 ${floating ? 'bg-surface shadow-2' : 'bg-transparent'}`}
      >
        <a href="#top" onClick={(e) => { e.preventDefault(); scrollToId('top', 0) }} className="flex shrink-0 items-center gap-2" aria-label="Mwani Zanzibar Seaweed">
          <Image src={markSrc} alt="" width={36} height={36} priority className="h-8 w-8 sm:h-9 sm:w-9" />
          <span className="font-logo text-[1rem] leading-none text-plum max-[374px]:hidden sm:text-[1.15rem]">Mwani Zanzibar</span>
        </a>

        <ul className="ml-6 hidden items-center lg:flex" onMouseLeave={() => setHover(null)}>
          {LINKS.map((l) => (
            <li key={l.id} className="relative" onMouseEnter={() => setHover(l.id)}>
              {hover === l.id && <motion.span layoutId="nav-hover" className="absolute inset-0 rounded-full bg-plum/[0.07]" transition={SPRING_SNAPPY} />}
              <a href={`#${l.id}`} onClick={(e) => { e.preventDefault(); scrollToId(l.id) }} className="group relative block px-4 py-2.5 text-[0.95rem] font-medium text-plum/80 transition-colors hover:text-plum">
                <RollText text={t(l.key)} className="leading-[1.35]" plain />
              </a>
            </li>
          ))}
        </ul>

        <div className="ml-auto flex items-center gap-1 sm:gap-1.5">
          <button onClick={() => setSearchOpen(true)} aria-label={t('nav.search')}
            className="press hidden h-11 items-center gap-2 rounded-full px-4 text-[0.93rem] font-medium text-plum/80 hover:bg-plum/[0.07] hover:text-plum md:inline-flex">
            <Search className="h-4 w-4" aria-hidden /> {t('nav.search')}
            <kbd className="ml-1 rounded-md bg-plum/[0.07] px-1.5 py-0.5 font-sans text-[0.7rem] text-plum/60">/</kbd>
          </button>
          <motion.button ref={bag} whileTap={{ scale: 0.96 }} onClick={() => setCartOpen(true)} aria-label={`${t('nav.bagLabel')}, ${count}`}
            className="flex h-10 items-center gap-2 rounded-full bg-plum pl-3 pr-1 text-[0.92rem] font-semibold text-porcelain transition-colors duration-200 hover:bg-plum-2 sm:h-11 sm:pl-4 sm:pr-1.5">
            <ShoppingBag className="h-4 w-4" aria-hidden />
            <span className="hidden sm:inline">{t('nav.bagLabel')}</span>
            <span className="grid h-8 min-w-8 place-items-center rounded-full bg-porcelain/15 px-2 text-[0.85rem]"><NumberRoll value={String(count)} /></span>
          </motion.button>
          {/* Language sits right beside the bag: a small segmented pill whose thumb slides. */}
          <button onClick={() => setLang(lang === 'sw' ? 'en' : 'sw')} aria-label={lang === 'sw' ? 'Switch to English' : 'Badilisha kwenda Kiswahili'}
            className={`press relative flex h-10 items-center rounded-full p-1 text-[0.76rem] font-semibold transition-colors duration-300 sm:h-11 sm:text-[0.8rem] ${floating ? 'bg-plum/[0.06]' : 'bg-surface/60'}`}>
            {(['en', 'sw'] as const).map((l) => (
              <span key={l} className={`relative grid h-8 w-8 place-items-center rounded-full transition-colors duration-200 sm:h-9 sm:w-10 ${lang === l ? 'text-porcelain' : 'text-plum/60'}`}>
                {lang === l && <motion.span layoutId="nav-lang" className="absolute inset-0 rounded-full bg-plum" transition={SPRING_SNAPPY} />}
                <span className="relative uppercase">{l}</span>
              </span>
            ))}
          </button>
          <button onClick={(e) => openMenu(e.currentTarget)} aria-label={t('nav.menu')} aria-expanded={menuOpen} className="press grid h-11 w-11 place-items-center rounded-full text-plum hover:bg-plum/[0.07]">
            <Burger open={false} />
          </button>
        </div>
      </nav>
    </motion.header>
  )
}
