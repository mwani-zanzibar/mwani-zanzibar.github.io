'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { Check, ChevronLeft, Clock, RotateCcw, ShoppingBag, Users } from 'lucide-react'
import type { ApiRecipe } from '@/lib/api'
import { ResponsiveSheet } from '@/components/store/overlay-shell'
import { ImageReveal, EASE_OUT, SPRING_POP, SPRING_SNAPPY } from '@/components/shared/reveal'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { useI18n } from '@/lib/i18n'
import { cn } from '@/lib/utils'
import { useImg } from '@/lib/content-store'

/** Recipe sheet: hero, tickable ingredients and a step-through method. */
export function RecipeModal({ recipe, onClose }: { recipe: ApiRecipe | null; onClose: () => void }) {
  // Keep the last recipe on screen while the sheet animates closed.
  const [last, setLast] = useState<ApiRecipe | null>(recipe)
  useEffect(() => { if (recipe) setLast(recipe) }, [recipe])
  const r = recipe ?? last
  if (!r) return null
  return (
    <ResponsiveSheet open={!!recipe} onOpenChange={(v) => { if (!v) onClose() }} title={r.title} description={r.excerpt || undefined} hideTitle size="lg">
      <MotionConfig reducedMotion="user">
        <RecipeBody key={r.id} recipe={r} onClose={onClose} />
      </MotionConfig>
    </ResponsiveSheet>
  )
}

function RecipeBody({ recipe, onClose }: { recipe: ApiRecipe; onClose: () => void }) {
  const markSrc = useImg('brand.mark', '/brand/mwani-mark.png')
  const { t } = useI18n()
  const [ticked, setTicked] = useState<Set<number>>(() => new Set())
  const [step, setStep] = useState(0)
  const steps = recipe.steps || []
  const ings = recipe.ingredients || []
  const done = step >= steps.length
  const catKey = `recipe.cat.${recipe.category}`
  const cat = t(catKey) === catKey ? recipe.category : t(catKey)

  const toggle = (i: number) => setTicked((s) => { const n = new Set(s); if (n.has(i)) n.delete(i); else n.add(i); return n })

  return (
    <div>
      {/* Hero */}
      <div className="relative">
        <ImageReveal className="aspect-[4/3] rounded-[24px] bg-shell sm:aspect-[2/1]">
          <Image src={recipe.image} alt="" fill sizes="(min-width: 768px) 720px, 100vw" className="object-cover" priority />
        </ImageReveal>
        <motion.div
          className="absolute bottom-3 left-3 right-3 flex flex-wrap gap-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.45, ease: EASE_OUT }}
        >
          {recipe.category && <Chip>{cat}</Chip>}
          {recipe.prepTime && <Chip><Clock className="h-4 w-4" aria-hidden /><span className="sr-only">{t('recipe.time')}: </span>{recipe.prepTime}</Chip>}
          {recipe.servings && <Chip><Users className="h-4 w-4" aria-hidden /><span className="sr-only">{t('recipe.serves')}: </span>{recipe.servings}</Chip>}
        </motion.div>
      </div>

      <h2 className="mt-6 font-display text-[clamp(1.9rem,4vw,2.6rem)] leading-[1.04] text-plum">{recipe.title}</h2>
      {(recipe.content || recipe.excerpt) && (
        <p className="mt-3 max-w-[60ch] text-[1rem] leading-relaxed text-foreground/80">{recipe.content || recipe.excerpt}</p>
      )}

      <div className="mt-7 grid gap-4 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] md:gap-5">
        {/* Ingredients */}
        <section className="self-start rounded-[24px] bg-porcelain p-5 ring-1 ring-border/60" aria-labelledby="rc-ing">
          <div className="flex items-baseline justify-between gap-3">
            <h3 id="rc-ing" className="font-display text-[1.35rem] leading-tight text-plum">{t('recipe.ingredients')}</h3>
            <span className="text-[0.84rem] text-muted-foreground tabular" aria-live="polite">{t('recipe.ready', { n: ticked.size, total: ings.length })}</span>
          </div>
          <ul className="mt-3">
            {ings.map((ing, i) => {
              const on = ticked.has(i)
              return (
                <li key={i}>
                  <button
                    role="checkbox"
                    aria-checked={on}
                    aria-label={t('recipe.tick', { x: ing })}
                    onClick={() => toggle(i)}
                    className="group flex min-h-11 w-full items-center gap-3 rounded-[12px] py-1.5 text-left"
                  >
                    <span className={cn('relative grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-colors duration-200', on ? 'border-lagoon-deep' : 'border-plum/25 group-hover:border-plum/50')}>
                      <motion.span className="absolute inset-[-2px] rounded-full bg-lagoon-deep" initial={false} animate={{ scale: on ? 1 : 0.4, opacity: on ? 1 : 0 }} transition={SPRING_SNAPPY} />
                      <svg viewBox="0 0 24 24" className="relative h-3.5 w-3.5 text-white" fill="none" stroke="currentColor" strokeWidth={3.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                        <motion.path d="M5 12.5l4.5 4.5L19 7.5" initial={false} animate={{ pathLength: on ? 1 : 0, opacity: on ? 1 : 0 }} transition={{ duration: 0.24, ease: EASE_OUT, delay: on ? 0.06 : 0 }} />
                      </svg>
                    </span>
                    <span className={cn('relative text-[0.98rem] transition-colors duration-200', on ? 'text-muted-foreground' : 'text-foreground/90')}>
                      {ing}
                      <motion.span
                        className="absolute left-0 right-0 top-1/2 h-[1.5px] origin-left rounded-full bg-current"
                        initial={false}
                        animate={{ scaleX: on ? 1 : 0 }}
                        transition={{ duration: 0.28, ease: EASE_OUT }}
                        aria-hidden
                      />
                    </span>
                  </button>
                </li>
              )
            })}
          </ul>
        </section>

        {/* Method: a real sequence, so numbered */}
        <section className="rounded-[24px] bg-card p-5 shadow-1 ring-1 ring-border/60" aria-labelledby="rc-method">
          <div className="flex items-baseline justify-between gap-3">
            <h3 id="rc-method" className="font-display text-[1.35rem] leading-tight text-plum">{t('recipe.method')}</h3>
            <span className="text-[0.84rem] text-muted-foreground tabular" aria-live="polite">
              {done ? t('recipe.allDone') : t('recipe.step', { n: step + 1, total: steps.length })}
            </span>
          </div>
          <ol className="-mx-2 mt-3 space-y-1">
            {steps.map((s, i) => {
              const cur = i === step
              const past = i < step
              return (
                <li key={i}>
                  <button
                    onClick={() => setStep(i)}
                    aria-current={cur ? 'step' : undefined}
                    aria-label={`${t('recipe.goStep', { n: i + 1 })}: ${s}`}
                    className="relative flex w-full items-start gap-3 rounded-[18px] p-2.5 text-left"
                  >
                    {cur && <motion.span layoutId="recipe-step-bg" className="absolute inset-0 rounded-[18px] bg-shell" transition={SPRING_SNAPPY} />}
                    <span className={cn(
                      'relative grid h-8 w-8 shrink-0 place-items-center rounded-full text-[0.9rem] font-semibold transition-colors duration-200',
                      past || done ? 'bg-lagoon-deep text-porcelain' : cur ? 'bg-plum text-porcelain' : 'bg-card text-plum ring-1 ring-border',
                    )}>
                      <AnimatePresence mode="popLayout" initial={false}>
                        {past || done ? (
                          <motion.span key="c" className="grid" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.5, opacity: 0 }} transition={SPRING_POP}>
                            <Check className="h-4 w-4" strokeWidth={3} aria-hidden />
                          </motion.span>
                        ) : (
                          <motion.span key="n" className="tabular" initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }} transition={{ duration: 0.18 }}>
                            {i + 1}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </span>
                    <span className={cn('relative pt-1 text-[0.98rem] leading-relaxed transition-colors duration-200', cur ? 'text-foreground' : past || done ? 'text-muted-foreground' : 'text-foreground/75')}>
                      {s}
                    </span>
                  </button>
                </li>
              )
            })}
          </ol>

          <div className="mt-4 flex items-center gap-2">
            {done ? (
              <button onClick={() => setStep(0)} className="press inline-flex h-11 items-center gap-2 rounded-full bg-card px-5 text-[0.95rem] font-semibold text-plum shadow-1 ring-1 ring-border/60">
                <RotateCcw className="h-4 w-4" aria-hidden />{t('recipe.again')}
              </button>
            ) : (
              <>
                <button
                  onClick={() => setStep((s) => Math.max(0, s - 1))}
                  disabled={step === 0}
                  className="press inline-flex h-11 items-center gap-1 rounded-full bg-card pl-3 pr-4 text-[0.95rem] font-medium text-plum shadow-1 ring-1 ring-border/60 disabled:opacity-40"
                >
                  <ChevronLeft className="h-4 w-4" aria-hidden />{t('recipe.prev')}
                </button>
                <button
                  onClick={() => setStep((s) => s + 1)}
                  className="press ml-auto inline-flex h-11 items-center gap-2 rounded-full bg-plum px-5 text-[0.95rem] font-semibold text-porcelain hover:bg-plum-2"
                >
                  {step >= steps.length - 1 ? <><Check className="h-4 w-4" strokeWidth={3} aria-hidden />{t('recipe.finish')}</> : t('recipe.next')}
                </button>
              </>
            )}
          </div>
        </section>
      </div>

      {/* Shop the seaweed */}
      <div className="mt-5 flex flex-col gap-4 rounded-[24px] bg-shell p-4 sm:flex-row sm:items-center md:p-5">
        <div className="flex min-w-0 flex-1 items-center gap-3.5">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-card shadow-1">
            <Image src={markSrc} alt="" width={30} height={30} className="h-[30px] w-[30px]" />
          </span>
          <div className="min-w-0">
            <p className="font-display text-[1.1rem] leading-tight text-plum">{t('recipe.shopTitle')}</p>
            <p className="mt-0.5 text-[0.9rem] text-foreground/75">{t('recipe.shopBody')}</p>
          </div>
        </div>
        <button
          onClick={() => { onClose(); window.setTimeout(() => scrollToId('shop'), 260) }}
          className="press inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-full bg-plum px-5 text-[0.95rem] font-semibold text-porcelain hover:bg-plum-2"
        >
          <ShoppingBag className="h-[18px] w-[18px]" aria-hidden />{t('recipe.shop')}
        </button>
      </div>
    </div>
  )
}

function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex h-9 items-center gap-1.5 rounded-full bg-card px-3.5 text-[0.86rem] font-medium text-plum shadow-2">
      {children}
    </span>
  )
}
