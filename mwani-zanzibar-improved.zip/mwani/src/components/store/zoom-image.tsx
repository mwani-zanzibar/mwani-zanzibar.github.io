'use client'

import Image from 'next/image'
import { useRef, useState } from 'react'
import { ZoomIn } from 'lucide-react'

type Props = {
  src: string
  alt: string
  sizes: string
  onClick?: () => void
  badge?: React.ReactNode
}

/**
 * Hover-zoom image: on mouse move over the image, a 2.5x zoomed view follows
 * the cursor (like a magnifier). On touch devices it falls back to a tap-to-open.
 */
export function ZoomImage({ src, alt, sizes, onClick, badge }: Props) {
  const ref = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null)
  const [hover, setHover] = useState(false)

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current
    if (!el) return
    const rect = el.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    setPos({ x, y })
  }

  return (
    <div
      ref={ref}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPos(null) }}
      onMouseMove={onMove}
      onClick={onClick}
      className="group relative block w-full aspect-square sm:aspect-auto sm:h-full sm:min-h-[28rem] overflow-hidden cursor-zoom-in"
    >
      <Image
        src={src}
        alt={alt}
        fill

        priority
        sizes={sizes}
        className={`object-cover transition-transform duration-300 ${hover && pos ? 'scale-[2.5]' : 'scale-100'}`}
        style={hover && pos ? { transformOrigin: `${pos.x}% ${pos.y}%` } : undefined}
      />
      {/* zoom hint */}
      <div className="pointer-events-none absolute top-3 right-3 inline-flex items-center gap-1 rounded-full bg-background/85 backdrop-blur px-2.5 py-1 text-[10px] font-bold text-brand border border-border/50 opacity-0 group-hover:opacity-100 transition-opacity">
        <ZoomIn className="h-3 w-3" /> Hover to zoom
      </div>
      {badge}
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors" />
    </div>
  )
}
