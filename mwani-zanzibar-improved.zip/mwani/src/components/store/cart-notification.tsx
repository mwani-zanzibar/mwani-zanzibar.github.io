'use client'

import Image from 'next/image'
import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { X } from 'lucide-react'
import { useCart } from '@/lib/cart-store'
import { useMoney } from '@/lib/use-money'
import { useI18n } from '@/lib/i18n'

type Item = { id: string; name: string; price: number; image: string; unit: string }
let push: ((i: Item) => void) | null = null
export function showCartNotification(item: Item) { push?.(item) }

export function CartNotificationHost({ onViewBag }: { onViewBag: () => void }) {
  const [item, setItem] = useState<(Item & { key: number }) | null>(null)
  const bagOpen = useCart((s) => s.open)
  const money = useMoney()
  const { t } = useI18n()
  useEffect(() => { push = (i) => setItem({ ...i, key: Date.now() }); return () => { push = null } }, [])
  useEffect(() => { if (bagOpen) setItem(null) }, [bagOpen])
  useEffect(() => { if (!item) return; const id = setTimeout(() => setItem(null), 3400); return () => clearTimeout(id) }, [item])
  return (
    <div className="pointer-events-none fixed inset-x-3 top-[76px] z-[60] flex justify-end sm:right-6 sm:left-auto" aria-live="polite">
      <AnimatePresence>
        {item && (
          <motion.div key={item.key} role="status"
            initial={{ opacity: 0, y: -10, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -6, transition: { duration: 0.18 } }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="pointer-events-auto w-full max-w-[22rem] rounded-[20px] border border-border bg-background p-3 shadow-[0_24px_60px_-28px_rgb(42_10_20/0.45)]">
            <div className="flex items-center gap-3">
              <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xl bg-blush"><Image src={item.image} alt="" fill sizes="56px" className="object-cover" /></div>
              <div className="min-w-0 flex-1">
                <p className="text-sm text-muted-foreground">{t('cart.added')}</p>
                <p className="truncate font-medium text-foreground">{item.name}</p>
                <p className="text-sm tabular-nums text-foreground/70">{money(item.price)}</p>
              </div>
              <button onClick={() => setItem(null)} className="grid h-8 w-8 place-items-center self-start rounded-full text-foreground/50 hover:bg-foreground/5 hover:text-foreground" aria-label="Close"><X className="h-4 w-4" /></button>
            </div>
            <button onClick={() => { setItem(null); onViewBag() }} className="press mt-3 h-11 w-full rounded-full bg-brand text-[0.92rem] font-medium text-brand-foreground">{t('cart.view')}</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
