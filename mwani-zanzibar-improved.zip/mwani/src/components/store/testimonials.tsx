'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, Star } from 'lucide-react'
import { api, type ApiReview } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { Reveal, SplitReveal, Stagger, StaggerItem } from '@/components/shared/reveal'
import { cn } from '@/lib/utils'

// Approved reviews only. With none yet, the section is left out rather than
// filled with placeholder praise.
export function TestimonialsSection() {
  const { t } = useI18n()
  const [reviews, setReviews] = useState<ApiReview[]>([])
  const rail = useRef<HTMLUListElement>(null)
  const [edge, setEdge] = useState({ start: true, end: false })

  useEffect(() => {
    let live = true
    api.approvedReviews()
      .then((r) => { if (live) setReviews(r.reviews.filter((x) => x.comment?.trim()).slice(0, 12)) })
      .catch(() => { if (live) setReviews([]) })
    return () => { live = false }
  }, [])

  // Mouse users can grab the row and drag it; touch keeps native swiping.
  useEffect(() => {
    const el = rail.current
    if (!el) return
    let down = false, moved = false, sx = 0, sl = 0
    const onDown = (e: PointerEvent) => {
      if (e.pointerType !== 'mouse' || e.button !== 0) return
      down = true; moved = false; sx = e.clientX; sl = el.scrollLeft
    }
    const onMove = (e: PointerEvent) => {
      if (!down) return
      const dx = e.clientX - sx
      if (!moved && Math.abs(dx) > 4) { moved = true; el.dataset.drag = 'true'; el.setPointerCapture(e.pointerId) }
      if (moved) el.scrollLeft = sl - dx
    }
    const onUp = (e: PointerEvent) => {
      if (!down) return
      down = false
      if (moved) {
        delete el.dataset.drag
        if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId)
      }
    }
    const onScroll = () => {
      const max = el.scrollWidth - el.clientWidth
      setEdge({ start: el.scrollLeft < 8, end: el.scrollLeft > max - 8 })
    }
    onScroll()
    el.addEventListener('pointerdown', onDown)
    el.addEventListener('pointermove', onMove)
    el.addEventListener('pointerup', onUp)
    el.addEventListener('pointercancel', onUp)
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      el.removeEventListener('pointerdown', onDown)
      el.removeEventListener('pointermove', onMove)
      el.removeEventListener('pointerup', onUp)
      el.removeEventListener('pointercancel', onUp)
      el.removeEventListener('scroll', onScroll)
    }
  }, [reviews.length])

  if (reviews.length === 0) return null

  const nudge = (dir: number) => {
    const el = rail.current
    if (!el) return
    const card = el.querySelector('li')
    el.scrollBy({ left: dir * ((card?.clientWidth || 360) + 16), behavior: 'smooth' })
  }

  return (
    <section id="reviews" className="relative py-20 sm:py-28">
      <div className="mx-auto flex max-w-[88rem] items-end justify-between gap-6 px-4 sm:px-8 lg:px-12">
        <div>
          <SplitReveal as="h2" text={t('rev.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-[1] text-plum" />
          <Reveal delay={0.1}><p className="mt-4 max-w-[28rem] text-[1.05rem] leading-[1.6] text-foreground/75">{t('rev.body')}</p></Reveal>
        </div>
        {reviews.length > 1 && (
          <div className="hidden shrink-0 gap-2 sm:flex">
            {[-1, 1].map((d) => (
              <button key={d} type="button" onClick={() => nudge(d)} disabled={d < 0 ? edge.start : edge.end}
                aria-label={d < 0 ? t('rev.prev') : t('rev.next')}
                className="press grid h-12 w-12 place-items-center rounded-full bg-surface text-plum shadow-1 hover:shadow-2 disabled:opacity-40 disabled:shadow-none">
                {d < 0 ? <ArrowLeft aria-hidden className="h-5 w-5" /> : <ArrowRight aria-hidden className="h-5 w-5" />}
              </button>
            ))}
          </div>
        )}
      </div>

      <Stagger as="ul"
        className="no-scrollbar mt-10 flex cursor-grab snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-8 pt-2 select-none data-[drag=true]:cursor-grabbing data-[drag=true]:snap-none sm:px-[max(2rem,calc((100vw-88rem)/2+2rem))] lg:px-[max(3rem,calc((100vw-88rem)/2+3rem))]">
        {reviews.map((r, i) => (
          <StaggerItem as="li" key={r.id}
            className={cn('w-[min(84vw,380px)] shrink-0 snap-start', i % 3 === 1 && 'sm:mt-6')}>
            <figure className="flex h-full flex-col rounded-[28px] bg-surface p-6 shadow-2 sm:p-7">
            <div className="flex gap-0.5" role="img" aria-label={t('rev.stars', { n: r.rating })}>
              {Array.from({ length: 5 }).map((_, s) => (
                <Star key={s} aria-hidden className={cn('h-[18px] w-[18px]', s < r.rating ? 'fill-coral text-coral' : 'fill-shell text-shell')} />
              ))}
            </div>
            <blockquote className="mt-4 flex-1 text-[1.05rem] leading-[1.6] text-foreground">{r.comment}</blockquote>
            <figcaption className="mt-6 flex items-center gap-3">
              <span aria-hidden className="grid h-10 w-10 place-items-center rounded-full bg-shell font-display text-[1.1rem] text-plum">{(r.name || '?').trim().charAt(0).toUpperCase()}</span>
              <span className="min-w-0">
                <span className="block truncate text-[0.95rem] font-semibold text-plum">{r.name}</span>
                {r.location && <span className="block truncate text-[0.88rem] text-muted-foreground">{r.location}</span>}
              </span>
            </figcaption>
            </figure>
          </StaggerItem>
        ))}
      </Stagger>
    </section>
  )
}
