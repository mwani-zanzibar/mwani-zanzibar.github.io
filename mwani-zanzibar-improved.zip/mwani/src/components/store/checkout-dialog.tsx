'use client'

import { useEffect, useId, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion, useReducedMotion } from 'framer-motion'
import {
  AlertCircle, ArrowRight, Check, ChevronDown, Copy, Loader2, MapPin, MessageCircle,
  Package, Ship, ShoppingBag, Store, Tag, Truck, X,
} from 'lucide-react'
import { ResponsiveSheet, useIsDesktop } from '@/components/store/overlay-shell'
import { NumberRoll } from '@/components/motion/number-roll'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { EASE_OUT, SPRING_POP, SPRING_SNAPPY } from '@/components/shared/reveal'
import { useCart, type CartItem } from '@/lib/cart-store'
import { useUI } from '@/lib/ui-store'
import { useI18n } from '@/lib/i18n'
import { formatTZS, normalizePhone, whatsappLink } from '@/lib/format'
import { useMoney } from '@/lib/use-money'
import { api, type ApiOrder, type ApiSettings } from '@/lib/api'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'

type Channel = 'local' | 'ferry' | 'pickup'

// "+255774870703" → "+255 774 870 703" for reading on screen.
function displayPhone(raw: string) {
  const d = normalizePhone(raw).replace(/[^\d]/g, '')
  if (d.startsWith('255') && d.length === 12) return `+255 ${d.slice(3, 6)} ${d.slice(6, 9)} ${d.slice(9)}`
  return `+${d}`
}

const INPUT =
  'h-12 w-full rounded-[14px] border border-input bg-surface px-4 text-base text-foreground outline-none placeholder:text-muted-foreground/75 transition-[border-color,box-shadow] duration-200 focus:border-transparent focus:ring-2 focus:ring-plum aria-[invalid=true]:border-destructive aria-[invalid=true]:focus:ring-destructive'

export function CheckoutDialog({ settings, onDone }: { settings: ApiSettings | null; onDone: () => void }) {
  const open = useUI((s) => s.checkoutOpen)
  const setOpen = useUI((s) => s.setCheckoutOpen)
  const openTrack = useUI((s) => s.openTrack)
  const items = useCart((s) => s.items)
  const clear = useCart((s) => s.clear)
  const money = useMoney()
  const { t, lang } = useI18n()
  const desktop = useIsDesktop()

  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [location, setLocation] = useState('Zanzibar')
  const [channel, setChannel] = useState<Channel>('local')
  const [area, setArea] = useState('')
  const [region, setRegion] = useState('')
  const [notes, setNotes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [order, setOrder] = useState<ApiOrder | null>(null)
  const [tried, setTried] = useState(false)
  const [submitError, setSubmitError] = useState('')

  // promo code
  const [promoInput, setPromoInput] = useState('')
  const [promoApplied, setPromoApplied] = useState<{ code: string; description: string; discount: number } | null>(null)
  const [promoLoading, setPromoLoading] = useState(false)
  const [promoError, setPromoError] = useState('')

  const nameRef = useRef<HTMLInputElement>(null)
  const phoneRef = useRef<HTMLInputElement>(null)

  const threshold = settings?.freeShippingThreshold || 150000
  const ferryFee = settings?.shippingFeeMainland || 15000
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0)
  const shipping = channel === 'ferry' && subtotal < threshold ? ferryFee : 0
  const discount = promoApplied?.discount || 0
  const total = Math.max(0, subtotal + shipping - discount)

  const nameOk = !!name.trim()
  const phoneOk = phone.replace(/[^\d]/g, '').length >= 9
  const errors = {
    name: tried && !nameOk ? t('co.errName') : '',
    phone: tried && !phoneOk ? t('co.errPhone') : '',
  }

  const applyPromo = async () => {
    if (!promoInput.trim() || subtotal === 0) return
    setPromoLoading(true)
    setPromoError('')
    try {
      const r = await api.validatePromo(promoInput.trim(), subtotal)
      if (r.valid) setPromoApplied({ code: r.code, description: r.description, discount: r.discount })
    } catch (e) {
      setPromoApplied(null)
      setPromoError(lang === 'en' ? (e as Error).message : t('co.promoInvalid'))
    } finally {
      setPromoLoading(false)
    }
  }

  const removePromo = () => { setPromoApplied(null); setPromoInput(''); setPromoError('') }

  const reset = () => {
    setName(''); setPhone(''); setLocation('Zanzibar'); setChannel('local'); setArea(''); setRegion(''); setNotes('')
    removePromo()
    setTried(false); setSubmitError('')
    setOrder(null)
  }

  // Desktop: start the caret in the first field rather than on the close button.
  useEffect(() => {
    if (!open || !desktop) return
    const id = window.setTimeout(() => nameRef.current?.focus({ preventScroll: true }), 80)
    return () => window.clearTimeout(id)
  }, [open, desktop])

  // Clear the form a beat after the sheet has closed, however it was closed.
  useEffect(() => {
    if (open) return
    const id = window.setTimeout(reset, 320)
    return () => window.clearTimeout(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault()
    setTried(true)
    setSubmitError('')
    if (!nameOk) { nameRef.current?.focus(); return }
    if (items.length === 0) return
    if (!phoneOk) { phoneRef.current?.focus(); return }
    setSubmitting(true)
    try {
      const finalLocation =
        channel === 'ferry' ? `${location} — ${region.trim() || 'Mainland Tanzania'}`
          : channel === 'local' && area.trim() ? `${area.trim()}, ${location}`
            : location
      const o = await api.createOrder({
        customerName: name.trim(),
        customerPhone: phone.trim(),
        customerLocation: finalLocation,
        deliveryChannel: channel,
        notes: notes.trim(),
        promoCode: promoApplied?.code || '',
        items: items.map((i) => ({ productId: i.productId, name: i.name, price: i.price, qty: i.qty, unit: i.unit, image: i.image })),
      })
      setOrder(o.order)
      clear()
      onDone()
    } catch (err) {
      setSubmitError((err as Error).message || t('co.errGeneric'))
    } finally {
      setSubmitting(false)
    }
  }

  const buildWhatsAppMessage = () => {
    if (!order) return ''
    const tmpl = settings?.whatsappMessageTemplate ||
      `Habari! Order yangu:\nOrder No: {orderNumber}\nName: {name}\nLocation: {location}\nDelivery: {channel}\n\n{items}\nTotal: {total}`
    const itemsText = order.items.map((i) => `• ${i.qty} × ${i.name} (${formatTZS(i.price)})`).join('\n')
    const promoLine = order.discount > 0 ? `\nPromo: ${order.promoCode} (−${formatTZS(order.discount)})` : ''
    const totalStr = formatTZS(order.total) + promoLine
    return tmpl
      .replace('{orderNumber}', order.orderNumber)
      .replaceAll('{name}', order.customerName)
      .replace('{location}', order.customerLocation)
      .replace('{channel}', channel === 'ferry' ? 'Azam Ferry (Mainland)' : channel === 'pickup' ? 'Pickup in Zanzibar' : 'Local delivery Zanzibar')
      .replace('{items}', itemsText)
      .replace('{total}', totalStr)
  }

  const waPrimary = settings?.whatsappPrimary || '+255774870703'

  const shippingLabel = shipping > 0 ? money(shipping) : t('co.free')
  const summary = (
    <SummaryBody
      items={items}
      subtotal={subtotal}
      shipping={shipping}
      shippingLabel={shippingLabel}
      discount={discount}
      promoCode={promoApplied?.code}
      total={total}
    />
  )

  const placeButton = (
    <div>
      <AnimatePresence initial={false}>
        {submitError && (
          <motion.p
            role="alert"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22, ease: EASE_OUT }}
            className="mb-3 flex items-start gap-2 rounded-[14px] bg-destructive/[0.07] px-3.5 py-2.5 text-sm text-destructive"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /> {submitError}
          </motion.p>
        )}
      </AnimatePresence>
      <button
        type="submit"
        disabled={submitting}
        aria-busy={submitting}
        className="press group relative flex h-14 w-full items-center justify-center overflow-hidden rounded-full bg-plum px-6 text-[1.02rem] font-semibold text-porcelain shadow-2 hover:bg-plum-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum focus-visible:ring-offset-2 disabled:cursor-progress"
      >
        <AnimatePresence mode="popLayout" initial={false}>
          {submitting ? (
            <motion.span key="busy" className="flex items-center gap-2.5" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={{ duration: 0.22, ease: EASE_OUT }}>
              <Loader2 className="h-[18px] w-[18px] animate-spin" aria-hidden /> {t('co.placing')}
            </motion.span>
          ) : (
            <motion.span key="idle" className="flex items-center gap-2.5" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={{ duration: 0.22, ease: EASE_OUT }}>
              {t('co.place')}
              <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-1" aria-hidden />
            </motion.span>
          )}
        </AnimatePresence>
      </button>
      <p className="mt-2.5 text-center text-[0.84rem] leading-snug text-muted-foreground">{t('co.payNote')}</p>
    </div>
  )

  return (
    <ResponsiveSheet
      open={open}
      onOpenChange={setOpen}
      title={order ? t('co.placed') : t('co.title')}
      description={order ? undefined : t('co.sub')}
      hideTitle={!!order || (items.length === 0 && !order)}
      size="xl"
    >
      <MotionConfig reducedMotion="user">
        <AnimatePresence mode="wait" initial={false}>
          {order ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: EASE_OUT }}
            >
              <SuccessView
                order={order}
                waPrimary={waPrimary}
                waSecondary={settings?.whatsappSecondary || ''}
                message={buildWhatsAppMessage()}
                onTrack={() => {
                  const n = order.orderNumber
                  setOpen(false)
                  window.setTimeout(() => openTrack(n), 200)
                }}
                onKeepShopping={() => setOpen(false)}
              />
            </motion.div>
          ) : items.length === 0 ? (
            <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center px-2 py-12 text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-shell text-plum"><ShoppingBag className="h-7 w-7" aria-hidden /></span>
              <h3 className="mt-5 font-display text-[1.7rem] leading-tight text-plum">{t('co.empty')}</h3>
              <p className="mt-2 max-w-xs text-muted-foreground">{t('co.emptyHint')}</p>
              <button
                type="button"
                onClick={() => { setOpen(false); window.setTimeout(() => scrollToId('shop'), 280) }}
                className="press group mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-plum px-6 font-semibold text-porcelain hover:bg-plum-2"
              >
                {t('co.browse')} <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" aria-hidden />
              </button>
            </motion.div>
          ) : (
            <motion.form
              key="form"
              noValidate
              onSubmit={submit}
              exit={{ opacity: 0, y: -10, transition: { duration: 0.22, ease: EASE_OUT } }}
              className={desktop ? 'grid grid-cols-[minmax(0,1fr)_320px] items-start gap-8 lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-10' : 'flex flex-col'}
            >
              {!desktop && <MobileSummary total={total} money={money} label={t('co.summary')}>{summary}</MobileSummary>}

              <div className={cn('flex flex-col', desktop ? 'gap-9' : 'mt-7 gap-8')}>
                {/* 1 — details */}
                <Section index={0} n={1} title={t('co.s1')} done={nameOk && phoneOk}>
                  <div className="grid gap-4 lg:grid-cols-2">
                    <Field id="co-name" label={t('co.name')} error={errors.name}>
                      <input
                        ref={nameRef}
                        id="co-name"
                        autoComplete="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder={t('co.namePh')}
                        aria-invalid={!!errors.name}
                        aria-describedby={errors.name ? 'co-name-err' : undefined}
                        aria-required
                        className={INPUT}
                      />
                    </Field>
                    <Field id="co-phone" label={t('co.phone')} error={errors.phone} hint={t('co.phoneHint')}>
                      <input
                        ref={phoneRef}
                        id="co-phone"
                        type="tel"
                        inputMode="tel"
                        autoComplete="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder={t('co.phonePh')}
                        aria-invalid={!!errors.phone}
                        aria-describedby={errors.phone ? 'co-phone-err' : 'co-phone-hint'}
                        aria-required
                        className={cn(INPUT, 'tabular')}
                      />
                    </Field>
                  </div>
                </Section>

                {/* 2 — delivery */}
                <Section index={1} n={2} title={t('co.s2')}>
                  <DeliveryOptions
                    channel={channel}
                    onChange={setChannel}
                    options={[
                      { k: 'local', icon: Truck, title: t('co.local'), desc: t('co.localDesc'), fee: t('co.free') },
                      { k: 'pickup', icon: Store, title: t('co.pickup'), desc: t('co.pickupDesc'), fee: t('co.free') },
                      { k: 'ferry', icon: Ship, title: t('co.ferry'), desc: t('co.ferryDesc'), fee: subtotal >= threshold ? t('co.free') : money(ferryFee) },
                    ]}
                  />

                  <Unfold show={channel === 'local'}>
                    <Field id="co-area" label={t('co.area')}>
                      <input id="co-area" autoComplete="street-address" value={area} onChange={(e) => setArea(e.target.value)} placeholder={t('co.areaPh')} className={INPUT} />
                    </Field>
                  </Unfold>

                  <Unfold show={channel === 'pickup'}>
                    <div className="flex items-start gap-3 rounded-[16px] bg-shell/70 p-4">
                      <MapPin className="mt-0.5 h-[18px] w-[18px] shrink-0 text-plum" aria-hidden />
                      <div className="text-[0.95rem] leading-snug">
                        <div className="font-semibold text-foreground">{t('co.pickupFrom')}</div>
                        <div className="text-muted-foreground">{settings?.address || 'Mbweni, Zanzibar'}</div>
                        <div className="mt-1 text-muted-foreground">{t('co.pickupTime')}</div>
                      </div>
                    </div>
                  </Unfold>

                  <Unfold show={channel === 'ferry'}>
                    <div className="space-y-3">
                      <Field id="co-region" label={t('co.region')}>
                        <input id="co-region" autoComplete="address-level1" value={region} onChange={(e) => setRegion(e.target.value)} placeholder={t('co.regionPh')} className={INPUT} />
                      </Field>
                      <div className="flex items-start gap-3 rounded-[16px] bg-lagoon-deep/[0.07] p-4 text-[0.95rem] leading-snug">
                        <Ship className="mt-0.5 h-[18px] w-[18px] shrink-0 text-lagoon-deep" aria-hidden />
                        <div>
                          <p className="text-foreground">{settings?.ferryInfo || 'Mainland orders ship via Azam Ferry; collect at your nearest Azam office.'}</p>
                          <p className="mt-1.5 font-medium text-lagoon-deep">
                            {subtotal >= threshold
                              ? t('co.ferryFreeYes', { amount: money(threshold) })
                              : t('co.ferryFreeLeft', { amount: money(threshold - subtotal) })}
                          </p>
                        </div>
                      </div>
                    </div>
                  </Unfold>
                </Section>

                {/* 3 — notes and promo */}
                <Section index={2} n={3} title={t('co.s3')} optional={t('co.optional')} last>
                  <div className="space-y-4">
                    <Field id="co-notes" label={t('co.notes')}>
                      <textarea
                        id="co-notes"
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        rows={2}
                        placeholder={t('co.notesPh')}
                        className={cn(INPUT, 'h-auto min-h-[88px] resize-none py-3 leading-snug')}
                      />
                    </Field>
                    <PromoField
                      applied={promoApplied}
                      input={promoInput}
                      setInput={(v) => { setPromoInput(v); if (promoError) setPromoError('') }}
                      loading={promoLoading}
                      error={promoError}
                      onApply={applyPromo}
                      onRemove={removePromo}
                      offLabel={promoApplied ? t('co.promoOff', { amount: money(promoApplied.discount) }) : ''}
                    />
                  </div>
                </Section>
              </div>

              {desktop ? (
                <motion.aside
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: EASE_OUT, delay: 0.14 }}
                  className="sticky top-0 flex flex-col gap-4"
                  aria-label={t('co.summary')}
                >
                  <div className="rounded-[24px] bg-shell p-5">
                    <h3 className="font-display text-[1.35rem] leading-tight text-plum">{t('co.summary')}</h3>
                    <div className="mt-4">{summary}</div>
                  </div>
                  {placeButton}
                </motion.aside>
              ) : (
                <div className="sticky bottom-[calc(-1*max(20px,env(safe-area-inset-bottom)))] z-10 -mx-5 -mb-[max(20px,env(safe-area-inset-bottom))] mt-8 border-t border-border bg-card px-5 pb-[max(14px,env(safe-area-inset-bottom))] pt-3 shadow-[0_-10px_24px_-18px_rgb(31_7_14/0.35)]">
                  {placeButton}
                </div>
              )}
            </motion.form>
          )}
        </AnimatePresence>
      </MotionConfig>
    </ResponsiveSheet>
  )
}

/* ─────────────────────────── pieces ─────────────────────────── */

function Section({
  n, index, title, optional, done = false, last = false, children,
}: {
  n: number; index: number; title: string; optional?: string; done?: boolean; last?: boolean; children: React.ReactNode
}) {
  const id = useId()
  return (
    <motion.section
      aria-labelledby={id}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: EASE_OUT, delay: 0.06 + index * 0.06 }}
      className="relative"
    >
      {!last && <span aria-hidden className="absolute bottom-[-28px] left-[15px] top-10 hidden w-px bg-border md:block" />}
      <div className="flex items-center gap-3">
        <span
          aria-hidden
          className={cn(
            'relative grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-full text-sm font-semibold transition-colors duration-200',
            done ? 'bg-plum text-porcelain' : 'bg-shell text-plum',
          )}
        >
          <AnimatePresence initial={false} mode="popLayout">
            {done ? (
              <motion.span key="d" initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.4, opacity: 0 }} transition={SPRING_POP}>
                <Check className="h-4 w-4" strokeWidth={3} />
              </motion.span>
            ) : (
              <motion.span key="n" className="tabular" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }}>
                {n}
              </motion.span>
            )}
          </AnimatePresence>
        </span>
        <h3 id={id} className="font-display text-[1.3rem] leading-tight text-plum">
          <span className="sr-only">{n}. </span>{title}
        </h3>
        {optional && <span className="ml-auto text-sm text-muted-foreground">{optional}</span>}
      </div>
      <div className="mt-4 md:pl-11">{children}</div>
    </motion.section>
  )
}

function Field({ id, label, error, hint, children }: { id: string; label: string; error?: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-[0.92rem] font-medium text-foreground">{label}</label>
      {children}
      <AnimatePresence initial={false} mode="wait">
        {error ? (
          <motion.p
            key="err"
            id={`${id}-err`}
            role="alert"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2, ease: EASE_OUT }}
            className="mt-1.5 flex items-start gap-1.5 text-sm leading-snug text-destructive"
          >
            <AlertCircle className="mt-[2px] h-4 w-4 shrink-0" aria-hidden /> {error}
          </motion.p>
        ) : hint ? (
          <motion.p key="hint" id={`${id}-hint`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }} className="mt-1.5 text-sm leading-snug text-muted-foreground">
            {hint}
          </motion.p>
        ) : null}
      </AnimatePresence>
    </div>
  )
}

// Height reveal without animating height: a 0fr → 1fr grid row.
function Unfold({ show, children }: { show: boolean; children: React.ReactNode }) {
  return (
    <div
      aria-hidden={!show}
      inert={!show}
      className={cn(
        'grid transition-[grid-template-rows] duration-[320ms] ease-[cubic-bezier(.22,1,.36,1)]',
        show ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
      )}
    >
      <div className="min-h-0 overflow-hidden">
        <div className={cn('pt-4 transition-opacity duration-300', show ? 'opacity-100 delay-75' : 'opacity-0')}>{children}</div>
      </div>
    </div>
  )
}

type Opt = { k: Channel; icon: typeof Truck; title: string; desc: string; fee: string }

function DeliveryOptions({ channel, onChange, options }: { channel: Channel; onChange: (c: Channel) => void; options: Opt[] }) {
  const group = useId()
  return (
    <div role="radiogroup" className="grid gap-2.5 lg:grid-cols-3">
      {options.map((o) => {
        const sel = channel === o.k
        const Icon = o.icon
        return (
          <label
            key={o.k}
            className={cn(
              'press relative flex min-h-[76px] cursor-pointer items-center gap-3.5 rounded-[20px] bg-surface p-4 shadow-1 ring-1 ring-border',
              'has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-plum',
              'lg:flex-col lg:items-start lg:gap-3',
              !sel && 'hover:ring-plum/25',
            )}
          >
            <input type="radio" name={group} value={o.k} checked={sel} onChange={() => onChange(o.k)} className="sr-only" />
            {sel && (
              <motion.span
                layoutId="co-delivery-ring"
                aria-hidden
                className="pointer-events-none absolute inset-0 rounded-[20px] ring-2 ring-plum"
                transition={SPRING_SNAPPY}
              />
            )}
            <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-full transition-colors duration-200', sel ? 'bg-plum text-porcelain' : 'bg-shell text-plum')}>
              <Icon className="h-[18px] w-[18px]" aria-hidden />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-semibold leading-tight text-foreground">{o.title}</span>
              <span className="mt-1 block text-sm leading-snug text-muted-foreground">{o.desc}</span>
            </span>
            <span className={cn('shrink-0 text-sm font-semibold tabular transition-colors duration-200 lg:mt-auto', sel ? 'text-plum' : 'text-foreground/70')}>{o.fee}</span>
          </label>
        )
      })}
    </div>
  )
}

function PromoField({
  applied, input, setInput, loading, error, onApply, onRemove, offLabel,
}: {
  applied: { code: string; description: string; discount: number } | null
  input: string
  setInput: (v: string) => void
  loading: boolean
  error: string
  onApply: () => void
  onRemove: () => void
  offLabel: string
}) {
  const { t } = useI18n()
  return (
    <div>
      <label htmlFor="co-promo" className={cn('mb-1.5 block text-[0.92rem] font-medium text-foreground', applied && 'sr-only')}>{t('co.promo')}</label>
      <AnimatePresence mode="wait" initial={false}>
        {applied ? (
          <motion.div
            key="chip"
            initial={{ opacity: 0, scale: 0.92 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={SPRING_SNAPPY}
            className="flex flex-wrap items-center gap-3"
          >
            <span className="inline-flex h-11 items-center gap-2 rounded-full bg-lagoon-deep pl-4 text-[0.95rem] font-semibold text-white shadow-1">
              <Tag className="h-4 w-4" aria-hidden />
              <span className="tracking-wide">{applied.code}</span>
              <button
                type="button"
                onClick={onRemove}
                aria-label={t('co.promoRemove', { code: applied.code })}
                className="press -ml-0.5 grid h-11 w-11 place-items-center rounded-full hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-surface"
              >
                <X className="h-4 w-4" aria-hidden />
              </button>
            </span>
            <span className="text-sm font-semibold text-lagoon-deep">{offLabel}</span>
            {applied.description && <span className="w-full text-sm text-muted-foreground">{applied.description}</span>}
          </motion.div>
        ) : (
          <motion.div key="input" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <input
                  id="co-promo"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); onApply() } }}
                  placeholder={t('co.promoPh')}
                  autoCapitalize="characters"
                  aria-invalid={!!error}
                  aria-describedby={error ? 'co-promo-err' : undefined}
                  className={cn(INPUT, 'pl-10 uppercase placeholder:normal-case')}
                />
              </div>
              <button
                type="button"
                onClick={onApply}
                disabled={loading || !input.trim()}
                className="press inline-flex h-12 min-w-[96px] items-center justify-center gap-2 rounded-full bg-surface px-5 font-semibold text-plum shadow-1 ring-1 ring-border hover:bg-shell focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum disabled:cursor-not-allowed disabled:opacity-50"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : t('co.apply')}
              </button>
            </div>
            <AnimatePresence initial={false}>
              {error ? (
                <motion.p
                  key="e"
                  id="co-promo-err"
                  role="alert"
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2, ease: EASE_OUT }}
                  className="mt-1.5 flex items-start gap-1.5 text-sm text-destructive"
                >
                  <AlertCircle className="mt-[2px] h-4 w-4 shrink-0" aria-hidden /> {error}
                </motion.p>
              ) : null}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function SummaryBody({
  items, subtotal, shipping, shippingLabel, discount, promoCode, total,
}: {
  items: CartItem[]; subtotal: number; shipping: number; shippingLabel: string; discount: number; promoCode?: string; total: number
}) {
  const { t } = useI18n()
  const money = useMoney()
  return (
    <div>
      <ul className="-mr-2 max-h-[248px] space-y-3 overflow-y-auto overscroll-contain pr-2 pt-1.5 scrollbar-thin">
        {items.map((it) => (
          <li key={it.productId} className="flex items-center gap-3">
            <span className="relative h-14 w-14 shrink-0">
              <span className="absolute inset-0 overflow-hidden rounded-[14px] bg-surface">
                {it.image ? <Image src={it.image} alt="" fill sizes="56px" className={fit(it.image, 'sm')} /> : <Package className="m-auto mt-4 h-6 w-6 text-plum/50" aria-hidden />}
              </span>
              <span className="absolute -right-1.5 -top-1.5 grid h-6 min-w-6 place-items-center rounded-full bg-plum px-1.5 text-xs font-semibold text-porcelain tabular ring-2 ring-shell">
                {it.qty}
              </span>
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate font-medium leading-tight text-foreground">{it.name}</span>
              <span className="mt-0.5 block text-sm text-muted-foreground">{it.qty} × {money(it.price)}</span>
            </span>
            <span className="shrink-0 text-[0.95rem] font-semibold tabular text-foreground">{money(it.price * it.qty)}</span>
          </li>
        ))}
      </ul>
      <dl className="mt-5 space-y-2.5 border-t border-plum/10 pt-4 text-[0.95rem]">
        <Row label={t('co.subtotal')}><NumberRoll value={money(subtotal)} /></Row>
        <Row label={t('co.shipping')}>
          <AnimatePresence mode="wait" initial={false}>
            <motion.span key={shipping > 0 ? 'fee' : 'free'} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2, ease: EASE_OUT }} className={cn('inline-flex', shipping === 0 && 'text-lagoon-deep')}>
              {shipping > 0 ? <NumberRoll value={shippingLabel} /> : shippingLabel}
            </motion.span>
          </AnimatePresence>
        </Row>
        <div className={cn('grid transition-[grid-template-rows] duration-300 ease-[cubic-bezier(.22,1,.36,1)]', discount > 0 ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]')}>
          <div className="min-h-0 overflow-hidden">
            <Row label={promoCode ? `${t('co.discount')} · ${promoCode}` : t('co.discount')} className="text-lagoon-deep">
              <span className="inline-flex items-center">−<NumberRoll value={money(discount)} /></span>
            </Row>
          </div>
        </div>
      </dl>
      <div className="mt-4 flex items-baseline justify-between border-t border-plum/10 pt-4">
        <span className="font-semibold text-foreground">{t('co.total')}</span>
        <NumberRoll value={money(total)} className="font-display text-[1.75rem] leading-none text-plum" />
      </div>
    </div>
  )
}

function Row({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('flex items-center justify-between gap-3', className)}>
      <dt className={className ? undefined : 'text-muted-foreground'}>{label}</dt>
      <dd className="font-semibold tabular">{children}</dd>
    </div>
  )
}

function MobileSummary({ total, money, label, children }: { total: number; money: (n: number) => string; label: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const id = useId()
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, ease: EASE_OUT }} className="rounded-[20px] bg-shell">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={id}
        onClick={() => setOpen((v) => !v)}
        className="press flex h-14 w-full items-center justify-between gap-3 rounded-[20px] px-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum"
      >
        <span className="flex items-center gap-2.5 font-medium text-plum">
          <ShoppingBag className="h-[18px] w-[18px]" aria-hidden /> {label}
        </span>
        <span className="flex items-center gap-2 font-semibold text-foreground">
          <NumberRoll value={money(total)} />
          <ChevronDown className={cn('h-[18px] w-[18px] text-plum transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)]', open && 'rotate-180')} aria-hidden />
        </span>
      </button>
      <div id={id} className={cn('grid transition-[grid-template-rows] duration-[320ms] ease-[cubic-bezier(.22,1,.36,1)]', open ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]')} inert={!open}>
        <div className="min-h-0 overflow-hidden">
          <div className={cn('px-4 pb-4 transition-opacity duration-300', open ? 'opacity-100' : 'opacity-0')}>{children}</div>
        </div>
      </div>
    </motion.div>
  )
}

/* ─────────────────────────── success ─────────────────────────── */

function SuccessView({
  order, waPrimary, waSecondary, message, onTrack, onKeepShopping,
}: {
  order: ApiOrder; waPrimary: string; waSecondary: string; message: string; onTrack: () => void; onKeepShopping: () => void
}) {
  const { t } = useI18n()
  const money = useMoney()
  const reduce = useReducedMotion()
  const [copied, setCopied] = useState(false)
  const count = order.items.reduce((n, i) => n + i.qty, 0)
  const rootRef = useRef<HTMLDivElement>(null)

  // The form was probably scrolled; start the confirmation at the top.
  useEffect(() => {
    let el = rootRef.current?.parentElement
    while (el && !(el.scrollHeight > el.clientHeight && /(auto|scroll)/.test(getComputedStyle(el).overflowY))) el = el.parentElement
    if (el) el.scrollTop = 0
  }, [])

  useEffect(() => {
    if (!copied) return
    const id = window.setTimeout(() => setCopied(false), 1800)
    return () => window.clearTimeout(id)
  }, [copied])

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(order.orderNumber)
    } catch {
      const ta = document.createElement('textarea')
      ta.value = order.orderNumber
      ta.setAttribute('readonly', '')
      ta.style.position = 'fixed'; ta.style.opacity = '0'
      document.body.appendChild(ta); ta.select()
      try { document.execCommand('copy') } catch { /* nothing more we can do */ }
      ta.remove()
    }
    setCopied(true)
  }

  const rise = (i: number) => ({
    initial: reduce ? false : { opacity: 0, y: 14 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5, ease: EASE_OUT, delay: 0.42 + i * 0.06 },
  })

  return (
    <div ref={rootRef} className="mx-auto flex max-w-md flex-col items-center pb-2 pt-6 text-center md:pt-8">
      {/* drawn check */}
      <div className="relative grid h-20 w-20 place-items-center">
        {!reduce && (
          <motion.span
            aria-hidden
            className="absolute inset-0 rounded-full bg-lagoon-deep/30"
            initial={{ scale: 1, opacity: 0.7 }}
            animate={{ scale: 1.75, opacity: 0 }}
            transition={{ duration: 0.9, delay: 0.3, ease: EASE_OUT }}
          />
        )}
        <motion.span
          aria-hidden
          className="absolute inset-0 rounded-full bg-lagoon-deep shadow-2"
          initial={reduce ? false : { scale: 0.55, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={SPRING_POP}
        />
        <svg viewBox="0 0 48 48" className="relative h-11 w-11" fill="none" aria-hidden>
          <motion.path
            d="M13 25.5l7 7 15-16"
            stroke="white"
            strokeWidth={4.2}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray={34}
            initial={reduce ? false : { strokeDashoffset: 34 }}
            animate={{ strokeDashoffset: 0 }}
            transition={{ duration: 0.5, delay: 0.26, ease: EASE_OUT }}
          />
        </svg>
      </div>

      <motion.h2 {...rise(0)} className="mt-6 font-display text-[2.3rem] leading-none text-plum">{t('co.placed')}</motion.h2>
      <motion.p {...rise(1)} className="mt-2.5 text-[1.02rem] text-muted-foreground">
        {t('co.thanks', { name: order.customerName.split(' ')[0] })}
      </motion.p>

      <motion.div {...rise(2)} className="mt-5 flex flex-col items-center gap-1.5">
        <span className="text-sm text-muted-foreground">{t('co.orderNo')}</span>
        <button
          type="button"
          onClick={copy}
          aria-label={t('co.copy', { n: order.orderNumber })}
          className="press inline-flex h-12 items-center gap-2.5 rounded-full bg-shell pl-5 pr-4 text-[1.05rem] font-semibold tracking-wide text-plum hover:bg-sand focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum"
        >
          <span className="tabular">{order.orderNumber}</span>
          <span className="relative grid h-7 min-w-7 place-items-center overflow-hidden rounded-full bg-surface px-1.5 text-xs font-semibold shadow-1">
            <AnimatePresence mode="popLayout" initial={false}>
              {copied ? (
                <motion.span key="ok" className="flex items-center gap-1 px-0.5 text-lagoon-deep" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2, ease: EASE_OUT }}>
                  <Check className="h-3.5 w-3.5" strokeWidth={3} aria-hidden /> {t('co.copied')}
                </motion.span>
              ) : (
                <motion.span key="cp" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2, ease: EASE_OUT }}>
                  <Copy className="h-3.5 w-3.5" aria-hidden />
                </motion.span>
              )}
            </AnimatePresence>
          </span>
        </button>
        <span className="sr-only" aria-live="polite">{copied ? t('co.copied') : ''}</span>
      </motion.div>

      <motion.p {...rise(3)} className="mt-6 text-[1rem] leading-relaxed text-foreground/85">
        {t('co.lastStep')}
      </motion.p>
      <motion.div {...rise(3)} className="mt-4 inline-flex items-center gap-3 rounded-full bg-shell/70 py-1.5 pl-1.5 pr-4">
        <span className="flex -space-x-2.5" aria-hidden>
          {order.items.filter((i) => i.image).slice(0, 3).map((it, k) => (
            <span key={it.productId} className="relative h-9 w-9 overflow-hidden rounded-full bg-surface ring-2 ring-surface" style={{ zIndex: 3 - k }}>
              <Image src={it.image} alt="" fill sizes="36px" className={fit(it.image, 'sm')} />
            </span>
          ))}
        </span>
        <span className="text-[0.92rem] font-medium text-foreground tabular">
          {t('co.recap', { items: count === 1 ? t('co.item1') : t('co.itemsN', { n: count }), total: money(order.total) })}
        </span>
      </motion.div>

      <motion.div {...rise(4)} className="mt-6 w-full">
        <a
          href={whatsappLink(waPrimary, message)}
          target="_blank"
          rel="noreferrer"
          className="press group flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-[#1f8a5a] px-6 text-[1.05rem] font-semibold text-white shadow-2 hover:bg-[#1a774e] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1f8a5a] focus-visible:ring-offset-2"
        >
          <MessageCircle className="h-5 w-5" aria-hidden />
          {t('co.sendWa')}
          <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-1" aria-hidden />
        </a>
        <p className="mt-2.5 text-sm text-muted-foreground tabular">{t('co.waTo', { phone: displayPhone(waPrimary) })}</p>
        {waSecondary && (
          <a
            href={whatsappLink(waSecondary, message)}
            target="_blank"
            rel="noreferrer"
            className="mt-1 inline-flex min-h-11 items-center text-sm font-semibold text-[#1a774e]"
          >
            <span className="link-draw tabular">{t('co.waSecondary', { phone: displayPhone(waSecondary) })}</span>
          </a>
        )}
      </motion.div>

      <motion.div {...rise(5)} className="mt-5 flex w-full flex-col items-center justify-center gap-2 border-t border-border pt-5 sm:flex-row sm:gap-3">
        <button
          type="button"
          onClick={onTrack}
          className="press inline-flex h-11 items-center gap-2 rounded-full bg-surface px-5 font-semibold text-plum shadow-1 ring-1 ring-border hover:bg-shell focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum"
        >
          <Package className="h-4 w-4" aria-hidden /> {t('co.trackThis')}
        </button>
        <button
          type="button"
          onClick={onKeepShopping}
          className="inline-flex min-h-11 items-center px-3 font-semibold text-plum focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum rounded-full"
        >
          <span className="link-draw">{t('co.keepShopping')}</span>
        </button>
      </motion.div>
    </div>
  )
}
