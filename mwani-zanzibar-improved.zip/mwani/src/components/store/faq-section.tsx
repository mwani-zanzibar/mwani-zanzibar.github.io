'use client'

import { useId, useState } from 'react'
import Image from 'next/image'
import { MessageCircle, Plus } from 'lucide-react'
import { useI18n } from '@/lib/i18n'
import { whatsappLink } from '@/lib/format'
import { Reveal, SplitReveal, Stagger, StaggerItem } from '@/components/shared/reveal'
import { cn } from '@/lib/utils'
import type { ApiSettings } from '@/lib/api'
import { useImg } from '@/lib/content-store'

const WA_GREEN = '#1f8a5a'
const ITEMS = [1, 2, 3, 4, 5, 6]

export function FaqSection({ settings }: { settings: ApiSettings | null }) {
  const { t } = useI18n()
  const [open, setOpen] = useState<number | null>(null)
  const wa = whatsappLink(settings?.whatsappPrimary || '+255774870703', t('faq.curious.msg'))

  return (
    <section id="faq" className="relative mx-auto max-w-[88rem] px-4 py-16 sm:px-8 sm:py-32 lg:px-12">
      <div className="grid gap-10 lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-4">
          <div className="lg:sticky lg:top-28">
            <SplitReveal as="h2" text={t('faq.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-[1] text-plum" />
            <Reveal delay={0.1}><p className="mt-4 max-w-[22rem] text-[1.05rem] leading-[1.6] text-foreground/75">{t('faq.body')}</p></Reveal>

            <Reveal delay={0.2} y={30} className="mt-8 hidden lg:block">
              <CuriousCard href={wa} />
            </Reveal>
          </div>
        </div>

        <Stagger as="ul" className="flex flex-col gap-3 lg:col-span-7 lg:col-start-6">
          {ITEMS.map((n) => (
            <StaggerItem as="li" key={n}>
              <FaqItem n={n} on={open === n} toggle={() => setOpen(open === n ? null : n)} />
            </StaggerItem>
          ))}
        </Stagger>

        <Reveal y={30} className="lg:hidden">
          <CuriousCard href={wa} />
        </Reveal>
      </div>
    </section>
  )
}

function CuriousCard({ href }: { href: string }) {
  const markSrc = useImg('brand.mark', '/brand/mwani-mark.png')
  const { t } = useI18n()
  return (
    <div className="relative overflow-hidden rounded-[28px] bg-shell p-6 shadow-1 sm:p-7">
      <Image src={markSrc} alt="" width={120} height={120} aria-hidden
        className="pointer-events-none absolute -right-3 -top-3 h-20 w-20 rotate-[14deg] opacity-90 sm:-right-5 sm:-top-4 sm:h-28 sm:w-28" />
      <h3 className="font-display max-w-[70%] text-[1.6rem] leading-[1.1] text-plum">{t('faq.curious.t')}</h3>
      <p className="mt-2 max-w-[calc(100%-3.5rem)] text-[1rem] leading-[1.55] text-foreground/75 sm:max-w-[20rem]">{t('faq.curious.d')}</p>
      <a href={href} target="_blank" rel="noopener noreferrer"
        className="group press mt-6 inline-flex h-12 items-center gap-2.5 rounded-full pl-4 pr-5 text-[0.96rem] font-medium text-white shadow-1 hover:brightness-110"
        style={{ backgroundColor: WA_GREEN }}>
        <MessageCircle aria-hidden className="h-5 w-5 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-rotate-12" />
        {t('faq.curious.cta')}
      </a>
    </div>
  )
}

function FaqItem({ n, on, toggle }: { n: number; on: boolean; toggle: () => void }) {
  const { t } = useI18n()
  const id = useId()
  return (
    <div className={cn(
      'rounded-[22px] bg-surface outline outline-[1.5px] -outline-offset-[1.5px] transition-[box-shadow,transform,outline-color] duration-300 ease-[cubic-bezier(.22,1,.36,1)]',
      on ? 'shadow-2 -translate-y-0.5 outline-plum/40' : 'shadow-1 outline-transparent hover:shadow-2',
    )}>
      <h3>
        <button type="button" id={`${id}-q`} aria-expanded={on} aria-controls={`${id}-a`} onClick={toggle}
          className="group flex min-h-16 w-full items-center justify-between gap-5 rounded-[22px] px-5 py-4 text-left sm:px-6">
          <span className="text-[1.04rem] font-medium leading-snug text-plum">{t(`faq.q${n}`)}</span>
          <span aria-hidden className={cn(
            'grid h-10 w-10 shrink-0 place-items-center rounded-full transition-[background-color,color,transform] duration-300 ease-[cubic-bezier(.22,1,.36,1)]',
            on ? 'rotate-45 bg-plum text-porcelain' : 'bg-shell text-plum group-hover:bg-sand',
          )}>
            <Plus className="h-5 w-5" />
          </span>
        </button>
      </h3>
      <div id={`${id}-a`} role="region" aria-labelledby={`${id}-q`}
        className={cn('grid transition-[grid-template-rows] duration-[380ms] ease-[cubic-bezier(.22,1,.36,1)]', on ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]')}>
        <div className="overflow-hidden" inert={!on}>
          <p className={cn(
            'px-5 pb-6 pr-16 text-[1rem] leading-[1.65] text-foreground/75 transition-[opacity,transform] duration-300 ease-[cubic-bezier(.22,1,.36,1)] sm:px-6 sm:pr-20',
            on ? 'translate-y-0 opacity-100 delay-75' : '-translate-y-1.5 opacity-0',
          )}>{t(`faq.a${n}`)}</p>
        </div>
      </div>
    </div>
  )
}
