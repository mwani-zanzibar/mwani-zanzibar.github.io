'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, motion, useMotionValueEvent, useScroll, useSpring, useTransform, type MotionValue } from 'framer-motion'
import { Check, Plus, Sparkles, CookingPot, Leaf } from 'lucide-react'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { useCart } from '@/lib/cart-store'
import { useUI } from '@/lib/ui-store'
import { flyToCart } from '@/lib/cart-fx'
import { getTier } from '@/lib/perf'
import { pickHeroes, useHeroImages, type HeroKey } from '@/lib/hero-products'
import { SplitReveal } from '@/components/motion/split-reveal'
import { NumberRoll } from '@/components/motion/number-roll'
import { Reveal, EASE_OUT, SPRING_SNAPPY } from '@/components/shared/reveal'
import type { ApiProduct } from '@/lib/api'

const KEYS: HeroKey[] = ['powder', 'tea']

function facts(p: ApiProduct | undefined, t: (k: string) => string) {
  if (!p) return []
  return [
    { icon: Leaf, label: t('duo.inside'), body: p.ingredients.join(', ') },
    { icon: CookingPot, label: t('duo.use'), body: p.howToUse },
    { icon: Sparkles, label: t('duo.good'), chips: p.benefits.slice(0, 4) },
  ]
}

function useAdd(p: ApiProduct | undefined) {
  const add = useCart((s) => s.add)
  const [added, setAdded] = useState(false)
  const go = (el: HTMLElement | null) => {
    if (!p || p.stock <= 0) return
    add({ productId: p.id, name: p.name, price: p.price, unit: p.unit, image: p.image, stock: p.stock })
    flyToCart(el)
    setAdded(true); setTimeout(() => setAdded(false), 1600)
  }
  return { added, go }
}

function AddButton({ added, onClick, label, dark = false }: { added: boolean; onClick: () => void; label: string; dark?: boolean }) {
  const { t } = useI18n()
  return (
    <motion.button layout whileTap={{ scale: 0.97 }} onClick={onClick} transition={SPRING_SNAPPY}
      className={`flex h-13 min-h-[52px] items-center gap-2 overflow-hidden rounded-full px-6 text-[0.98rem] font-semibold transition-colors duration-200 ${added ? 'bg-lagoon-deep text-white' : dark ? 'bg-on-night text-night hover:bg-white' : 'bg-plum text-porcelain hover:bg-plum-2'}`}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span key={added ? 'a' : 'b'} initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -20, opacity: 0 }} transition={{ duration: 0.2 }} className="flex items-center gap-2">
          {added ? <Check className="h-5 w-5" aria-hidden /> : <Plus className="h-5 w-5" aria-hidden />}{added ? t('hx.added') : label}
        </motion.span>
      </AnimatePresence>
    </motion.button>
  )
}

// A fact card that enters and leaves on its own slice of the scroll.
function StepCard({ progress, from, to, children }: { progress: MotionValue<number>; from: number; to: number; children: React.ReactNode }) {
  // In over the first slice of its window, out over the last, so neighbours never overlap.
  const opacity = useTransform(progress, [from, from + 0.035, to - 0.035, to], [0, 1, 1, 0])
  const y = useTransform(progress, [from, from + 0.035, to - 0.035, to], [40, 0, 0, -30])
  const scale = useTransform(progress, [from, from + 0.035], [0.94, 1])
  return <motion.div style={{ opacity, y, scale }} className="rounded-[24px] bg-surface p-5 shadow-3">{children}</motion.div>
}

function Pinned({ products }: { products: ApiProduct[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const setQuick = useUI((s) => s.setQuick)
  const heroes = pickHeroes(products)
  const { cut: HERO_CUT } = useHeroImages()
  const ref = useRef<HTMLDivElement>(null)
  const shots = { powder: useRef<HTMLDivElement>(null), tea: useRef<HTMLDivElement>(null) }
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end end'] })
  const p = useSpring(scrollYProgress, { stiffness: 140, damping: 30, mass: 0.4 })
  const [key, setKey] = useState<HeroKey>('powder')
  useMotionValueEvent(p, 'change', (v) => setKey(v < 0.5 ? 'powder' : 'tea'))
  const teaBg = useTransform(p, [0.4, 0.6], [0, 1])
  // Powder hands over to Tea: one real scene slides out left as the next rises in from the right.
  const aX = useTransform(p, [0.42, 0.58], ['0%', '-38%'])
  const aO = useTransform(p, [0.42, 0.53], [1, 0])
  const bX = useTransform(p, [0.42, 0.58], ['38%', '0%'])
  const bO = useTransform(p, [0.47, 0.58], [0, 1])
  const pScale = useTransform(p, [0, 0.12, 0.5, 0.88, 1], [0.9, 1, 0.94, 1, 0.96])
  const lift = useTransform(p, [0, 0.12], [40, 0])
  const rail = useTransform(p, [0, 1], [0, 1])
  const prod = heroes[key]
  const { added, go } = useAdd(prod)
  const fs = facts(prod, t)
  const slots = key === 'powder' ? [[0.04, 0.19], [0.19, 0.33], [0.33, 0.46]] : [[0.54, 0.68], [0.68, 0.82], [0.82, 1.01]]

  return (
    <div ref={ref} className="relative h-[420vh]">
      <div className="sticky top-3 mx-3 flex h-[calc(100vh-24px)] items-center overflow-hidden rounded-[40px] bg-[var(--powder-a)]">
        <motion.div aria-hidden style={{ opacity: teaBg }} className="pointer-events-none absolute inset-0 bg-[var(--tea-a)]" />
        <div className="relative mx-auto grid w-full max-w-[84rem] grid-cols-12 items-center gap-6 px-12">
          <div className="col-span-4">
            <AnimatePresence mode="wait">
              <motion.div key={key} initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.45, ease: EASE_OUT }}>
                <p className="text-sm font-semibold text-plum/70">{key === 'powder' ? '01' : '02'} / 02</p>
                <h3 className="font-display mt-3 text-[clamp(3rem,5vw,5rem)] leading-[0.95] text-plum">{t(`duo.${key}.name`)}</h3>
                {prod && <p className="mt-4 max-w-sm text-[1.02rem] leading-relaxed text-foreground/75">{prod.tagline}</p>}
                {prod && (
                  <div className="mt-7 flex flex-wrap items-center gap-3">
                    <span className="rounded-full bg-surface px-4 py-3 text-[1.05rem] font-semibold text-plum shadow-1">{money(prod.price)} <span className="font-normal text-muted-foreground">· {prod.unit}</span></span>
                    <AddButton added={added} onClick={() => go(shots[key].current)} label={t('hx.add')} />
                    <button onClick={() => prod && setQuick(prod)} className="link-draw text-[0.95rem] font-semibold text-plum">{t('duo.view')}</button>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="col-span-4 flex justify-center">
            <motion.div style={{ y: lift, scale: pScale }} className="relative -mx-[12%] aspect-[1.15] w-[124%] max-w-[560px]">
              <div aria-hidden className="absolute -bottom-[2%] left-1/2 h-[12%] w-[80%] -translate-x-1/2 rounded-[50%] bg-[radial-gradient(closest-side,rgba(31,7,14,0.24),rgba(31,7,14,0))]" />
              <motion.div ref={shots.powder} style={{ x: aX, opacity: aO }} className="absolute inset-0">
                <Image src={HERO_CUT.powder} alt="" fill sizes="560px" className="object-contain object-bottom drop-shadow-[0_24px_28px_rgba(31,7,14,0.22)]" />
              </motion.div>
              <motion.div ref={shots.tea} style={{ x: bX, opacity: bO }} className="absolute inset-0">
                <Image src={HERO_CUT.tea} alt="" fill sizes="560px" className="object-contain object-bottom drop-shadow-[0_24px_28px_rgba(31,7,14,0.22)]" />
              </motion.div>
            </motion.div>
          </div>

          <div className="relative col-span-4 h-[62vh] max-h-[560px]">
            {fs.map((f, i) => (
              <div key={`${key}-${i}`} className="absolute inset-x-0 top-1/2 -translate-y-1/2">
                <StepCard progress={p} from={slots[i][0]} to={slots[i][1]}>
                  <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-shell text-plum"><f.icon className="h-5 w-5" aria-hidden /></span>
                    <span className="text-sm font-semibold text-muted-foreground">{f.label}</span>
                  </div>
                  {f.body && <p className="font-display mt-4 text-[1.55rem] leading-snug text-plum">{f.body}</p>}
                  {f.chips && (
                    <ul className="mt-4 flex flex-wrap gap-2">
                      {f.chips.map((c) => <li key={c} className="rounded-full bg-shell px-3.5 py-2 text-[0.92rem] font-medium text-plum">{c}</li>)}
                    </ul>
                  )}
                </StepCard>
              </div>
            ))}
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 flex -translate-x-1/2 items-center gap-4">
          {KEYS.map((k) => (
            <span key={k} className={`text-sm font-semibold transition-colors duration-300 ${key === k ? 'text-plum' : 'text-plum/40'}`}>{t(`hx.${k}`)}</span>
          )).reduce<React.ReactNode[]>((acc, el, i) => (i ? [...acc, <span key="rail" className="relative h-1 w-40 overflow-hidden rounded-full bg-plum/15"><motion.span style={{ scaleX: rail }} className="absolute inset-0 origin-left rounded-full bg-plum" /></span>, el] : [el]), [])}
        </div>
      </div>
    </div>
  )
}

function Stacked({ products }: { products: ApiProduct[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const setQuick = useUI((s) => s.setQuick)
  const heroes = pickHeroes(products)
  return (
    <div className="mx-auto grid max-w-[84rem] gap-4 px-3 sm:px-6 md:grid-cols-2">
      {KEYS.map((k) => <StackedCard key={k} k={k} p={heroes[k]} t={t} money={money} onView={setQuick} />)}
    </div>
  )
}

function StackedCard({ k, p, t, money, onView }: { k: HeroKey; p?: ApiProduct; t: (s: string) => string; money: (n: number) => string; onView: (p: ApiProduct) => void }) {
  const img = useRef<HTMLDivElement>(null)
  const { cut: HERO_CUT } = useHeroImages()
  const { added, go } = useAdd(p)
  if (!p) return null
  return (
    <Reveal className="overflow-hidden rounded-[32px]" y={30}>
      <div style={{ background: k === 'powder' ? 'linear-gradient(160deg,var(--powder-a),var(--powder-b))' : 'linear-gradient(160deg,var(--tea-a),var(--tea-b))' }} className="p-5 sm:p-7">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-[2.4rem] leading-none text-plum">{t(`duo.${k}.name`)}</h3>
            <p className="mt-2 text-[0.98rem] text-foreground/75">{p.tagline}</p>
          </div>
          <span className="shrink-0 rounded-full bg-surface px-3 py-2 text-sm font-semibold text-plum shadow-1">{money(p.price)}</span>
        </div>
        <motion.div ref={img} initial={{ y: 30, opacity: 0, scale: 0.96 }} whileInView={{ y: 0, opacity: 1, scale: 1 }} viewport={{ once: true, margin: '-10%' }} transition={{ duration: 0.9, ease: EASE_OUT }}
          className="relative mx-auto my-5 aspect-[1.25] w-full max-w-[24rem]">
          <Image src={HERO_CUT[k]} alt="" fill sizes="(max-width: 768px) 90vw, 400px" className="object-contain object-bottom drop-shadow-[0_20px_24px_rgba(31,7,14,0.22)]" />
        </motion.div>
        <ul className="space-y-2">
          {facts(p, t).map((f) => (
            <li key={f.label} className="rounded-[20px] bg-surface/85 p-4">
              <p className="flex items-center gap-2 text-xs font-semibold text-muted-foreground"><f.icon className="h-4 w-4 text-plum" aria-hidden />{f.label}</p>
              {f.body && <p className="mt-1.5 text-[0.98rem] font-medium leading-snug text-plum">{f.body}</p>}
              {f.chips && <div className="mt-2 flex flex-wrap gap-1.5">{f.chips.map((c) => <span key={c} className="rounded-full bg-shell px-2.5 py-1 text-xs font-medium text-plum">{c}</span>)}</div>}
            </li>
          ))}
        </ul>
        <div className="mt-5 flex items-center gap-3">
          <AddButton added={added} onClick={() => go(img.current)} label={t('hx.add')} />
          <button onClick={() => onView(p)} className="link-draw text-[0.95rem] font-semibold text-plum">{t('duo.view')}</button>
        </div>
      </div>
    </Reveal>
  )
}

function BothCard({ products }: { products: ApiProduct[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const add = useCart((s) => s.add)
  const { powder, tea } = pickHeroes(products)
  const { cut: HERO_CUT } = useHeroImages()
  const a = useRef<HTMLDivElement>(null), b = useRef<HTMLDivElement>(null)
  const [done, setDone] = useState(false)
  if (!powder || !tea) return null
  const both = () => {
    for (const p of [powder, tea]) add({ productId: p.id, name: p.name, price: p.price, unit: p.unit, image: p.image, stock: p.stock })
    flyToCart(a.current); setTimeout(() => flyToCart(b.current), 140)
    setDone(true); setTimeout(() => setDone(false), 1800)
  }
  return (
    <Reveal y={30} className="mx-auto mt-4 max-w-[84rem] px-3 sm:mt-6 sm:px-6">
      <div className="relative flex flex-col items-center gap-6 overflow-hidden rounded-[32px] bg-night px-6 py-8 text-on-night sm:flex-row sm:px-10 sm:py-9">
        <div className="flex -space-x-8">
          <motion.div ref={a} whileHover={{ rotate: -10, y: -6 }} className="relative h-24 w-32 -rotate-3"><Image src={HERO_CUT.powder} alt="" fill sizes="128px" className="object-contain object-bottom" /></motion.div>
          <motion.div ref={b} whileHover={{ rotate: 10, y: -6 }} className="relative h-24 w-32 rotate-3"><Image src={HERO_CUT.tea} alt="" fill sizes="128px" className="object-contain object-bottom" /></motion.div>
        </div>
        <div className="text-center sm:text-left">
          <p className="font-display text-[2rem] leading-tight">{t('duo.both')}</p>
          <p className="mt-1 text-on-night/70">{t('duo.bothBody')}</p>
        </div>
        <div className="flex flex-col items-center gap-3 sm:ml-auto sm:flex-row">
          <NumberRoll value={money(powder.price + tea.price)} className="text-[1.4rem] font-semibold" />
          <AddButton added={done} onClick={both} label={t('duo.addBoth')} dark />
        </div>
      </div>
    </Reveal>
  )
}

export function DuoSection({ products }: { products: ApiProduct[] }) {
  const { t } = useI18n()
  const [pinned, setPinned] = useState(false)
  useEffect(() => {
    const m = window.matchMedia('(min-width: 1024px) and (min-height: 640px)')
    const on = () => setPinned(m.matches && getTier() > 0)
    on(); m.addEventListener('change', on)
    return () => m.removeEventListener('change', on)
  }, [])
  return (
    <section id="duo" className="pt-16 sm:pt-28">
      <div className="mx-auto mb-10 flex max-w-[84rem] flex-wrap items-end justify-between gap-4 px-5 sm:px-10 lg:px-14">
        <SplitReveal as="h2" text={t('duo.title')} className="font-display max-w-3xl text-[clamp(2.4rem,5vw,4.6rem)] leading-[0.98] text-plum" />
        <Reveal delay={0.1}><p className="max-w-sm text-[1.02rem] text-foreground/75">{t('duo.body')}</p></Reveal>
      </div>
      {pinned ? <Pinned products={products} /> : <Stacked products={products} />}
      <BothCard products={products} />
    </section>
  )
}
