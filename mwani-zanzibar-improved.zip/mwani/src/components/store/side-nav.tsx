'use client'

import { useEffect, useLayoutEffect, useState } from 'react'
import Image from 'next/image'
import * as Dialog from '@radix-ui/react-dialog'
import { AnimatePresence, MotionConfig, motion, useReducedMotion } from 'framer-motion'
import { useTheme } from 'next-themes'
import { ArrowRight, ChevronRight, Heart, Instagram, Mail, MessageCircle, MonitorSmartphone, Moon, PackageSearch, ReceiptText, Search, ShieldCheck, Sun } from 'lucide-react'
import { switchTheme, type ThemeChoice } from '@/lib/theme-switch'
import { NumberRoll } from '@/components/motion/number-roll'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { EASE_OUT, SPRING_SNAPPY } from '@/components/shared/reveal'
import { useUI } from '@/lib/ui-store'
import { useWishlist } from '@/lib/wishlist-store'
import { useCurrency, type Currency } from '@/lib/currency-store'
import { useI18n, type Lang } from '@/lib/i18n'
import { whatsappLink } from '@/lib/format'
import type { ApiSettings } from '@/lib/api'
import { cn } from '@/lib/utils'
import { useImg } from '@/lib/content-store'

const useIsoLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect

const LINKS = [
  { id: 'shop', key: 'menu.shop' },
  { id: 'duo', key: 'menu.duo' },
  { id: 'story', key: 'menu.story' },
  { id: 'recipes', key: 'menu.recipes' },
  { id: 'how', key: 'menu.how' },
  { id: 'faq', key: 'menu.faq' },
]

function prettyPhone(p: string) {
  const d = p.replace(/[^\d+]/g, '')
  const m = d.match(/^\+?255(\d{3})(\d{3})(\d{3})$/)
  return m ? `+255 ${m[1]} ${m[2]} ${m[3]}` : p
}

type Box = { left: number; top: number; width: number; height: number }

// Where the menu card sits: full screen (with an 8px gutter) on phones, a tall
// card on the right on wider screens.
function menuBox(): Box {
  const w = window.innerWidth, h = window.innerHeight
  if (w < 768) return { left: 8, top: 8, width: w - 16, height: h - 16 }
  const width = Math.min(440, w - 24)
  return { left: w - 12 - width, top: 12, width, height: h - 24 }
}

/**
 * The menu grows out of the three-line button that opened it: a circle opens
 * from the button's centre, the lines fold into an ✕ in the same spot, then
 * the links rise in one after another. Closing runs the same path backwards.
 */
export function NavPanel({ settings }: { settings: ApiSettings | null }) {
  const markSrc = useImg('brand.mark', '/brand/mwani-mark.png')
  const open = useUI((s) => s.menuOpen)
  const setOpen = useUI((s) => s.setMenuOpen)
  const origin = useUI((s) => s.menuOrigin)
  const { t, lang, setLang } = useI18n()
  const currency = useCurrency((s) => s.currency)
  const setCurrency = useCurrency((s) => s.setCurrency)
  const saved = useWishlist((s) => s.items.length)
  const { theme, setTheme } = useTheme()
  const reduce = useReducedMotion()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  const [geo, setGeo] = useState<{ box: Box; x: number; y: number; r: number } | null>(null)
  useIsoLayoutEffect(() => {
    if (!open) return
    const measure = () => {
      const box = menuBox()
      const o = origin ?? { x: box.left + box.width - 34, y: box.top + 34 }
      const x = Math.min(Math.max(o.x - box.left, 26), box.width - 26)
      const y = Math.min(Math.max(o.y - box.top, 26), box.height - 26)
      const r = Math.hypot(Math.max(x, box.width - x), Math.max(y, box.height - y)) + 8
      setGeo({ box, x, y, r })
    }
    measure()
    window.addEventListener('resize', measure)
    return () => window.removeEventListener('resize', measure)
  }, [open, origin])

  const go = (id: string) => { setOpen(false); window.setTimeout(() => scrollToId(id), 320) }
  const then = (fn: () => void) => { setOpen(false); window.setTimeout(fn, 260) }

  const utils = [
    { key: 'menu.track', icon: PackageSearch, run: () => useUI.getState().openTrack() },
    { key: 'menu.myOrders', icon: ReceiptText, run: () => useUI.getState().setMyOrdersOpen(true) },
    { key: 'menu.wishlist', icon: Heart, run: () => useWishlist.getState().setOpen(true), badge: saved },
    { key: 'menu.search', icon: Search, run: () => useUI.getState().setSearchOpen(true) },
  ]

  const ig = settings?.instagram?.trim() || ''
  const igUrl = ig ? (/^https?:\/\//.test(ig) ? ig : `https://instagram.com/${ig.replace(/^@/, '')}`) : ''
  const igLabel = ig ? `@${ig.replace(/^https?:\/\/(www\.)?instagram\.com\//, '').replace(/^@/, '').replace(/\/$/, '')}` : ''

  const low = !!geo && geo.y > geo.box.height / 2 // opened from a button low on the screen
  const circle = (r: number) => (geo ? `circle(${r}px at ${geo.x}px ${geo.y}px)` : 'circle(0px at 100% 0%)')
  const rise = (i: number) => ({
    initial: { opacity: 0, y: reduce ? 0 : 26 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.5, delay: reduce ? 0 : 0.2 + i * 0.045, ease: EASE_OUT } },
    exit: { opacity: 0, transition: { duration: 0.12 } },
  })

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <AnimatePresence>
        {open && geo && (
          <Dialog.Portal forceMount>
            <Dialog.Overlay asChild forceMount>
              <motion.div
                className="fixed inset-0 z-[70] bg-night/35 md:backdrop-blur-[6px]"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                transition={{ duration: 0.3, ease: EASE_OUT }}
              />
            </Dialog.Overlay>
            <Dialog.Content asChild forceMount aria-describedby={undefined}>
              <motion.div
                className="fixed z-[71] overflow-hidden rounded-[28px] bg-surface shadow-3 outline-none md:rounded-[32px]"
                style={{ left: geo.box.left, top: geo.box.top, width: geo.box.width, height: geo.box.height }}
                initial={{ clipPath: circle(22) }}
                animate={{ clipPath: circle(geo.r), transition: { duration: reduce ? 0 : 0.62, ease: [0.65, 0, 0.35, 1] } }}
                exit={{ clipPath: circle(22), transition: { duration: reduce ? 0 : 0.42, ease: [0.65, 0, 0.35, 1] } }}
              >
                <Dialog.Title className="sr-only">{t('menu.title')}</Dialog.Title>

                {/* The three lines, now an ✕, exactly where the button was. */}
                <Dialog.Close asChild>
                  <button type="button" aria-label={t('menu.close')}
                    className="absolute z-10 grid h-11 w-11 place-items-center rounded-full bg-plum text-porcelain shadow-2 transition-colors duration-200 hover:bg-plum-2"
                    style={{ left: geo.x - 22, top: geo.y - 22 }}>
                    <Burger open />
                  </button>
                </Dialog.Close>

                <MotionConfig reducedMotion="user">
                  <div data-lenis-prevent className={cn('no-scrollbar h-full overflow-y-auto px-5 pt-5 sm:px-7 sm:pt-7', low ? 'pb-24' : 'pb-6')}>
                    <div className="flex min-h-full flex-col">
                      <motion.div {...rise(0)} className="flex h-11 items-center gap-2.5 pr-14">
                        <Image src={markSrc} alt="" width={30} height={30} className="h-[30px] w-[30px]" />
                        <span className="font-logo text-[1.1rem] leading-none text-plum">Mwani Zanzibar</span>
                      </motion.div>

                      {/* Section links */}
                      <nav aria-label={t('menu.title')} className="mt-5">
                        <ul>
                          {LINKS.map((l, i) => (
                            <motion.li key={l.id} {...rise(i + 1)}>
                              <button onClick={() => go(l.id)}
                                className="group flex min-h-[54px] w-full items-center justify-between gap-4 rounded-[14px] py-1 text-left">
                                <RollText text={t(l.key)} className="font-display text-[2.1rem] leading-[1.08] text-plum md:text-[2.25rem]" />
                                <span className="grid h-11 w-11 shrink-0 -translate-x-3 place-items-center rounded-full bg-plum text-porcelain opacity-0 transition-[opacity,transform] duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-0 group-hover:opacity-100 group-focus-visible:translate-x-0 group-focus-visible:opacity-100" aria-hidden>
                                  <ArrowRight className="h-[18px] w-[18px]" />
                                </span>
                              </button>
                            </motion.li>
                          ))}
                        </ul>
                      </nav>

                      {/* Utilities */}
                      <motion.div {...rise(LINKS.length + 1)} className="mt-6 rounded-[24px] bg-shell/70 p-1.5">
                        {utils.map((u) => (
                          <button key={u.key} onClick={() => then(u.run)}
                            className="press group flex h-14 w-full items-center gap-3 rounded-[18px] px-2.5 text-left hover:bg-surface">
                            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-surface text-plum shadow-1 transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-rotate-6 group-hover:scale-105">
                              <u.icon className="h-[18px] w-[18px]" aria-hidden />
                            </span>
                            <span className="flex-1 text-[1rem] font-medium text-foreground">{t(u.key)}</span>
                            {!!u.badge && (
                              <span className="grid h-7 min-w-7 place-items-center rounded-full bg-plum px-2 text-[0.82rem] font-semibold text-porcelain" aria-label={t('menu.saved', { n: u.badge })}>
                                <NumberRoll value={String(u.badge)} />
                              </span>
                            )}
                            <ChevronRight className="h-[18px] w-[18px] text-muted-foreground transition-transform duration-200 group-hover:translate-x-0.5" aria-hidden />
                          </button>
                        ))}
                      </motion.div>

                      {/* Appearance, language and currency */}
                      <motion.div {...rise(LINKS.length + 2)} className="mt-5">
                        <Segmented
                          label={t('menu.theme')} id="menu-theme"
                          value={mounted ? (theme || 'light') : 'light'}
                          onChange={(v, el) => switchTheme(v as ThemeChoice, setTheme, el)}
                          options={[
                            { v: 'light', label: t('menu.theme.light'), icon: Sun },
                            { v: 'dark', label: t('menu.theme.dark'), icon: Moon },
                            { v: 'system', label: t('menu.theme.system'), icon: MonitorSmartphone },
                          ]}
                        />
                      </motion.div>
                      <motion.div {...rise(LINKS.length + 3)} className="mt-4 grid grid-cols-2 gap-3">
                        <Segmented label={t('menu.language')} id="menu-lang" value={lang} onChange={(v) => setLang(v as Lang)}
                          options={[{ v: 'en', label: t('menu.lang.en') }, { v: 'sw', label: t('menu.lang.sw') }]} />
                        <Segmented label={t('menu.currency')} id="menu-cur" value={currency} onChange={(v) => setCurrency(v as Currency)}
                          options={[{ v: 'TZS', label: 'TZS' }, { v: 'USD', label: 'USD' }]} />
                      </motion.div>

                      {/* Contact */}
                      {settings && (
                        <motion.div {...rise(LINKS.length + 4)} className="mt-5 rounded-[26px] bg-night p-5 text-on-night shadow-3">
                          <h3 className="font-display text-[1.5rem] leading-tight">{t('menu.talk')}</h3>
                          <p className="mt-1 text-[0.93rem] text-on-night/70">{t('menu.talkBody')}</p>
                          <div className="mt-4 space-y-1">
                            {settings.whatsappPrimary && (
                              <ContactRow href={whatsappLink(settings.whatsappPrimary, t('menu.waMsg'))} icon={MessageCircle} label={t('menu.whatsapp')} value={prettyPhone(settings.whatsappPrimary)} external />
                            )}
                            {settings.email && <ContactRow href={`mailto:${settings.email}`} icon={Mail} label={t('menu.email')} value={settings.email.toLowerCase()} />}
                            {igUrl && <ContactRow href={igUrl} icon={Instagram} label={t('menu.instagram')} value={igLabel} external />}
                          </div>
                        </motion.div>
                      )}

                      <div className="mt-auto flex flex-wrap items-center justify-between gap-2 pt-6">
                        <span className="text-[0.84rem] text-muted-foreground">{t('menu.coop')}</span>
                        <a href="?admin=1" className="press inline-flex h-11 items-center gap-1.5 rounded-full px-2 text-[0.86rem] font-medium text-muted-foreground hover:text-plum">
                          <ShieldCheck className="h-4 w-4" aria-hidden />{t('menu.staff')}
                        </a>
                      </div>
                    </div>
                  </div>
                </MotionConfig>
              </motion.div>
            </Dialog.Content>
          </Dialog.Portal>
        )}
      </AnimatePresence>
    </Dialog.Root>
  )
}

/** Three lines that fold into an ✕ (and back). Also used by the navbar button. */
export function Burger({ open }: { open: boolean }) {
  const reduce = useReducedMotion()
  const tr = reduce ? { duration: 0 } : { type: 'spring' as const, stiffness: 420, damping: 30, delay: open ? 0.12 : 0 }
  return (
    <span aria-hidden className="relative block h-4 w-5">
      <motion.span className="absolute left-0 top-1/2 -mt-px h-[2px] w-5 rounded-full bg-current" initial={{ y: -6, rotate: 0 }} animate={open ? { y: 0, rotate: 45 } : { y: -6, rotate: 0 }} transition={tr} />
      <motion.span className="absolute left-0 top-1/2 -mt-px h-[2px] w-5 rounded-full bg-current" initial={{ scaleX: 1, opacity: 1 }} animate={open ? { scaleX: 0, opacity: 0 } : { scaleX: 1, opacity: 1 }} transition={{ duration: reduce ? 0 : 0.18, delay: open ? 0.1 : 0 }} />
      <motion.span className="absolute left-0 top-1/2 -mt-px h-[2px] w-5 rounded-full bg-current" initial={{ y: 6, rotate: 0 }} animate={open ? { y: 0, rotate: -45 } : { y: 6, rotate: 0 }} transition={tr} />
    </span>
  )
}

/** Link label whose letters roll up on hover (the copy below slides into place). */
export function RollText({ text, className, plain }: { text: string; className?: string; plain?: boolean }) {
  return (
    <span className={cn('relative block overflow-hidden', className)}>
      <span className="block transition-transform duration-[450ms] ease-[cubic-bezier(.65,0,.35,1)] group-hover:-translate-y-full group-focus-visible:-translate-y-full">{text}</span>
      <span aria-hidden className={cn('absolute inset-x-0 top-full block transition-transform duration-[450ms] ease-[cubic-bezier(.65,0,.35,1)] group-hover:-translate-y-full group-focus-visible:-translate-y-full', !plain && "italic [font-variation-settings:'SOFT'_100,'opsz'_144,'WONK'_1]")}>{text}</span>
    </span>
  )
}

function Segmented({ label, id, value, onChange, options }: {
  label: string; id: string; value: string; onChange: (v: string, el: HTMLElement) => void
  options: { v: string; label: string; icon?: typeof Sun }[]
}) {
  return (
    <div className="min-w-0">
      <span id={`${id}-label`} className="text-[0.86rem] font-medium text-muted-foreground">{label}</span>
      <div role="radiogroup" aria-labelledby={`${id}-label`} className="mt-1.5 flex h-[52px] rounded-full bg-shell p-1">
        {options.map((o) => {
          const on = o.v === value
          return (
            <button
              key={o.v}
              role="radio"
              aria-checked={on}
              onClick={(e) => onChange(o.v, e.currentTarget)}
              className={cn('relative h-11 min-w-0 flex-1 rounded-full px-2 text-[0.9rem] font-semibold transition-colors duration-200', on ? 'text-porcelain' : 'text-plum/70 hover:text-plum')}
            >
              {on && <motion.span layoutId={`${id}-thumb`} className="absolute inset-0 rounded-full bg-plum shadow-1" transition={SPRING_SNAPPY} />}
              <span className="relative flex items-center justify-center gap-1.5 truncate">{o.icon && <o.icon className="h-4 w-4 shrink-0" aria-hidden />}{o.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function ContactRow({ href, icon: Icon, label, value, external }: { href: string; icon: typeof Mail; label: string; value: string; external?: boolean }) {
  return (
    <a
      href={href}
      {...(external ? { target: '_blank', rel: 'noreferrer' } : {})}
      className="group -mx-2 flex min-h-[52px] items-center gap-3 rounded-[16px] px-2 transition-colors duration-200 hover:bg-on-night/[0.08]"
    >
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-on-night/10 text-on-night">
        <Icon className="h-[18px] w-[18px]" aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[0.8rem] text-on-night/60">{label}</span>
        <span className="block truncate text-[0.98rem] font-medium">{value}</span>
      </span>
      <ArrowRight className="h-4 w-4 shrink-0 -translate-x-1 text-on-night/50 opacity-0 transition-[opacity,transform] duration-200 group-hover:translate-x-0 group-hover:opacity-100" aria-hidden />
    </a>
  )
}
