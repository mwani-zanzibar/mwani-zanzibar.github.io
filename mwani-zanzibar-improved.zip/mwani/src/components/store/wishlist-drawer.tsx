'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { Check, Heart, ShoppingBag, X } from 'lucide-react'
import { ResponsiveSheet } from '@/components/store/overlay-shell'
import { EASE_OUT, SPRING_POP, SPRING_SNAPPY } from '@/components/shared/reveal'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { useWishlist, type WishItem } from '@/lib/wishlist-store'
import { useCart } from '@/lib/cart-store'
import { useUI } from '@/lib/ui-store'
import { useMoney } from '@/lib/use-money'
import { useI18n } from '@/lib/i18n'
import { flyToCart } from '@/lib/cart-fx'
import type { ApiProduct } from '@/lib/api'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'

/** Saved products. Opens from useWishlist.open; a right panel on desktop, a bottom sheet on phones. */
export function WishlistDrawer({ products }: { products: ApiProduct[] }) {
  const open = useWishlist((s) => s.open)
  const setOpen = useWishlist((s) => s.setOpen)
  const items = useWishlist((s) => s.items)
  const { t } = useI18n()
  const n = items.length

  const view = (id: string) => {
    const p = products.find((x) => x.id === id)
    if (!p) return
    setOpen(false)
    useUI.getState().setQuick(p)
  }

  return (
    <ResponsiveSheet
      open={open}
      onOpenChange={setOpen}
      title={t('wish.title')}
      description={n ? (n === 1 ? t('wish.countOne') : t('wish.countMany', { n })) : undefined}
      side="right"
    >
      <MotionConfig reducedMotion="user">
        {n === 0 ? (
          <Empty onBrowse={() => { setOpen(false); window.setTimeout(() => scrollToId('shop'), 250) }} />
        ) : (
          <ul className="relative space-y-3 pb-2">
            <AnimatePresence mode="popLayout" initial={false}>
              {items.map((it, i) => (
                <Row key={it.id} item={it} index={i} product={products.find((p) => p.id === it.id)} onView={() => view(it.id)} />
              ))}
            </AnimatePresence>
          </ul>
        )}
      </MotionConfig>
    </ResponsiveSheet>
  )
}

function Row({ item, index, product, onView }: { item: WishItem; index: number; product?: ApiProduct; onView: () => void }) {
  const { t } = useI18n()
  const money = useMoney()
  const remove = useWishlist((s) => s.remove)
  const [added, setAdded] = useState(false)
  const timer = useRef(0)
  const wellRef = useRef<HTMLButtonElement>(null)
  useEffect(() => () => clearTimeout(timer.current), [])

  // Prefer live product data (price, stock) over what was saved.
  const price = product?.price ?? item.price
  const unit = product?.unit ?? item.unit
  const stock = product?.stock ?? 99
  const out = !!product && product.stock <= 0

  const add = () => {
    if (out) return
    useCart.getState().add({ productId: item.id, name: product?.name ?? item.name, price, unit, image: product?.image ?? item.image, stock }, 1)
    flyToCart(wellRef.current)
    setAdded(true)
    clearTimeout(timer.current)
    timer.current = window.setTimeout(() => setAdded(false), 1600)
  }

  return (
    <motion.li
      layout
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0, transition: { duration: 0.34, delay: 0.06 + Math.min(index, 6) * 0.05, ease: EASE_OUT } }}
      exit={{ opacity: 0, x: 48, scale: 0.96, transition: { duration: 0.22, ease: EASE_OUT } }}
      transition={{ layout: SPRING_SNAPPY }}
      className="relative flex gap-3.5 rounded-[24px] bg-card p-2.5 pr-3 shadow-2 ring-1 ring-border/60"
    >
      <button
        ref={wellRef}
        onClick={onView}
        disabled={!product}
        aria-label={t('wish.view', { name: item.name })}
        className="group relative h-[104px] w-[104px] shrink-0 overflow-hidden rounded-[18px] bg-shell"
      >
        <Image src={item.image} alt="" fill sizes="104px" className={`${fit(item.image, 'sm')} transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.06]`} />
      </button>
      <div className="flex min-w-0 flex-1 flex-col py-0.5">
        <button onClick={onView} disabled={!product} className="block min-w-0 pr-9 text-left">
          <span className="line-clamp-2 text-[1rem] font-medium leading-snug text-foreground hover:text-plum">{item.name}</span>
        </button>
        <span className="mt-0.5 text-[0.86rem] text-muted-foreground">{unit}</span>
        <div className="mt-auto flex items-center justify-between gap-2 pt-2">
          <span className="text-[1rem] font-semibold text-plum tabular">{money(price)}</span>
          <button
            onClick={add}
            disabled={out}
            className={cn(
              'press relative inline-flex h-11 items-center overflow-hidden rounded-full px-4 text-[0.9rem] font-semibold',
              out ? 'bg-foreground/[0.07] text-muted-foreground' : added ? 'bg-lagoon-deep text-porcelain' : 'bg-plum text-porcelain hover:bg-plum-2',
            )}
          >
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.span
                key={added ? 'added' : 'add'}
                className="inline-flex items-center gap-1.5 whitespace-nowrap"
                initial={{ y: 16, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                exit={{ y: -16, opacity: 0 }}
                transition={{ duration: 0.2, ease: EASE_OUT }}
              >
                {added ? (
                  <><motion.span initial={{ scale: 0.5 }} animate={{ scale: 1 }} transition={SPRING_POP} className="grid"><Check className="h-4 w-4" strokeWidth={3} aria-hidden /></motion.span>{t('wish.added')}</>
                ) : out ? t('wish.out') : (
                  <><ShoppingBag className="h-4 w-4" aria-hidden />{t('wish.add')}</>
                )}
              </motion.span>
            </AnimatePresence>
          </button>
        </div>
      </div>
      <button
        onClick={() => remove(item.id)}
        aria-label={t('wish.remove', { name: item.name })}
        className="press absolute right-1.5 top-1.5 grid h-11 w-11 place-items-center rounded-full text-muted-foreground hover:bg-shell hover:text-plum"
      >
        <X className="h-[18px] w-[18px]" aria-hidden />
      </button>
    </motion.li>
  )
}

function Empty({ onBrowse }: { onBrowse: () => void }) {
  const { t } = useI18n()
  return (
    <div className="flex flex-col items-center px-4 pb-6 pt-10 text-center md:pt-16">
      <div className="relative h-[132px] w-[132px]" aria-hidden>
        <motion.span className="absolute inset-0 rounded-full bg-shell" initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5, ease: EASE_OUT }} />
        <motion.span className="absolute inset-[22px] grid place-items-center rounded-full bg-card shadow-2" initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ ...SPRING_POP, delay: 0.12 }}>
          <Heart className="h-10 w-10 text-plum" strokeWidth={1.6} />
        </motion.span>
        <motion.span className="absolute right-3 top-4 h-4 w-4 rounded-full bg-lagoon/70" initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.3, ease: EASE_OUT }} />
        <motion.span className="absolute left-2 top-10 h-2.5 w-2.5 rounded-full bg-coral/70" initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.38, ease: EASE_OUT }} />
        <motion.span className="absolute bottom-5 right-0 h-2 w-2 rounded-full bg-rose" initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.44, ease: EASE_OUT }} />
      </div>
      <h3 className="mt-7 font-display text-[1.6rem] leading-tight text-plum">{t('wish.emptyTitle')}</h3>
      <p className="mt-2 max-w-[30ch] text-[0.98rem] text-muted-foreground">{t('wish.emptyBody')}</p>
      <button onClick={onBrowse} className="press mt-7 inline-flex h-12 items-center gap-2 rounded-full bg-plum px-6 text-[0.98rem] font-semibold text-porcelain hover:bg-plum-2">
        <ShoppingBag className="h-[18px] w-[18px]" aria-hidden />{t('wish.browse')}
      </button>
    </div>
  )
}
