'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { ArrowUpRight } from 'lucide-react'
import { gsap, ScrollTrigger, useGSAP } from '@/lib/gsap'
import { getTier, isTouch, reducedMotion } from '@/lib/perf'
import { useI18n } from '@/lib/i18n'
import { Reveal, ImageReveal, SplitReveal } from '@/components/shared/reveal'
import type { ApiSettings } from '@/lib/api'
import { useImg } from '@/lib/content-store'

type Step =
  | { n: 1; kind: 'type' }
  | { n: 2 | 3; kind: 'photo'; img: string; pos: string }
  | { n: 4; kind: 'split'; img: string; img2: string }

const STEPS: Step[] = [
  { n: 1, kind: 'type' },
  { n: 2, kind: 'photo', img: '/products/dried-seaweed.webp', pos: '50% 60%' },
  { n: 3, kind: 'photo', img: '/products/powder.webp', pos: '50% 62%' },
  { n: 4, kind: 'split', img: '/products/tea.webp', img2: '/products/soaps.webp' },
]

// The lagoon runs cool at the start of the journey and warms towards the cup.
const LAGOON_BG = 'var(--story-lagoon)'

function siteOf(settings: ApiSettings | null) {
  const raw = (settings?.website || 'www.wakulimahai.org').trim()
  const bare = raw.replace(/^https?:\/\//, '').replace(/\/$/, '')
  return { href: `https://${bare}`, label: bare.replace(/^www\./, '') }
}

// Pinned sideways scroll on capable desktops; a vertical stack everywhere else.
function usePinned() {
  const [pin, setPin] = useState(false)
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)')
    const update = () => setPin(mq.matches && getTier() === 2 && !reducedMotion() && !isTouch())
    update()
    mq.addEventListener('change', update)
    return () => mq.removeEventListener('change', update)
  }, [])
  return pin
}

export function StorySection({ settings }: { settings: ApiSettings | null }) {
  const pin = usePinned()
  const site = siteOf(settings)
  return (
    <section id="story" className="relative pt-24 sm:pt-32">
      {pin ? <PinnedStory site={site} /> : <StackedStory site={site} />}
    </section>
  )
}

function CoopCard({ site }: { site: { href: string; label: string } }) {
  const coopLogo = useImg('brand.coop', '/wakulima-hai-logo.png')
  const { t } = useI18n()
  return (
    <a href={site.href} target="_blank" rel="noopener noreferrer"
      className="group press inline-flex max-w-full items-center gap-3.5 rounded-[22px] bg-surface py-3 pl-3 pr-5 shadow-3 hover:-translate-y-0.5">
      <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full bg-surface ring-1 ring-border">
        <Image src={coopLogo} alt="" fill sizes="56px" className="object-contain" />
      </span>
      <span className="min-w-0">
        <span className="block text-[0.98rem] font-semibold leading-snug text-plum">{t('story.coop')}</span>
        <span className="mt-0.5 flex items-center gap-1 text-[0.9rem] text-muted-foreground">
          {t('story.visit', { site: site.label })}
          <ArrowUpRight aria-hidden className="h-4 w-4 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
        </span>
      </span>
    </a>
  )
}

// Step 1 has no photograph that fits, so it is set in type: the Swahili word
// for the ropes, over rows of "mwani" tied along lines like the real farms.
function RopeRows({ drift }: { drift: boolean }) {
  const row = Array.from({ length: 8 }, () => 'mwani').join('  —  ')
  return (
    <div aria-hidden className="absolute inset-0 flex flex-col justify-center gap-[0.35em] overflow-hidden text-[clamp(1.35rem,2vw,1.9rem)]">
      {[0, 1, 2, 3, 4].map((r) => (
        <div key={r} data-row={drift ? r : undefined}
          className="font-display whitespace-nowrap leading-none text-lagoon/45"
          style={{ transform: `translateX(${r % 2 ? -18 : -6}%)` }}>
          —  {row}  —  {row}
        </div>
      ))}
    </div>
  )
}

function StepMedia({ step, parallax }: { step: Step; parallax: boolean }) {
  // Admin can replace these photos (Site content → Our farmers).
  const photo = useImg(`story.${step.n}`, 'img' in step ? step.img : '')
  const left = useImg('story.4a', step.kind === 'split' ? step.img : '')
  const right = useImg('story.4b', step.kind === 'split' ? step.img2 : '')
  const { t } = useI18n()
  const par = parallax ? 'absolute inset-y-0 -left-[9%] w-[118%]' : 'absolute inset-0'
  if (step.kind === 'type') {
    return (
      <div className="absolute inset-0 bg-lagoon-deep">
        <RopeRows drift={parallax} />
        <div className="absolute inset-x-0 bottom-0 bg-[linear-gradient(to_top,rgb(10_92_100/0.95)_35%,transparent)] px-6 pb-6 pt-16 sm:px-7">
          <p className="font-display text-[clamp(3.6rem,6vw,5.6rem)] leading-[0.9] text-on-night">kamba</p>
          <p className="mt-2 max-w-[26rem] text-[0.95rem] leading-snug text-on-night/85">
            <span className="italic text-on-night/70">{t('story.kamba.pos')}.</span> {t('story.kamba.def')}
          </p>
        </div>
      </div>
    )
  }
  if (step.kind === 'split') {
    return (
      <div className="absolute inset-0 grid grid-cols-2 gap-1.5">
        {[{ src: left, label: t('story.food') }, { src: right, label: t('story.care') }].map((m, i) => (
          <div key={m.src} className="relative overflow-hidden">
            <div data-par={parallax ? (i === 0 ? 'a' : 'b') : undefined} className={par}>
              <Image src={m.src} alt="" fill sizes="(min-width: 1024px) 300px, 50vw" className="object-cover" />
            </div>
            <span className="absolute bottom-3 left-3 rounded-full bg-surface px-3 py-1.5 text-[0.84rem] font-medium text-plum shadow-1">{m.label}</span>
          </div>
        ))}
      </div>
    )
  }
  return (
    <div data-par={parallax ? 'a' : undefined} className={par}>
      <Image src={photo} alt="" fill sizes="(min-width: 1024px) 600px, 100vw" className="object-cover" style={{ objectPosition: step.pos }} />
    </div>
  )
}

// ── Desktop: pinned, scrubbed sideways journey ───────────────────────────
function PinnedStory({ site }: { site: { href: string; label: string } }) {
  const { t, lang } = useI18n()
  const wrap = useRef<HTMLDivElement>(null)
  const panel = useRef<HTMLDivElement>(null)
  const track = useRef<HTMLDivElement>(null)
  const bar = useRef<HTMLDivElement>(null)
  const warm = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    const w = wrap.current, p = panel.current, tr = track.current, b = bar.current, wm = warm.current
    if (!w || !p || !tr || !b || !wm) return
    const distance = () => Math.max(0, tr.offsetWidth - p.clientWidth)
    const setBar = gsap.quickSetter(b, 'scaleX') as (v: number) => void

    let self: gsap.core.Tween | undefined
    const slide = gsap.to(tr, {
      x: () => -distance(),
      ease: 'none',
      onUpdate() {
        const k = self ? self.progress() : 0
        setBar(k)
        // Cool lagoon warms towards the cup: fade a shell layer in (theme-aware).
        wm.style.opacity = String(k)
      },
      scrollTrigger: {
        trigger: w,
        pin: w,
        start: 'top top',
        end: () => '+=' + distance(),
        scrub: 0.8,
        invalidateOnRefresh: true,
        anticipatePin: 1,
      },
    })
    self = slide

    gsap.utils.toArray<HTMLElement>('[data-card]', tr).forEach((card) => {
      // Each card is dealt onto the table as it slides in.
      gsap.fromTo(card, { rotate: 3, y: 48 }, {
        rotate: 0, y: 0, ease: 'none',
        scrollTrigger: { trigger: card, containerAnimation: slide, start: 'left 104%', end: 'left 58%', scrub: true },
      })
      // Photos travel inside their frame, a little slower than the card.
      card.querySelectorAll<HTMLElement>('[data-par]').forEach((el) => {
        const amt = el.dataset.par === 'b' ? 10 : 7
        gsap.fromTo(el, { xPercent: amt }, {
          xPercent: -amt, ease: 'none',
          scrollTrigger: { trigger: card, containerAnimation: slide, start: 'left right', end: 'right left', scrub: true },
        })
      })
      // The rope rows drift against each other like water.
      card.querySelectorAll<HTMLElement>('[data-row]').forEach((el) => {
        const r = Number(el.dataset.row)
        const from = r % 2 ? -26 : -2
        gsap.fromTo(el, { xPercent: from }, {
          xPercent: from + (r % 2 ? 14 : -14), ease: 'none',
          scrollTrigger: { trigger: card, containerAnimation: slide, start: 'left right', end: 'right left', scrub: true },
        })
      })
    })

    // The pin changes the page height; make everything below re-measure.
    ScrollTrigger.refresh()
  }, { scope: wrap, dependencies: [lang] })

  return (
    <div ref={wrap} className="relative h-[100svh] p-3">
      <div ref={panel} className="relative h-full overflow-hidden rounded-[40px]" style={{ backgroundColor: LAGOON_BG }}>
        <div ref={warm} aria-hidden className="pointer-events-none absolute inset-0 bg-shell opacity-0" />
        <div ref={track} className="flex h-full w-max items-center gap-7 pl-[max(3rem,calc((100vw-88rem)/2+3rem))] pr-[10vw] pt-10 will-change-transform">
          <div className="flex w-[min(34rem,36vw)] shrink-0 flex-col justify-center pr-8">
            <SplitReveal as="h2" text={t('story.title')} className="font-display text-[clamp(2.6rem,4.6vw,4.4rem)] leading-[1] text-plum" />
            <Reveal delay={0.12} y={16}>
              <p className="mt-6 max-w-[30rem] text-[1.05rem] leading-[1.6] text-foreground/80">{t('story.body')}</p>
            </Reveal>
            <Reveal delay={0.24} y={24} className="mt-8">
              <CoopCard site={site} />
            </Reveal>
          </div>

          <ol className="flex items-center gap-7">
            {STEPS.map((s) => (
              <li key={s.n} data-card
                className="relative flex h-[70vh] max-h-[760px] min-h-[440px] w-[clamp(500px,40vw,600px)] shrink-0 flex-col rounded-[36px] bg-surface p-2.5 shadow-3">
                <div className="relative h-[60%] overflow-hidden rounded-[28px] bg-shell">
                  <StepMedia step={s} parallax />
                </div>
                <div className="flex flex-1 items-start gap-5 px-4 pb-3 pt-5">
                  <span aria-hidden className="font-display tabular -mt-1 text-[clamp(4rem,5.4vw,5.6rem)] leading-[0.85] text-lagoon-deep">{s.n}</span>
                  <div className="min-w-0 pt-1">
                    <span className="sr-only">{t('story.step', { n: s.n, total: STEPS.length })}: </span>
                    <h3 className="font-display text-[clamp(1.45rem,1.9vw,1.9rem)] leading-[1.08] text-plum">{t(`story.s${s.n}.t`)}</h3>
                    <p className="mt-2.5 max-w-[26rem] text-[1rem] leading-[1.5] text-muted-foreground">{t(`story.s${s.n}.d`)}</p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <div aria-hidden
          className="absolute bottom-7 left-1/2 h-[3px] w-[min(22rem,28vw)] -translate-x-1/2 overflow-hidden rounded-full bg-plum/12">
          <div ref={bar} className="h-full w-full origin-left scale-x-0 rounded-full bg-plum" />
        </div>
      </div>
    </div>
  )
}

// ── Phones, tablets, low tier and reduced motion: a vertical stack ─────────
function StackedStory({ site }: { site: { href: string; label: string } }) {
  const { t } = useI18n()
  return (
    <div className="px-3">
      <div className="rounded-[32px] px-4 pb-6 pt-14 sm:rounded-[40px] sm:px-8 sm:pb-8 sm:pt-20 lg:px-12" style={{ backgroundColor: LAGOON_BG }}>
        <div className="mx-auto max-w-[88rem]">
          <div className="max-w-[40rem] px-1">
            <SplitReveal as="h2" text={t('story.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-[1] text-plum" />
            <Reveal delay={0.1}>
              <p className="mt-5 text-[1.02rem] leading-[1.6] text-foreground/80">{t('story.body')}</p>
            </Reveal>
            <Reveal delay={0.18} y={24} className="mt-7">
              <CoopCard site={site} />
            </Reveal>
          </div>

          <ol className="mt-12 grid gap-4 sm:mt-14 sm:gap-5 md:grid-cols-2 xl:grid-cols-4">
            {STEPS.map((s, i) => (
              <li key={s.n} className="flex flex-col rounded-[32px] bg-surface p-2 shadow-2">
                <ImageReveal className="aspect-[4/3] rounded-[24px] bg-shell" delay={(i % 2) * 0.08}>
                  <StepMedia step={s} parallax={false} />
                </ImageReveal>
                <Reveal y={14} delay={0.1} className="flex items-start gap-4 px-3 pb-4 pt-4 sm:px-4">
                  <span aria-hidden className="font-display tabular text-[3.6rem] leading-[0.85] text-lagoon-deep">{s.n}</span>
                  <div className="min-w-0 pt-0.5">
                    <span className="sr-only">{t('story.step', { n: s.n, total: STEPS.length })}: </span>
                    <h3 className="font-display text-[1.4rem] leading-[1.1] text-plum">{t(`story.s${s.n}.t`)}</h3>
                    <p className="mt-2 text-[1rem] leading-[1.5] text-muted-foreground">{t(`story.s${s.n}.d`)}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  )
}
