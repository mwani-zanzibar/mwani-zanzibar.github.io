'use client'

import { useRef } from 'react'
import Image from 'next/image'
import { ArrowRight, MessageCircle } from 'lucide-react'
import { gsap, useGSAP } from '@/lib/gsap'
import { reducedMotion } from '@/lib/perf'
import { useI18n } from '@/lib/i18n'
import { whatsappLink } from '@/lib/format'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { Reveal, SplitReveal } from '@/components/shared/reveal'
import { NewsletterForm } from '@/components/store/newsletter-form'
import { Magnetic } from '@/components/motion/effects'
import type { ApiSettings } from '@/lib/api'
import { useImg } from '@/lib/content-store'

const WA_GREEN = '#1f8a5a'

// The night slab begins here and runs on into the footer. The two pouches
// swing in from the sides as it arrives, each on its own colour.
export function ClosingCta({ settings }: { settings: ApiSettings | null }) {
  const { t } = useI18n()
  const root = useRef<HTMLDivElement>(null)
  const left = useImg('cta.left', '/products/powder-cut.webp')
  const right = useImg('cta.right', '/products/tea-cut.webp')
  const wa = whatsappLink(settings?.whatsappPrimary || '+255774870703', t('cta.waMsg'))

  useGSAP(() => {
    if (reducedMotion()) return
    const band = root.current
    ;([['l', -1], ['r', 1]] as const).forEach(([side, s]) => {
      const pouch = `[data-pouch="${side}"]`
      const disc = `[data-disc="${side}"]`
      // Swing in from the side while the band arrives...
      gsap.fromTo(pouch, { xPercent: 45 * s, rotate: 10 * s, opacity: 0 }, {
        xPercent: 0, rotate: 0, opacity: 1, ease: 'none',
        scrollTrigger: { trigger: band, start: 'top bottom', end: 'top 30%', scrub: 0.7 },
      })
      // ...then keep drifting upward, the disc slower than the pouch.
      gsap.fromTo(pouch, { yPercent: 10 }, {
        yPercent: -8, ease: 'none', immediateRender: false,
        scrollTrigger: { trigger: band, start: 'top bottom', end: 'bottom top', scrub: 0.7 },
      })
      gsap.fromTo(disc, { yPercent: 12, scale: 0.8 }, {
        yPercent: -6, scale: 1, ease: 'none',
        scrollTrigger: { trigger: band, start: 'top bottom', end: 'bottom top', scrub: 0.7 },
      })
    })
  }, { scope: root })

  return (
    <div ref={root} className="px-3 pt-10 sm:pt-16">
      <div className="relative overflow-hidden rounded-t-[32px] bg-night px-5 pb-16 pt-12 text-on-night sm:rounded-t-[40px] sm:px-10 sm:pt-14 lg:px-14 lg:pb-24 xl:pt-32">
        {/* The two real products, each on its own colour. Below xl they sit in a
            row above the heading; on wide screens they flank it. Never on the words. */}
        <div className="relative mx-auto mb-8 flex max-w-[40rem] items-end justify-center gap-3 sm:gap-6 xl:contents">
          <Pouch side="l" src={left} color="var(--coral)"
            className="relative w-1/2 max-w-[19rem] xl:absolute xl:left-[2.5%] xl:top-1/2 xl:w-[21%] xl:max-w-none xl:-translate-y-1/2" />
          <Pouch side="r" src={right} color="var(--lagoon)"
            className="relative w-1/2 max-w-[19rem] xl:absolute xl:right-[2.5%] xl:top-1/2 xl:w-[21%] xl:max-w-none xl:-translate-y-1/2" />
        </div>

        <div className="relative mx-auto flex max-w-[46rem] flex-col items-center text-center">
          <SplitReveal as="h2" text={t('cta.title')} stagger={0.12}
            className="font-display text-[clamp(3rem,8.4vw,7.6rem)] leading-[0.95] text-on-night" />
          <Reveal delay={0.15}>
            <p className="mx-auto mt-6 max-w-[30rem] text-[1.08rem] leading-[1.6] text-on-night/75">{t('cta.body')}</p>
          </Reveal>
          <Reveal delay={0.25} y={22} className="mt-9 flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row">
            <Magnetic className="w-full sm:w-auto"><button type="button" onClick={() => scrollToId('duo')}
              className="group press inline-flex h-14 w-full items-center justify-center gap-2.5 rounded-full bg-on-night px-7 text-[1rem] font-medium text-night hover:bg-white sm:w-auto">
              {t('cta.shop')}
              <ArrowRight aria-hidden className="h-4 w-4 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-1" />
            </button></Magnetic>
            <Magnetic className="w-full sm:w-auto"><a href={wa} target="_blank" rel="noopener noreferrer"
              className="group press inline-flex h-14 w-full items-center justify-center gap-2.5 rounded-full px-7 text-[1rem] font-medium text-white hover:brightness-110 sm:w-auto"
              style={{ backgroundColor: WA_GREEN }}>
              <MessageCircle aria-hidden className="h-5 w-5 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-rotate-12" />
              {t('cta.wa')}
            </a></Magnetic>
          </Reveal>
          <Reveal delay={0.35} y={16} className="mt-12 w-full max-w-[30rem]">
            <p className="mb-3 text-[0.95rem] text-on-night/70">{t('cta.news')}</p>
            <NewsletterForm dark />
          </Reveal>
        </div>
      </div>
    </div>
  )
}

function Pouch({ side, src, color, className }: { side: 'l' | 'r'; src: string; color: string; className: string }) {
  return (
    <div aria-hidden className={`pointer-events-none aspect-[1.2] ${className}`}>
      <div className="absolute left-1/2 top-[46%] aspect-square w-[74%] -translate-x-1/2 -translate-y-1/2">
        <div data-disc={side} className="h-full w-full rounded-full" style={{ backgroundColor: color }} />
      </div>
      <div data-pouch={side} className="absolute inset-0">
        <Image src={src} alt="" fill sizes="(min-width: 1280px) 20vw, 45vw" className="object-contain object-bottom drop-shadow-[0_24px_30px_rgb(0_0_0/0.45)]" />
      </div>
    </div>
  )
}
