'use client'

import Image from 'next/image'
import { GitCompareArrows, X, Trash2, ShoppingBag, Star, Check, Minus, Plus } from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { useCompare, COMPARE_MAX } from '@/lib/compare-store'
import { useCart } from '@/lib/cart-store'
import { useMoney } from '@/lib/use-money'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import type { ApiProduct } from '@/lib/api'

export function CompareDrawer({ onSelect }: { onSelect: (p: ApiProduct) => void }) {
  const open = useCompare((s) => s.open)
  const setOpen = useCompare((s) => s.setOpen)
  const items = useCompare((s) => s.items)
  const remove = useCompare((s) => s.remove)
  const clear = useCompare((s) => s.clear)
  const add = useCart((s) => s.add)
  const money = useMoney()

  // Best price (lowest)
  const minPrice = items.length ? Math.min(...items.map((i) => i.price)) : 0
  const bestRating = items.length ? Math.max(...items.map((i) => i.rating)) : 0
  const bestStock = items.length ? Math.max(...items.map((i) => i.stock)) : 0

  const rows: { label: string; render: (it: typeof items[number]) => React.ReactNode; best?: (it: typeof items[number]) => boolean }[] = [
    {
      label: 'Price',
      render: (it) => <span className="font-bold text-brand">{money(it.price)}</span>,
      best: (it) => it.price === minPrice && items.length > 1,
    },
    {
      label: 'Unit',
      render: (it) => <span className="text-foreground/80">{it.unit}</span>,
    },
    {
      label: 'Rating',
      render: (it) => (
        <span className="inline-flex items-center gap-1">
          <Star className="h-3 w-3 fill-coral text-coral" />
          <span className="font-semibold">{it.rating > 0 ? it.rating.toFixed(1) : '—'}</span>
          <span className="text-[10px] text-muted-foreground">({it.reviewCount})</span>
        </span>
      ),
      best: (it) => it.rating === bestRating && it.rating > 0 && items.length > 1,
    },
    {
      label: 'Stock',
      render: (it) => (
        <span className={it.stock <= 0 ? 'text-destructive font-bold' : it.stock <= 8 ? 'text-amber-600 font-bold' : 'text-leaf font-bold'}>
          {it.stock <= 0 ? 'Out' : `${it.stock} left`}
        </span>
      ),
      best: (it) => it.stock === bestStock && items.length > 1,
    },
    {
      label: 'Category',
      render: (it) => <span className="text-foreground/80">{it.category}</span>,
    },
    {
      label: 'Benefits',
      render: (it) => (
        <ul className="space-y-0.5 text-left">
          {it.benefits.slice(0, 3).map((b) => (
            <li key={b} className="flex items-start gap-1 text-[11px] text-foreground/80">
              <Check className="h-3 w-3 text-leaf shrink-0 mt-0.5" />{b}
            </li>
          ))}
          {it.benefits.length > 3 && <li className="text-[10px] text-muted-foreground">+{it.benefits.length - 3} more</li>}
        </ul>
      ),
    },
    {
      label: 'Key ingredients',
      render: (it) => <span className="text-[11px] text-foreground/80 leading-snug">{it.ingredients.slice(0, 3).join(', ')}{it.ingredients.length > 3 ? '…' : ''}</span>,
    },
  ]

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full sm:max-w-3xl p-0 flex flex-col">
        <SheetHeader className="px-5 pt-5 pb-3 border-b border-border/60">
          <SheetTitle className="flex items-center gap-2 font-display text-lg">
            <GitCompareArrows className="h-5 w-5 text-brand" /> Compare products
          </SheetTitle>
          <SheetDescription>
            {items.length === 0 ? 'Add products to compare side-by-side.' : `Comparing ${items.length} of ${COMPARE_MAX} products`}
          </SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
            <div className="grid h-20 w-20 place-items-center rounded-full bg-brand/10">
              <GitCompareArrows className="h-9 w-9 text-brand/50" />
            </div>
            <p className="mt-4 font-display text-lg font-bold">Nothing to compare yet</p>
            <p className="mt-1 text-sm text-muted-foreground max-w-xs">Tap the compare icon on any product card (max {COMPARE_MAX} at a time) to see them side-by-side.</p>
            <button onClick={() => setOpen(false)} className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-semibold hover:opacity-95 transition">
              Browse products
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-auto scrollbar-thin">
              {/* Product header row */}
              <div className="grid border-b border-border/60 bg-sand/30" style={{ gridTemplateColumns: `120px repeat(${items.length}, minmax(160px, 1fr))` }}>
                <div className="p-3 text-[10px] font-bold uppercase tracking-wide text-muted-foreground flex items-end">Product</div>
                {items.map((it) => (
                  <div key={it.id} className="p-3 border-l border-border/40 relative">
                    <button onClick={() => remove(it.id)} className="absolute top-2 right-2 grid h-6 w-6 place-items-center rounded-full hover:bg-destructive/10 hover:text-destructive transition" aria-label="remove">
                      <X className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => { setOpen(false); onSelect({ id: it.id, name: it.name, price: it.price, image: it.image, category: it.category, unit: it.unit } as ApiProduct) }} className="block w-full text-center">
                      <div className="relative h-24 w-24 mx-auto rounded-xl overflow-hidden bg-muted/30">
                        <Image src={it.image} alt={it.name} fill className="object-cover" sizes="96px" />
                      </div>
                      <div className="mt-2 text-xs font-bold leading-tight line-clamp-2 hover:text-brand transition-colors">{it.name}</div>
                    </button>
                  </div>
                ))}
              </div>

              {/* Comparison rows */}
              {rows.map((row, ri) => (
                <div key={row.label} className={`grid ${ri % 2 === 0 ? 'bg-background' : 'bg-sand/20'}`} style={{ gridTemplateColumns: `120px repeat(${items.length}, minmax(160px, 1fr))` }}>
                  <div className="p-3 text-xs font-semibold text-muted-foreground flex items-center">{row.label}</div>
                  {items.map((it) => (
                    <div key={it.id} className={`p-3 border-l border-border/40 text-center text-sm flex items-center justify-center relative ${row.best?.(it) ? 'bg-leaf/5' : ''}`}>
                      {row.render(it)}
                      {row.best?.(it) && (
                        <span className="absolute top-1 right-1 inline-flex items-center gap-0.5 rounded-full bg-leaf/15 text-leaf px-1.5 py-0.5 text-[8px] font-bold uppercase">
                          <Star className="h-2 w-2 fill-leaf" /> Best
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              ))}

              {/* Add-to-bag row */}
              <div className="grid border-t-2 border-border/60" style={{ gridTemplateColumns: `120px repeat(${items.length}, minmax(160px, 1fr))` }}>
                <div className="p-3 text-[10px] font-bold uppercase tracking-wide text-muted-foreground flex items-end">Add to bag</div>
                {items.map((it) => (
                  <div key={it.id} className="p-3 border-l border-border/40 flex items-center justify-center">
                    <button
                      disabled={it.stock <= 0}
                      onClick={() => {
                        add({ productId: it.id, name: it.name, price: it.price, unit: it.unit, image: it.image, stock: it.stock })
                        toast.success(`${it.name} added to bag`, { duration: 1500 })
                      }}
                      className="inline-flex items-center gap-1.5 rounded-full bg-brand text-primary-foreground px-3 py-1.5 text-xs font-bold hover:opacity-95 transition disabled:opacity-40"
                    >
                      <Plus className="h-3 w-3" /> Add
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border/60 p-4 flex items-center justify-between gap-3 bg-card/50">
              <p className="text-[11px] text-muted-foreground">Best price & rating are highlighted. Add up to {COMPARE_MAX} products.</p>
              <div className="flex items-center gap-2">
                <button onClick={clear} className="inline-flex items-center gap-1.5 rounded-full border border-border/70 px-4 py-2 text-xs font-semibold hover:bg-accent/40 transition">
                  <Trash2 className="h-3.5 w-3.5" /> Clear
                </button>
                <button
                  onClick={() => { items.forEach((it) => add({ productId: it.id, name: it.name, price: it.price, unit: it.unit, image: it.image, stock: it.stock })); setOpen(false); toast.success(`Added ${items.length} items to bag`) }}
                  className="inline-flex items-center gap-1.5 rounded-full bg-brand text-primary-foreground px-4 py-2 text-xs font-bold hover:opacity-95 transition"
                >
                  <ShoppingBag className="h-3.5 w-3.5" /> Add all to bag
                </button>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  )
}
