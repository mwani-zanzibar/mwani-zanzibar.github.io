'use client'

import { useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react'
import { reducedMotion } from '@/lib/perf'
import { PlusOne, useTilt } from '@/components/motion/effects'
import Image from 'next/image'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Check, ChevronLeft, ChevronRight, Heart, Plus, Star } from 'lucide-react'
import type { ApiProduct } from '@/lib/api'
import { useCart } from '@/lib/cart-store'
import { useWishlist } from '@/lib/wishlist-store'
import { useUI } from '@/lib/ui-store'
import { flyToCart } from '@/lib/cart-fx'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { EASE_OUT, SPRING_POP, SPRING_SNAPPY, SPRING_SOFT } from '@/components/shared/reveal'
import { CAT_SW } from '@/components/store/products-section'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'

const useIsoLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect
const LIFT = { type: 'spring', stiffness: 380, damping: 28 } as const

// Below this width the footer can't hold price + "＋ Add" side by side, so the
// button becomes a round "+" that stretches into "✓ Added" over the price.
function useCompact(ref: RefObject<HTMLElement | null>, min = 236) {
  const [compact, setCompact] = useState(false)
  useIsoLayoutEffect(() => {
    const el = ref.current
    if (!el) return
    setCompact(el.getBoundingClientRect().width < min)
    const ro = new ResizeObserver(([e]) => setCompact(e.contentRect.width + 16 < min))
    ro.observe(el)
    return () => ro.disconnect()
  }, [ref, min])
  return compact
}

export function ProductCard({ product: p, priority, hint }: { product: ApiProduct; priority?: boolean; hint?: boolean }) {
  const { t, lang } = useI18n()
  const money = useMoney()
  const reduce = useReducedMotion()
  const qty = useCart((s) => s.items.find((i) => i.productId === p.id)?.qty ?? 0)
  const wished = useWishlist((s) => s.items.some((i) => i.id === p.id))
  const cardRef = useRef<HTMLElement>(null)
  const wellRef = useRef<HTMLDivElement>(null)
  const compact = useCompact(cardRef)
  const tilt = useTilt(4)
  const [plus, setPlus] = useState(0)
  const [added, setAdded] = useState(false)
  const [burst, setBurst] = useState(0)
  const timers = useRef<number[]>([])
  useEffect(() => () => timers.current.forEach(clearTimeout), [])

  const soldOut = p.stock <= 0
  const low = !soldOut && p.lowStockThreshold > 0 && p.stock <= p.lowStockThreshold
  const maxed = !soldOut && qty >= p.stock
  // The clean cut-out first, then the real photographs, one swipe away.
  const slides = [p.image, ...(p.gallery || [])].filter((src, i, a) => src && a.indexOf(src) === i)
  const slideIdx = useRef(0)
  const slideEls = useRef<HTMLElement[]>([])
  const catFull = lang === 'sw' ? CAT_SW[p.category] || p.category : p.category
  const shortKey = `card.cat.${p.category}`
  const catShort = t(shortKey) === shortKey ? catFull : t(shortKey)

  const openQuick = () => useUI.getState().setQuick(p)

  const add = () => {
    if (soldOut || maxed) return
    useCart.getState().add({ productId: p.id, name: p.name, price: p.price, unit: p.unit, image: p.image, stock: p.stock })
    setAdded(true)
    setPlus((n) => n + 1)
    // Lift whichever picture is showing right now.
    flyToCart(slideEls.current[slideIdx.current] ?? wellRef.current)
    timers.current.forEach(clearTimeout)
    timers.current = [window.setTimeout(() => setAdded(false), 1600)]
  }

  const toggleWish = () => {
    const was = useWishlist.getState().has(p.id)
    useWishlist.getState().toggle({ id: p.id, name: p.name, price: p.price, image: p.image, category: p.category, unit: p.unit })
    if (!was) setBurst((b) => b + 1)
  }

  return (
    <motion.article
      ref={cardRef}
      whileHover={reduce ? undefined : { y: -4 }}
      transition={LIFT}
      style={tilt.style}
      onPointerMove={tilt.onPointerMove}
      onPointerLeave={tilt.onPointerLeave}
      className="group @container relative flex h-full flex-col rounded-[28px] bg-surface p-2 shadow-2 transition-shadow duration-300 ease-out hover:shadow-3"
    >
      {/* Image well (card-in-card): a small swipeable gallery. */}
      <div ref={wellRef} className="relative aspect-square select-none overflow-hidden rounded-[22px] bg-shell [-webkit-touch-callout:none]">
        <Gallery
          slides={slides}
          name={p.name}
          priority={priority}
          soldOut={soldOut}
          hint={hint}
          onOpen={openQuick}
          idxRef={slideIdx}
          elsRef={slideEls}
        />

        {/* Soft light that follows the cursor (desktop). */}
        {tilt.on && <span aria-hidden className="pointer-events-none absolute inset-0 opacity-0 mix-blend-soft-light transition-opacity duration-300 group-hover:opacity-100" style={{ background: 'radial-gradient(360px circle at var(--mx, 50%) var(--my, 30%), rgb(255 255 255 / 0.55), transparent 55%)' }} />}
        <span className="pointer-events-none absolute left-2.5 top-2.5 flex h-7 max-w-[calc(100%-4.25rem)] items-center rounded-full bg-surface/90 px-2.5 text-[0.76rem] font-semibold text-plum">
          <span className="truncate @[15rem]:hidden">{catShort}</span>
          <span className="hidden truncate @[15rem]:inline">{catFull}</span>
        </span>

        <button
          type="button"
          onClick={toggleWish}
          aria-pressed={wished}
          aria-label={wished ? t('card.unsave', { name: p.name }) : t('card.save', { name: p.name })}
          className="absolute right-2 top-2 grid h-10 w-10 place-items-center rounded-full bg-surface text-plum shadow-1 transition-colors duration-200 after:absolute after:-inset-0.5 after:content-[''] hover:bg-porcelain"
        >
          <motion.span
            key={burst}
            className="grid place-items-center"
            initial={{ scale: 1 }}
            animate={burst > 0 && !reduce ? { scale: [1, 1.25, 0.94, 1] } : { scale: 1 }}
            transition={{ duration: 0.45, ease: EASE_OUT }}
          >
            <Heart className={cn('h-[18px] w-[18px] transition-[fill] duration-200', wished ? 'fill-plum' : 'fill-transparent')} strokeWidth={2} aria-hidden />
          </motion.span>
          {burst > 0 && !reduce && <Burst key={burst} />}
        </button>

        {soldOut ? (
          <span className="pointer-events-none absolute bottom-2.5 left-2.5 flex h-7 items-center rounded-full bg-night px-2.5 text-[0.76rem] font-semibold text-on-night">
            {t('card.soldOut')}
          </span>
        ) : low ? (
          <span className="pointer-events-none absolute bottom-2.5 left-2.5 flex h-7 items-center gap-1.5 rounded-full bg-surface/90 px-2.5 text-[0.76rem] font-semibold text-plum">
            <span className="h-1.5 w-1.5 rounded-full bg-coral" aria-hidden />
            {t('card.onlyLeft', { n: p.stock })}
          </span>
        ) : null}
      </div>

      <div className="flex flex-1 flex-col px-1.5 pb-1 pt-3 @[15rem]:px-2.5 @[15rem]:pb-1.5">
        <button type="button" onClick={openQuick} className="text-left" aria-label={t('card.view', { name: p.name })}>
          <h3 className="line-clamp-3 text-[0.96rem] font-semibold leading-snug text-foreground @[11rem]:text-[1.02rem]">{p.name}</h3>
        </button>
        <div className="mt-1 flex min-w-0 items-center gap-2">
          <span className="truncate text-[14px] text-muted-foreground">{p.unit}</span>
          {p.reviewCount > 0 && (
            <span
              className="inline-flex h-6 shrink-0 items-center gap-1 rounded-full bg-shell px-2 text-[0.76rem] font-semibold text-plum"
              aria-label={t('card.rating', { r: p.rating.toFixed(1), n: p.reviewCount })}
            >
              <Star className="h-3 w-3 fill-plum" strokeWidth={0} aria-hidden />
              {p.rating.toFixed(1)}
            </span>
          )}
        </div>

        <div className="mt-auto flex items-center justify-between gap-2 pt-3">
          <AnimatePresence mode="popLayout" initial={false}>
            {!(compact && added) && (
              <motion.span
                key="price"
                layout="position"
                initial={{ opacity: 0, x: -6 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -6, transition: { duration: 0.12 } }}
                transition={{ duration: 0.22, ease: EASE_OUT }}
                className="tabular whitespace-nowrap text-[1.02rem] font-semibold text-plum"
              >
                {money(p.price)}
              </motion.span>
            )}
          </AnimatePresence>
          <span className={cn('relative flex', compact && added && 'flex-1')}>
            <PlusOne fire={plus} />
            <AddButton compact={compact} added={added} qty={qty} soldOut={soldOut} maxed={maxed} name={p.name} onAdd={add} />
          </span>
        </div>
      </div>
    </motion.article>
  )
}

function AddButton({ compact, added, qty, soldOut, maxed, name, onAdd }: {
  compact: boolean; added: boolean; qty: number; soldOut: boolean; maxed: boolean; name: string; onAdd: () => void
}) {
  const { t } = useI18n()
  const disabled = soldOut || maxed
  const showLabel = !compact || added
  const label = added ? t('card.added') : soldOut ? t('card.soldOut') : t('card.add')
  const aria = added ? t('card.addedAria', { name }) : soldOut ? t('card.soldOut') : maxed ? t('card.maxed', { name }) : t('card.addAria', { name })
  return (
    <motion.button
      type="button"
      layout
      onClick={onAdd}
      disabled={disabled && !added}
      aria-label={aria}
      whileTap={disabled ? undefined : { scale: 0.97 }}
      transition={{ layout: SPRING_SOFT }}
      style={{ borderRadius: 22 }}
      className={cn(
        'relative flex h-11 shrink-0 items-center justify-center gap-1.5 whitespace-nowrap text-[0.92rem] font-semibold transition-colors duration-200',
        added ? 'bg-lagoon-deep text-white' : 'bg-plum text-porcelain hover:bg-plum-2',
        disabled && !added && 'bg-sand text-plum/45 hover:bg-sand',
        compact ? (added ? 'flex-1 px-4' : 'w-11') : 'pl-3.5 pr-4',
      )}
    >
      <span className="relative grid h-[18px] w-[18px] shrink-0 place-items-center" aria-hidden>
        <AnimatePresence initial={false}>
          <motion.span
            key={added ? 'check' : 'plus'}
            className="absolute inset-0 grid place-items-center"
            initial={{ rotate: added ? -120 : 120, scale: 0.4, opacity: 0 }}
            animate={{ rotate: 0, scale: 1, opacity: 1 }}
            exit={{ rotate: added ? 120 : -120, scale: 0.4, opacity: 0 }}
            transition={SPRING_SNAPPY}
          >
            {added ? <Check className="h-[18px] w-[18px]" strokeWidth={2.6} /> : <Plus className="h-[18px] w-[18px]" strokeWidth={2.4} />}
          </motion.span>
        </AnimatePresence>
      </span>
      <AnimatePresence mode="popLayout" initial={false}>
        {showLabel && (
          <motion.span
            key={label}
            layout="position"
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -12, opacity: 0 }}
            transition={{ duration: 0.22, ease: EASE_OUT }}
            aria-hidden
          >
            {label}
          </motion.span>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {qty > 0 && !added && (
          <motion.span
            key="qty"
            layout="position"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={SPRING_POP}
            className="tabular absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-plum px-1 text-[0.7rem] font-bold leading-none text-porcelain ring-2 ring-surface"
            aria-label={t('card.inBag', { n: qty })}
          >
            {qty}
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  )
}

// The card's image well. Slides snap natively (smooth on low-end Android);
// dots show there is more to see, arrows appear on hover for mouse users, and
// the first card in the grid does a small one-time peek so phones discover it.
function Gallery({ slides, name, priority, soldOut, hint, onOpen, idxRef, elsRef }: {
  slides: string[]; name: string; priority?: boolean; soldOut: boolean; hint?: boolean
  onOpen: () => void; idxRef: RefObject<number>; elsRef: RefObject<HTMLElement[]>
}) {
  const { t } = useI18n()
  const scroller = useRef<HTMLDivElement>(null)
  const track = useRef<HTMLDivElement>(null)
  const [idx, setIdx] = useState(0)
  const many = slides.length > 1

  const onScroll = () => {
    const el = scroller.current
    if (!el) return
    const i = Math.round(el.scrollLeft / Math.max(1, el.clientWidth))
    if (i !== idx) { setIdx(i); idxRef.current = i }
  }
  const go = (i: number) => {
    const el = scroller.current
    if (!el) return
    const n = (i + slides.length) % slides.length
    el.scrollTo({ left: n * el.clientWidth, behavior: reducedMotion() ? 'auto' : 'smooth' })
  }

  // One gentle peek, once, when the first card scrolls into view.
  useEffect(() => {
    if (!hint || !many || reducedMotion()) return
    const el = track.current
    if (!el) return
    let done = false
    const io = new IntersectionObserver(([e]) => {
      if (done || !e.isIntersecting) return
      done = true; io.disconnect()
      window.setTimeout(() => {
        el.animate(
          [{ transform: 'translateX(0)' }, { transform: 'translateX(-22%)', offset: 0.45 }, { transform: 'translateX(-22%)', offset: 0.6 }, { transform: 'translateX(0)' }],
          { duration: 1100, easing: 'cubic-bezier(.65,0,.35,1)' },
        )
      }, 500)
    }, { threshold: 0.8 })
    io.observe(el)
    return () => io.disconnect()
  }, [hint, many])

  return (
    <>
      <div ref={scroller} onScroll={many ? onScroll : undefined}
        className={cn('no-scrollbar absolute inset-0 overscroll-x-contain', many ? 'snap-x snap-mandatory overflow-x-auto' : 'overflow-hidden')}>
        <div ref={track} className="flex h-full">
          {slides.map((src, i) => (
            <button key={src} type="button" tabIndex={-1} aria-hidden onClick={onOpen}
              ref={(el) => { if (el) elsRef.current[i] = el }}
              className="relative block h-full w-full shrink-0 cursor-pointer snap-center snap-always overflow-hidden">
              <Image
                src={src}
                alt={i === 0 ? name : ''}
                fill
                priority={priority && i === 0}
                sizes="(max-width: 767px) 50vw, (max-width: 1023px) 33vw, 360px"
                draggable={false}
                className={cn(fit(src), 'transition-transform duration-700 ease-out group-hover:scale-105', soldOut && 'opacity-50 saturate-[0.35]')}
              />
            </button>
          ))}
        </div>
      </div>

      {many && (
        <>
          {([['prev', -1, ChevronLeft, 'left-2'], ['next', 1, ChevronRight, 'right-2']] as const).map(([k, d, Icon, pos]) => (
            <button key={k} type="button" onClick={() => go(idx + d)} aria-label={t(`card.${k}`)}
              className={cn('absolute top-1/2 hidden h-9 w-9 -translate-y-1/2 place-items-center rounded-full bg-surface/95 text-plum opacity-0 shadow-1 transition-[opacity,transform] duration-200 hover:scale-105 focus-visible:opacity-100 group-hover:opacity-100 [@media(hover:hover)]:grid', pos)}>
              <Icon className="h-4 w-4" aria-hidden />
            </button>
          ))}
          <div className="absolute bottom-2 right-2 flex h-7 items-center rounded-full bg-surface/90 px-1.5" role="group" aria-label={t('card.photos')}>
            {slides.map((_, i) => (
              <button key={i} type="button" onClick={() => go(i)} aria-label={t('card.photo', { n: i + 1, total: slides.length })} aria-current={i === idx}
                className="relative grid h-7 w-4 place-items-center">
                <span className={cn('h-1.5 w-1.5 rounded-full transition-[background-color,transform] duration-200', i === idx ? 'scale-125 bg-plum' : 'bg-plum/25')} />
              </button>
            ))}
          </div>
        </>
      )}
    </>
  )
}

// Six rose/coral dots that fly out of the heart and fade (~450ms).
function Burst() {
  return (
    <span aria-hidden className="pointer-events-none absolute inset-0">
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2 - Math.PI / 2
        return (
          <motion.span
            key={i}
            className={cn('absolute left-1/2 top-1/2 -ml-[3px] -mt-[3px] h-1.5 w-1.5 rounded-full', i % 2 ? 'bg-coral' : 'bg-rose')}
            initial={{ x: 0, y: 0, opacity: 0, scale: 0.4 }}
            animate={{ x: Math.cos(a) * 21, y: Math.sin(a) * 21, opacity: [0, 1, 0], scale: [0.4, 1, 0.6] }}
            transition={{ duration: 0.45, ease: EASE_OUT, times: [0, 0.25, 1] }}
          />
        )
      })}
    </span>
  )
}
