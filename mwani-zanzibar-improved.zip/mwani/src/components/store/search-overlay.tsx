'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { CornerDownLeft, MessageCircle, Search, SearchX, X } from 'lucide-react'
import { ResponsiveSheet, useIsDesktop } from '@/components/store/overlay-shell'
import { EASE_OUT, SPRING_SNAPPY } from '@/components/shared/reveal'
import { catLabel } from '@/components/store/product-modal'
import { useUI } from '@/lib/ui-store'
import { useMoney } from '@/lib/use-money'
import { useI18n } from '@/lib/i18n'
import { whatsappLink } from '@/lib/format'
import { api, type ApiProduct } from '@/lib/api'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'

// Swahili shoppers type Swahili; product data is English. Map the common words.
const SW: Record<string, string[]> = {
  unga: ['powder'], chai: ['tea'], sabuni: ['soap'], nywele: ['hair'], vidonge: ['capsule'], kidonge: ['capsule'],
  mafuta: ['oil'], supu: ['soup'], ngozi: ['skin'], mwani: ['seaweed'], chumvi: ['salt'], losheni: ['lotion'],
  shampuu: ['shampoo'], jeli: ['jelly'], karafuu: ['clove'], tangawizi: ['ginger'], mdalasini: ['cinnamon'],
  manjano: ['turmeric'], limau: ['lemon'], ndimu: ['lemon'], mkaratusi: ['eucalyptus'], kusugua: ['scrub'], iliyokaushwa: ['dried'], nazi: ['coconut'], chakula: ['food'], afya: ['health', 'wellness'], kuoga: ['bath'],
  masaji: ['massage'], mwili: ['body'],
}
const STOP = new Set(['wa', 'na', 'ya', 'za', 'la', 'kwa', 'of', 'the', 'and', 'for', '&'])

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

type Hit = { p: ApiProduct; score: number; terms: string[]; via: string; viaIng: boolean }

function alternatives(tok: string) {
  const alts = new Set([tok])
  if (tok.length >= 3) for (const [k, v] of Object.entries(SW)) if (k.startsWith(tok)) { alts.add(k); v.forEach((x) => alts.add(x)) }
  // plural forms: "capsules" should find "capsule", "oils" "oil"
  if (tok.length > 3 && tok.endsWith('s')) alts.add(tok.slice(0, -1))
  return [...alts]
}

function searchProducts(products: ApiProduct[], q: string): Hit[] {
  const tokens = norm(q).split(/\s+/).filter((x) => x && !STOP.has(x))
  if (!tokens.length) return []
  const hits: Hit[] = []
  for (const p of products) {
    if (p.active === false) continue
    const name = norm(p.name), tag = norm(p.tagline || ''), cat = norm(p.category || ''), ings = (p.ingredients || []).map(norm)
    let score = 0
    const terms: string[] = []
    let via = ''
    let viaIng = false
    let ok = true
    for (const tok of tokens) {
      let best = 0
      for (const a of alternatives(tok)) {
        let s = 0
        if (name.includes(a)) s = new RegExp(`(^|\\s)${esc(a)}`).test(name) ? 6 : 4
        else if (tag.includes(a)) s = 2.5
        else if (cat.includes(a)) s = 2
        else if (ings.some((x) => x.includes(a))) s = 1
        if (s > 0) terms.push(a)
        best = Math.max(best, s)
      }
      if (!best) { ok = false; break }
      score += best
    }
    if (!ok) continue
    // Say why a product matched when its name does not show it.
    if (!terms.some((a) => name.includes(a))) {
      const ing = (p.ingredients || []).find((x) => terms.some((a) => norm(x).includes(a)))
      if (ing) { via = ing; viaIng = true }
      else {
        const a = terms.find((x) => tag.includes(x))
        const m = a ? (p.tagline || '').match(new RegExp(`\\S*${esc(a)}\\S*`, 'i')) : null
        if (m) via = m[0].replace(/[.,;:]$/, '')
      }
    }
    hits.push({ p, score: score + (p.featured ? 0.5 : 0), terms, via, viaIng })
  }
  return hits.sort((a, b) => b.score - a.score)
}

function Mark({ text, terms }: { text: string; terms: string[] }) {
  if (!terms.length) return <>{text}</>
  const re = new RegExp(`(${[...terms].sort((a, b) => b.length - a.length).map(esc).join('|')})`, 'ig')
  const parts = text.split(re)
  return (
    <>
      {parts.map((part, i) => i % 2 === 1
        ? <mark key={i} className="rounded-[4px] bg-rose/25 px-[1px] font-semibold text-plum">{part}</mark>
        : <span key={i}>{part}</span>)}
    </>
  )
}

function isField(el: EventTarget | null) {
  const n = el as HTMLElement | null
  return !!n?.closest?.('input, textarea, select, [contenteditable="true"]')
}

/** Command-palette search. Opens from useUI.searchOpen, "/" or Ctrl/⌘+K. */
export function SearchOverlay({ products }: { products: ApiProduct[] }) {
  const open = useUI((s) => s.searchOpen)
  const setOpen = useUI((s) => s.setSearchOpen)
  const setQuick = useUI((s) => s.setQuick)
  const { t } = useI18n()
  const money = useMoney()
  const desktop = useIsDesktop()
  const [q, setQ] = useState('')
  const [active, setActive] = useState(0)
  const [wa, setWa] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  // Keyboard shortcut: "/" or Ctrl/⌘+K, unless the shopper is typing or another dialog is up.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const combo = (e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k'
      const slash = e.key === '/' && !e.metaKey && !e.ctrlKey && !e.altKey
      if (!combo && !slash) return
      if (isField(e.target)) return
      const ui = useUI.getState()
      if (ui.searchOpen) { if (combo) e.preventDefault(); return }
      if (document.querySelector('[role="dialog"]')) return
      e.preventDefault()
      ui.setSearchOpen(true)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  useEffect(() => {
    if (!open) return
    setQ(''); setActive(0)
    const id = window.setTimeout(() => inputRef.current?.focus(), 60)
    if (!wa) api.settings().then((r) => setWa(r.settings.whatsappPrimary || '')).catch(() => {})
    return () => clearTimeout(id)
  }, [open]) // eslint-disable-line react-hooks/exhaustive-deps

  const hits = useMemo(() => searchProducts(products, q), [products, q])
  const popular = useMemo(() => {
    const live = products.filter((p) => p.active !== false)
    const f = live.filter((p) => p.featured)
    return (f.length ? f : live).slice(0, desktop ? 4 : 8)
  }, [products, desktop])
  useEffect(() => { setActive(0) }, [q])

  const query = q.trim()
  const pick = (p: ApiProduct) => { setOpen(false); setQuick(p) }

  useEffect(() => {
    const h = hits[active]
    if (h) document.getElementById(`search-opt-${h.p.id}`)?.scrollIntoView({ block: 'nearest' })
  }, [active, hits])

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!hits.length) return
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((a) => Math.min(a + 1, hits.length - 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)) }
    else if (e.key === 'Enter') { e.preventDefault(); const h = hits[active]; if (h) pick(h.p) }
  }

  const chips = ['powder', 'tea', 'soap', 'hair', 'capsules'].map((k) => t(`search.chip.${k}`))

  return (
    <ResponsiveSheet
      open={open}
      onOpenChange={setOpen}
      title={t('search.title')}
      hideTitle
      hideClose
      size="lg"
      className="h-[90svh] overflow-hidden md:h-auto md:top-[9vh] md:max-h-[80vh] md:translate-y-0"
    >
      <MotionConfig reducedMotion="user">
        {/* Search field stays pinned while results scroll */}
        <div className="sticky top-[-16px] z-10 -mx-5 -mt-4 bg-card px-5 pb-3 pt-4 md:top-[-20px] md:-mx-7 md:-mt-5 md:px-7 md:pt-5">
          <div className="flex items-center gap-2">
            <div className="relative min-w-0 flex-1">
              <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-plum/70" aria-hidden />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder={t('search.placeholder')}
                aria-label={t('search.title')}
                role="combobox"
                aria-expanded={hits.length > 0}
                aria-controls="search-list"
                aria-autocomplete="list"
                aria-activedescendant={hits[active] ? `search-opt-${hits[active].p.id}` : undefined}
                enterKeyHint="search"
                autoComplete="off"
                spellCheck={false}
                className="h-14 w-full rounded-[18px] border border-input bg-card pl-12 pr-12 text-[1.05rem] text-foreground outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted-foreground focus:border-plum focus:ring-2 focus:ring-plum/20 md:pr-28"
              />
              <div className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1">
                <AnimatePresence initial={false}>
                  {q && (
                    <motion.button
                      key="clear"
                      onClick={() => { setQ(''); inputRef.current?.focus() }}
                      aria-label={t('search.clear')}
                      className="grid h-10 w-10 place-items-center rounded-full text-muted-foreground hover:bg-shell hover:text-plum"
                      initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} transition={{ duration: 0.15 }}
                    >
                      <X className="h-[18px] w-[18px]" aria-hidden />
                    </motion.button>
                  )}
                </AnimatePresence>
                {desktop && (
                  <button onClick={() => setOpen(false)} className="press h-8 rounded-[10px] bg-shell px-2.5 text-[0.78rem] font-semibold tracking-wide text-plum hover:bg-sand" aria-label={t('search.close')}>
                    Esc
                  </button>
                )}
              </div>
            </div>
            {!desktop && (
              <button onClick={() => setOpen(false)} className="press h-12 shrink-0 rounded-full px-3 text-[0.98rem] font-medium text-plum">
                {t('search.cancel')}
              </button>
            )}
          </div>
        </div>

        <AnimatePresence mode="wait" initial={false}>
          {!query ? (
            <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.16 }} className="pt-2">
              <p className="text-[0.9rem] font-medium text-muted-foreground">{t('search.try')}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {chips.map((c, i) => (
                  <motion.button
                    key={c}
                    onClick={() => { setQ(c); inputRef.current?.focus() }}
                    className="press inline-flex h-10 items-center gap-2 rounded-full bg-card px-4 text-[0.92rem] font-medium text-plum shadow-1 ring-1 ring-border/60 hover:ring-plum/30"
                    initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.24, delay: i * 0.04, ease: EASE_OUT }}
                  >
                    <Search className="h-3.5 w-3.5 opacity-60" aria-hidden />{c}
                  </motion.button>
                ))}
              </div>

              {popular.length > 0 && (
                <>
                  <p className="mt-8 text-[0.9rem] font-medium text-muted-foreground">{t('search.popular')}</p>
                  <ul className="no-scrollbar -mx-5 mt-3 flex snap-x scroll-px-5 gap-3 overflow-x-auto px-5 pb-2 md:mx-0 md:grid md:grid-cols-4 md:overflow-visible md:px-0">
                    {popular.map((p, i) => (
                      <motion.li
                        key={p.id}
                        className="w-[42%] shrink-0 snap-start md:w-auto"
                        initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.32, delay: 0.08 + i * 0.05, ease: EASE_OUT }}
                      >
                        <button onClick={() => pick(p)} className="group block w-full rounded-[20px] text-left">
                          <span className="relative block aspect-square overflow-hidden rounded-[18px] bg-shell">
                            <Image src={p.image} alt="" fill sizes="(min-width: 768px) 170px, 42vw" className={`${fit(p.image, 'lg')} transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]`} />
                          </span>
                          <span className="mt-2 block truncate px-0.5 text-[0.93rem] font-medium text-foreground group-hover:text-plum">{p.name}</span>
                          <span className="block px-0.5 text-[0.86rem] text-muted-foreground tabular">{money(p.price)}</span>
                        </button>
                      </motion.li>
                    ))}
                  </ul>
                </>
              )}
            </motion.div>
          ) : hits.length ? (
            <motion.div key="hits" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.14 }} className="pt-1">
              <div className="flex items-center justify-between px-1 pb-2 text-[0.86rem] text-muted-foreground">
                <span aria-live="polite">{hits.length === 1 ? t('search.resultsOne') : t('search.resultsMany', { n: hits.length })}</span>
                {desktop && (
                  <span className="flex items-center gap-3" aria-hidden>
                    <span className="flex items-center gap-1.5"><kbd className="grid h-6 min-w-6 place-items-center rounded-[7px] bg-shell px-1 text-[0.75rem] font-semibold text-plum">↑</kbd><kbd className="grid h-6 min-w-6 place-items-center rounded-[7px] bg-shell px-1 text-[0.75rem] font-semibold text-plum">↓</kbd>{t('search.move')}</span>
                    <span className="flex items-center gap-1.5"><kbd className="grid h-6 min-w-6 place-items-center rounded-[7px] bg-shell px-1 text-plum"><CornerDownLeft className="h-3 w-3" /></kbd>{t('search.open')}</span>
                  </span>
                )}
              </div>
              <ul id="search-list" role="listbox" aria-label={t('search.title')} className="space-y-1">
                {hits.map((h, i) => {
                  const on = i === active
                  return (
                    <motion.li
                      key={h.p.id}
                      id={`search-opt-${h.p.id}`}
                      role="option"
                      aria-selected={on}
                      layout="position"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.26, delay: Math.min(i, 8) * 0.035, ease: EASE_OUT, layout: SPRING_SNAPPY }}
                      onMouseMove={() => { if (!on) setActive(i) }}
                      onClick={() => pick(h.p)}
                      className="relative flex cursor-pointer items-center gap-3.5 rounded-[18px] p-2 pr-3"
                    >
                      {on && <motion.span layoutId="search-active" className="absolute inset-0 rounded-[18px] bg-shell" transition={SPRING_SNAPPY} />}
                      <span className="relative h-14 w-14 shrink-0 overflow-hidden rounded-[14px] bg-shell">
                        <Image src={h.p.image} alt="" fill sizes="56px" className={fit(h.p.image, 'sm')} />
                      </span>
                      <span className="relative min-w-0 flex-1">
                        <span className="line-clamp-2 block text-[1rem] font-medium leading-snug text-foreground"><Mark text={h.p.name} terms={h.terms} /></span>
                        <span className="mt-0.5 flex min-w-0 items-center gap-2 text-[0.86rem] text-muted-foreground">
                          <span className="truncate"><Mark text={catLabel(t, h.p.category)} terms={h.terms} /></span>
                          {h.via && (
                            <span className="shrink-0 truncate rounded-full bg-card px-2 py-0.5 text-[0.78rem] text-plum ring-1 ring-border">
                              {h.viaIng ? (() => { const [pre, post = ''] = t('search.contains', { x: '\u0001' }).split('\u0001'); return <>{pre}<Mark text={h.via} terms={h.terms} />{post}</> })() : <Mark text={h.via} terms={h.terms} />}
                            </span>
                          )}
                        </span>
                      </span>
                      <span className="relative shrink-0 text-[0.95rem] font-semibold text-plum tabular">{money(h.p.price)}</span>
                    </motion.li>
                  )
                })}
              </ul>
            </motion.div>
          ) : (
            <motion.div key="none" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.22, ease: EASE_OUT }} className="flex flex-col items-center px-2 pb-4 pt-8 text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-shell text-plum"><SearchX className="h-7 w-7" aria-hidden /></span>
              <h3 className="mt-5 max-w-[26ch] break-words font-display text-[1.5rem] leading-tight text-plum" role="status">{t('search.none', { q: query })}</h3>
              <p className="mt-2 max-w-[44ch] text-[0.96rem] text-muted-foreground">{t('search.noneBody')}</p>
              {wa && (
                <a
                  href={whatsappLink(wa, t('search.waMsg', { q: query }))}
                  target="_blank"
                  rel="noreferrer"
                  className="press mt-6 inline-flex h-12 items-center gap-2 rounded-full bg-plum px-6 text-[0.98rem] font-semibold text-porcelain hover:bg-plum-2"
                >
                  <MessageCircle className="h-[18px] w-[18px]" aria-hidden />{t('search.ask')}
                </a>
              )}
              <div className="mt-8 flex flex-wrap justify-center gap-2">
                {chips.map((c) => (
                  <button key={c} onClick={() => { setQ(c); inputRef.current?.focus() }} className="press inline-flex h-10 items-center rounded-full bg-card px-4 text-[0.92rem] font-medium text-plum shadow-1 ring-1 ring-border/60 hover:ring-plum/30">
                    {c}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </MotionConfig>
    </ResponsiveSheet>
  )
}
