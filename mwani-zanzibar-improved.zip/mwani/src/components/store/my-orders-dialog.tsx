'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { MotionConfig, motion } from 'framer-motion'
import { ArrowRight, Package, Search } from 'lucide-react'
import { ResponsiveSheet } from '@/components/store/overlay-shell'
import { orderSteps, StatusChip } from '@/components/store/track-dialog'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { EASE_OUT } from '@/components/shared/reveal'
import { api, type ApiOrder } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { useUI } from '@/lib/ui-store'
import { fit } from '@/lib/img-fit'

// Lists orders placed from this phone or computer. Order details are never
// looked up by phone number, so one customer can't see another's orders.
export function MyOrdersDialog() {
  const open = useUI((s) => s.myOrdersOpen)
  const setOpen = useUI((s) => s.setMyOrdersOpen)
  const openTrack = useUI((s) => s.openTrack)
  const { t, lang } = useI18n()
  const money = useMoney()
  const [orders, setOrders] = useState<ApiOrder[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    let live = true
    setLoading(true)
    api.myOrders()
      .then((r) => { if (live) setOrders([...r.orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt))) })
      .catch(() => { if (live) setOrders([]) })
      .finally(() => { if (live) setLoading(false) })
    return () => { live = false }
  }, [open])

  const track = (orderNumber?: string) => {
    setOpen(false)
    window.setTimeout(() => openTrack(orderNumber), 200)
  }

  const locale = lang === 'sw' ? 'sw-TZ' : 'en-GB'

  return (
    <ResponsiveSheet open={open} onOpenChange={setOpen} title={t('orders.title')} description={t('orders.subtitle')} size="md">
      <MotionConfig reducedMotion="user">
        {loading ? (
          <div className="space-y-3" aria-busy>
            {[0, 1].map((i) => <div key={i} className="shimmer h-[168px] rounded-[24px]" />)}
          </div>
        ) : orders.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: EASE_OUT }}
            className="flex flex-col items-center px-2 py-10 text-center"
          >
            <span className="grid h-16 w-16 place-items-center rounded-full bg-shell text-plum">
              <Package className="h-7 w-7" aria-hidden />
            </span>
            <h3 className="mt-5 font-display text-[1.6rem] leading-tight text-plum">{t('orders.empty')}</h3>
            <p className="mt-2 max-w-xs text-muted-foreground">{t('orders.emptyHint')}</p>
            <div className="mt-6 flex flex-col items-center gap-2 sm:flex-row sm:gap-3">
              <button
                type="button"
                onClick={() => track()}
                className="press inline-flex h-12 items-center gap-2 rounded-full bg-plum px-6 font-semibold text-porcelain hover:bg-plum-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum focus-visible:ring-offset-2"
              >
                <Search className="h-4 w-4" aria-hidden /> {t('orders.trackOther')}
              </button>
              <button
                type="button"
                onClick={() => { setOpen(false); window.setTimeout(() => scrollToId('shop'), 280) }}
                className="inline-flex min-h-11 items-center rounded-full px-3 font-semibold text-plum focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum"
              >
                <span className="link-draw">{t('orders.shop')}</span>
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.ul
            className="space-y-3"
            initial="hidden"
            animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.06, delayChildren: 0.05 } } }}
          >
            {orders.map((o) => {
              const steps = orderSteps(o.deliveryChannel, o.status)
              const current = steps.indexOf(o.status)
              const progress = current < 0 ? 0 : (current + 1) / steps.length
              const count = o.items.reduce((n, i) => n + i.qty, 0)
              const thumbs = o.items.filter((i) => i.image).slice(0, 3)
              return (
                <motion.li
                  key={o.orderNumber}
                  variants={{
                    hidden: { opacity: 0, y: 20, scale: 0.98 },
                    show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.45, ease: EASE_OUT } },
                  }}
                  className="rounded-[24px] bg-surface p-5 shadow-2 ring-1 ring-border/70"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate text-[1.05rem] font-semibold tracking-wide text-foreground tabular">{o.orderNumber}</div>
                      <div className="mt-0.5 text-sm text-muted-foreground">
                        {new Date(o.createdAt).toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' })}
                        <span className="mx-1.5 opacity-60" aria-hidden>·</span>
                        {count === 1 ? t('orders.item1') : t('orders.items', { n: count })}
                      </div>
                    </div>
                    <StatusChip status={o.status} />
                  </div>

                  {o.status !== 'cancelled' && (
                    <div
                      className="mt-4 h-1.5 overflow-hidden rounded-full bg-sand"
                      role="img"
                      aria-label={t('orders.step', { n: Math.max(1, current + 1), total: steps.length })}
                    >
                      <motion.div
                        className="h-full w-full origin-left rounded-full bg-plum"
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: progress }}
                        transition={{ duration: 0.8, ease: EASE_OUT, delay: 0.25 }}
                      />
                    </div>
                  )}

                  <div className="mt-4 flex items-center justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      {thumbs.length > 0 && (
                        <span className="flex shrink-0 -space-x-2.5" aria-hidden>
                          {thumbs.map((it, k) => (
                            <span key={it.productId} className="relative h-10 w-10 overflow-hidden rounded-full bg-shell ring-[3px] ring-surface" style={{ zIndex: 3 - k }}>
                              <Image src={it.image} alt="" fill sizes="40px" className={fit(it.image, 'sm')} />
                            </span>
                          ))}
                        </span>
                      )}
                      <span className="truncate text-[1.05rem] font-semibold text-foreground tabular">{money(o.total)}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => track(o.orderNumber)}
                      aria-label={t('orders.trackAria', { n: o.orderNumber })}
                      className="press group inline-flex h-11 shrink-0 items-center gap-1.5 rounded-full bg-plum px-4 text-[0.95rem] font-semibold text-porcelain hover:bg-plum-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-plum focus-visible:ring-offset-2"
                    >
                      {t('orders.track')}
                      <ArrowRight className="h-4 w-4 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-0.5" aria-hidden />
                    </button>
                  </div>
                </motion.li>
              )
            })}
          </motion.ul>
        )}
      </MotionConfig>
    </ResponsiveSheet>
  )
}
