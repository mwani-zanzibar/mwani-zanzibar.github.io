'use client'

import { useId, useState } from 'react'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { AlertCircle, ArrowRight, Check, Loader2, Mail } from 'lucide-react'
import { api } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { EASE_OUT, SPRING_POP, SPRING_SOFT } from '@/components/shared/reveal'
import { cn } from '@/lib/utils'

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

// One pill: the field and the button share a rounded container. On success
// the button folds into a check and the field turns into a confirmation line.
export function NewsletterForm({ compact = false, dark = false }: { compact?: boolean; dark?: boolean }) {
  const { t } = useI18n()
  const id = useId()
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [done, setDone] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (done || loading) return
    const v = email.trim()
    if (!v) { setError(t('news.errEmpty')); return }
    if (!EMAIL.test(v)) { setError(t('news.errInvalid')); return }
    setError('')
    setLoading(true)
    try {
      await api.subscribe(v)
      setDone(true)
      setEmail('')
    } catch (err) {
      const msg = (err as Error).message || ''
      setError(/valid email/i.test(msg) ? t('news.errInvalid') : t('news.errGeneric'))
    } finally {
      setLoading(false)
    }
  }

  const errId = `${id}-err`

  return (
    <MotionConfig reducedMotion="user">
      <form onSubmit={submit} noValidate className="w-full">
        <div
          className={cn(
            'relative flex items-center rounded-full transition-[box-shadow,background-color] duration-200',
            compact ? 'h-[52px] p-1' : 'h-[60px] p-1.5',
            dark
              ? 'bg-white/10 text-on-night ring-1 ring-white/15 focus-within:ring-2 focus-within:ring-on-night'
              : 'bg-surface text-foreground shadow-1 ring-1 ring-input focus-within:ring-2 focus-within:ring-plum',
            error && (dark ? 'ring-2 ring-coral' : 'ring-2 ring-destructive'),
          )}
        >
          <label htmlFor={id} className="sr-only">{t('news.label')}</label>
          <Mail
            aria-hidden
            className={cn('ml-3 h-[18px] w-[18px] shrink-0 transition-opacity duration-200', dark ? 'text-on-night/60' : 'text-muted-foreground', done && 'opacity-0')}
          />
          <div className="relative h-full min-w-0 flex-1">
            <AnimatePresence initial={false} mode="popLayout">
              {done ? (
                <motion.p
                  key="done"
                  role="status"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease: EASE_OUT, delay: 0.12 }}
                  className={cn('absolute inset-0 flex items-center truncate pl-1 pr-2 font-semibold', compact ? 'text-[0.95rem]' : 'text-base', dark ? 'text-on-night' : 'text-plum')}
                >
                  {t('news.done')}
                </motion.p>
              ) : (
                <motion.input
                  key="input"
                  id={id}
                  type="email"
                  name="email"
                  inputMode="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => { setEmail(e.target.value); if (error) setError('') }}
                  placeholder={t('news.ph')}
                  aria-invalid={!!error}
                  aria-describedby={error ? errId : undefined}
                  exit={{ opacity: 0, y: -12, transition: { duration: 0.2, ease: EASE_OUT } }}
                  className={cn(
                    'absolute inset-0 h-full w-full min-w-0 bg-transparent pl-2.5 pr-2 text-base outline-none',
                    dark ? 'text-on-night placeholder:text-on-night/60' : 'text-foreground placeholder:text-muted-foreground/80',
                  )}
                />
              )}
            </AnimatePresence>
          </div>
          <motion.button
            layout
            type="submit"
            disabled={loading || done}
            aria-busy={loading}
            aria-label={done ? t('news.doneAria') : loading ? t('news.joining') : undefined}
            transition={SPRING_SOFT}
            style={{ borderRadius: 999 }}
            className={cn(
              'press group relative flex h-full shrink-0 items-center justify-center overflow-hidden font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
              done ? 'aspect-square px-0' : compact ? 'px-5' : 'px-6',
              done
                ? 'bg-lagoon-deep text-white'
                : dark
                  ? 'bg-on-night text-night hover:bg-surface focus-visible:ring-on-night focus-visible:ring-offset-night'
                  : 'bg-plum text-porcelain hover:bg-plum-2 focus-visible:ring-plum',
              loading && 'cursor-progress',
            )}
          >
            <AnimatePresence initial={false} mode="popLayout">
              {done ? (
                <motion.span key="ok" layout initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ ...SPRING_POP, delay: 0.08 }}>
                  <Check className="h-5 w-5" strokeWidth={3} aria-hidden />
                </motion.span>
              ) : loading ? (
                <motion.span key="busy" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.15 }} className="flex items-center gap-2">
                  <Loader2 className="h-[18px] w-[18px] animate-spin" aria-hidden />
                  <span className="sr-only sm:not-sr-only">{t('news.join')}</span>
                </motion.span>
              ) : (
                <motion.span key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, transition: { duration: 0.1 } }} transition={{ duration: 0.15 }} className="flex items-center gap-1.5">
                  {t('news.join')}
                  <ArrowRight className="h-4 w-4 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-0.5" aria-hidden />
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>
        </div>
        <AnimatePresence initial={false}>
          {error && (
            <motion.p
              key={error}
              id={errId}
              role="alert"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2, ease: EASE_OUT }}
              className={cn('mt-2 flex items-start gap-1.5 px-3 text-sm leading-snug', dark ? 'text-on-night/90' : 'text-destructive')}
            >
              <AlertCircle className={cn('mt-[2px] h-4 w-4 shrink-0', dark && 'text-coral')} aria-hidden /> {error}
            </motion.p>
          )}
        </AnimatePresence>
      </form>
    </MotionConfig>
  )
}
