'use client'

import { useEffect, useState } from 'react'
import * as D from '@radix-ui/react-dialog'
import { Drawer } from 'vaul'
import { X } from 'lucide-react'
import { cn } from '@/lib/utils'

export function useIsDesktop(query = '(min-width: 768px)') {
  const [is, setIs] = useState(false)
  useEffect(() => {
    const m = window.matchMedia(query)
    const on = () => setIs(m.matches)
    on(); m.addEventListener('change', on)
    return () => m.removeEventListener('change', on)
  }, [query])
  return is
}

const WIDTH = { sm: 'max-w-md', md: 'max-w-xl', lg: 'max-w-3xl', xl: 'max-w-5xl' } as const

// One shell for every overlay: a centred dialog or right-hand panel on
// desktop, a draggable bottom sheet on phones. Same scrim, radius and motion
// everywhere (DESIGN.md: 380ms in, 260ms out).
export function ResponsiveSheet({
  open, onOpenChange, title, description, children, size = 'md', side = 'center', className, hideTitle = false, hideClose = false,
}: {
  open: boolean
  onOpenChange: (v: boolean) => void
  title: string
  description?: string
  children: React.ReactNode
  size?: keyof typeof WIDTH
  side?: 'center' | 'right'
  className?: string
  hideTitle?: boolean
  hideClose?: boolean
}) {
  const desktop = useIsDesktop()

  const close = !hideClose && (
    <button
      onClick={() => onOpenChange(false)}
      aria-label="Close"
      className="press absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-shell text-plum hover:bg-sand"
    >
      <X className="h-[18px] w-[18px]" aria-hidden />
    </button>
  )

  if (!desktop) {
    return (
      <Drawer.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={false}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 z-[80] bg-night/45 backdrop-blur-[6px]" />
          <Drawer.Content
            data-lenis-prevent
            className={cn('fixed inset-x-0 bottom-0 z-[81] flex max-h-[92svh] flex-col rounded-t-[28px] bg-card text-card-foreground shadow-3 outline-none', className)}
          >
            <div className="mx-auto mt-3 h-1.5 w-11 shrink-0 rounded-full bg-foreground/15" aria-hidden />
            <Drawer.Title className={hideTitle ? 'sr-only' : 'px-5 pt-4 font-display text-[1.6rem] leading-tight text-plum'}>{title}</Drawer.Title>
            {description ? <Drawer.Description className={hideTitle ? 'sr-only' : 'px-5 pt-1 text-sm text-muted-foreground'}>{description}</Drawer.Description> : <Drawer.Description className="sr-only">{title}</Drawer.Description>}
            {close}
            <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 pb-[max(20px,env(safe-area-inset-bottom))] pt-4">{children}</div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    )
  }

  return (
    <D.Root open={open} onOpenChange={onOpenChange}>
      <D.Portal>
        <D.Overlay className="fixed inset-0 z-[80] bg-night/40 backdrop-blur-[6px] data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:duration-300 data-[state=closed]:duration-200" />
        <D.Content
          data-lenis-prevent
          className={cn(
            'fixed z-[81] flex flex-col bg-card text-card-foreground shadow-3 outline-none',
            'data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=open]:duration-[380ms] data-[state=closed]:duration-[260ms] ease-[cubic-bezier(.22,1,.36,1)]',
            side === 'right'
              ? 'bottom-3 right-3 top-3 w-[440px] rounded-[28px] data-[state=open]:slide-in-from-right-8 data-[state=closed]:slide-out-to-right-8 data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0'
              : cn('left-1/2 top-1/2 max-h-[90vh] w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 rounded-[28px] data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0 data-[state=open]:zoom-in-[0.97] data-[state=closed]:zoom-out-[0.98] data-[state=open]:slide-in-from-bottom-3', WIDTH[size]),
            className,
          )}
        >
          <D.Title className={hideTitle ? 'sr-only' : 'px-7 pt-7 pr-16 font-display text-[1.9rem] leading-tight text-plum'}>{title}</D.Title>
          {description ? <D.Description className={hideTitle ? 'sr-only' : 'px-7 pt-1.5 text-[0.95rem] text-muted-foreground'}>{description}</D.Description> : <D.Description className="sr-only">{title}</D.Description>}
          {close}
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-7 pb-7 pt-5 scrollbar-thin">{children}</div>
        </D.Content>
      </D.Portal>
    </D.Root>
  )
}
