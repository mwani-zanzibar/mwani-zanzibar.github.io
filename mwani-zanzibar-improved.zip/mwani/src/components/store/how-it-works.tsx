'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { Check, CheckCheck, MessageCircle, Ship, Store, Truck } from 'lucide-react'
import { gsap, ScrollTrigger, useGSAP } from '@/lib/gsap'
import { reducedMotion } from '@/lib/perf'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { whatsappLink } from '@/lib/format'
import { Reveal, SplitReveal, Stagger, StaggerItem } from '@/components/shared/reveal'
import { cn } from '@/lib/utils'
import type { ApiSettings } from '@/lib/api'

const WA_GREEN = '#1f8a5a'
const PAYMENTS = ['M-Pesa', 'Tigo Pesa', 'Airtel Money', 'how.pay.bank']
const FALLBACK_WA = '+255774870703'

// Ordering, told as a path that draws itself down the page. Each numbered
// node pops as the line reaches it, and that step's little UI wakes up.
export function HowItWorks({ settings }: { settings: ApiSettings | null }) {
  const { t, lang } = useI18n()
  const money = useMoney()
  const root = useRef<HTMLElement>(null)
  const list = useRef<HTMLOListElement>(null)
  const [geo, setGeo] = useState<{ d: string; w: number; h: number; y0: number; y1: number; stops: string[] } | null>(null)
  const wa = whatsappLink(settings?.whatsappPrimary || FALLBACK_WA, t('how.waMsg'))

  // Measure node centres (layout positions, ignoring transforms) and build a
  // path that curves from one to the next.
  const measure = useCallback(() => {
    const ol = list.current
    if (!ol) return
    const pts = Array.from(ol.querySelectorAll<HTMLElement>('[data-node]')).map((n) => {
      let x = n.offsetWidth / 2, y = n.offsetHeight / 2
      for (let e: HTMLElement | null = n; e && e !== ol; e = e.offsetParent as HTMLElement | null) { x += e.offsetLeft; y += e.offsetTop }
      return { x, y }
    })
    if (pts.length < 2) return
    const segs = pts.slice(1).map((q, i) => {
      const p = pts[i]
      const my = (p.y + q.y) / 2
      return `C ${p.x} ${my} ${q.x} ${my} ${q.x} ${q.y}`
    })
    const start = `M ${pts[0].x} ${pts[0].y}`
    // Cumulative path strings, so each node knows how far along the line it sits.
    const stops = pts.map((_, i) => [start, ...segs.slice(0, i)].join(' '))
    const d = [start, ...segs].join(' ')
    const w = ol.offsetWidth, h = ol.offsetHeight
    setGeo((g) => (g && g.d === d && g.w === w && g.h === h ? g : { d, w, h, y0: pts[0].y, y1: pts[pts.length - 1].y, stops }))
  }, [])

  useEffect(() => {
    measure()
    const ol = list.current
    if (!ol) return
    const ro = new ResizeObserver(() => measure())
    ro.observe(ol)
    return () => ro.disconnect()
  }, [measure, lang])

  useGSAP(() => {
    const ol = list.current
    const path = ol?.querySelector<SVGPathElement>('[data-draw]')
    const probe = ol?.querySelector<SVGPathElement>('[data-probe]')
    if (!ol || !path || !probe || !geo) return
    const items = Array.from(ol.querySelectorAll<HTMLElement>('[data-step]'))
    const nodes = items.map((li) => li.querySelector<HTMLElement>('[data-node]'))
    const len = path.getTotalLength()
    const at = geo.stops.map((d, i) => {
      if (i === 0) return 0
      probe.setAttribute('d', d)
      return probe.getTotalLength() / len
    })
    const setOn = (i: number, on: boolean, pop: boolean) => {
      const li = items[i]
      if (!li || (li.dataset.on === 'true') === on) return
      li.dataset.on = String(on)
      const node = nodes[i]
      if (on && pop && node) gsap.fromTo(node, { scale: 0.62 }, { scale: 1, duration: 0.55, ease: 'back.out(3.2)', overwrite: true })
    }

    if (reducedMotion()) {
      gsap.set(path, { strokeDasharray: 'none', strokeDashoffset: 0 })
      items.forEach((_, i) => setOn(i, true, false))
      return
    }
    gsap.set(path, { strokeDasharray: len, strokeDashoffset: len })
    const draw = { p: 0 }
    gsap.to(draw, {
      p: 1,
      ease: 'none',
      onUpdate() {
        path.style.strokeDashoffset = String(len * (1 - draw.p))
        at.forEach((a, i) => setOn(i, draw.p >= a - 0.004, true))
      },
      scrollTrigger: {
        trigger: ol,
        start: () => `top+=${geo.y0} 64%`,
        end: () => `top+=${geo.y1} 64%`,
        scrub: 0.5,
        invalidateOnRefresh: true,
      },
    })
    ScrollTrigger.refresh()
  }, { scope: root, dependencies: [geo] })

  const fee = settings?.shippingFeeMainland ?? 15000
  const free = settings?.freeShippingThreshold ?? 150000

  return (
    <section id="how" ref={root} className="relative mx-auto max-w-[88rem] px-4 py-16 sm:px-8 sm:py-32 lg:px-12">
      <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
        {/* Left: sticky on desktop */}
        <div className="lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <SplitReveal as="h2" text={t('how.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-[1] text-plum" />
            <Reveal delay={0.1}>
              <p className="mt-5 max-w-[28rem] text-[1.05rem] leading-[1.6] text-foreground/80">{t('how.body')}</p>
            </Reveal>
            <Reveal delay={0.18} y={20} className="mt-7">
              <a href={wa} target="_blank" rel="noopener noreferrer"
                className="group press inline-flex h-[52px] items-center gap-2.5 rounded-full pl-5 pr-6 text-[0.98rem] font-medium text-white shadow-2 hover:brightness-110"
                style={{ backgroundColor: WA_GREEN }}>
                <MessageCircle aria-hidden className="h-5 w-5 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-rotate-12" />
                {t('how.wa')}
              </a>
            </Reveal>
            <div className="mt-9">
              <Reveal y={10}><p className="text-[0.92rem] font-medium text-muted-foreground">{t('how.payWith')}</p></Reveal>
              <Stagger as="ul" className="mt-3 flex flex-wrap gap-2">
                {PAYMENTS.map((p) => (
                  <StaggerItem as="li" key={p}>
                    <span className="inline-flex h-9 items-center rounded-full bg-surface px-3.5 text-[0.86rem] font-medium text-plum shadow-1">
                      {p.startsWith('how.') ? t(p) : p}
                    </span>
                  </StaggerItem>
                ))}
              </Stagger>
            </div>
          </div>
        </div>

        {/* Right: the drawn path */}
        <div className="lg:col-span-7">
          <ol ref={list} className="relative flex flex-col gap-6 sm:gap-8">
            {geo && (
              <svg aria-hidden className="pointer-events-none absolute left-0 top-0 overflow-visible" width={geo.w} height={geo.h} viewBox={`0 0 ${geo.w} ${geo.h}`}>
                <path d={geo.d} fill="none" stroke="var(--plum)" strokeOpacity={0.14} strokeWidth={2} strokeDasharray="2 7" strokeLinecap="round" />
                <path data-draw d={geo.d} fill="none" stroke="var(--plum)" strokeWidth={2.5} strokeLinecap="round" />
                <path data-probe d="" fill="none" stroke="none" />
              </svg>
            )}
            {[1, 2, 3, 4].map((n, i) => (
              <li key={n} data-step data-on="false"
                className={cn('group relative ml-6 sm:ml-7 lg:w-[80%]', i % 2 ? 'lg:ml-auto lg:mr-0' : 'lg:ml-7')}>
                <Reveal y={28} className="relative">
                  <div className="relative rounded-[28px] bg-surface py-6 pl-10 pr-6 shadow-2 transition-shadow duration-300 group-data-[on=true]:shadow-3 sm:py-7 sm:pl-12 sm:pr-8">
                    <span data-node
                      className="absolute -left-6 top-6 grid h-12 w-12 place-items-center rounded-full bg-surface font-display text-[1.35rem] text-plum/50 shadow-1 ring-1 ring-plum/10 transition-colors duration-300 group-data-[on=true]:bg-plum group-data-[on=true]:text-porcelain sm:-left-7 sm:h-14 sm:w-14 sm:text-[1.5rem]">
                      {n}
                    </span>
                    <h3 className="font-display text-[clamp(1.3rem,1.7vw,1.6rem)] leading-[1.12] text-plum">{t(`how.${n}.t`)}</h3>
                    <p className="mt-2 max-w-[30rem] text-[1rem] leading-[1.55] text-muted-foreground">{t(`how.${n}.d`)}</p>
                    <div className="mt-5"><StepToy n={n} /></div>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </div>

      {/* Delivery options */}
      <div className="mt-20 sm:mt-28">
        <SplitReveal as="h3" text={t('how.del.title')} className="font-display text-[clamp(1.7rem,2.6vw,2.4rem)] leading-[1.05] text-plum" />
        <Stagger className="mt-8 grid gap-4 sm:gap-5 md:grid-cols-2 lg:grid-cols-4">
          <StaggerItem>
            <DeliveryCard tone="powder" icon={<Truck className="h-5 w-5" />} title={t('how.del.local.t')} body={t('how.del.local.d')} chips={[t('how.del.local.chip')]} />
          </StaggerItem>
          <StaggerItem>
            <DeliveryCard tone="white" icon={<Store className="h-5 w-5" />} title={t('how.del.pickup.t')} body={t('how.del.pickup.d')} chips={[t('how.del.pickup.chip')]} />
          </StaggerItem>
          <StaggerItem className="md:col-span-2">
            <DeliveryCard tone="lagoon" wide icon={<Ship className="h-6 w-6" />} title={t('how.del.ferry.t')}
              body={settings?.ferryInfo || t('how.del.ferry.d')}
              chips={[t('how.del.ferry.fee', { fee: money(fee) }), t('how.del.ferry.free', { amount: money(free) })]} />
          </StaggerItem>
        </Stagger>
      </div>
    </section>
  )
}

function DeliveryCard({ tone, icon, title, body, chips, wide = false }: { tone: 'powder' | 'white' | 'lagoon'; icon: React.ReactNode; title: string; body: string; chips: string[]; wide?: boolean }) {
  const bg = tone === 'powder' ? 'bg-[var(--powder-a)]' : tone === 'lagoon' ? 'bg-[var(--tea-a)]' : 'bg-surface shadow-2'
  const iconBg = tone === 'lagoon' ? 'bg-lagoon-deep text-white' : tone === 'powder' ? 'bg-surface text-coral' : 'bg-shell text-plum'
  return (
    <div className={cn('flex h-full flex-col rounded-[28px] p-6 sm:p-7', bg, wide && 'lg:flex-row lg:items-start lg:gap-7')}>
      <span aria-hidden className={cn('grid shrink-0 place-items-center rounded-full', wide ? 'h-14 w-14' : 'h-12 w-12', iconBg)}>{icon}</span>
      <div className={cn('flex flex-1 flex-col', wide ? 'mt-5 lg:mt-0' : 'mt-5')}>
        <h4 className={cn('font-display leading-[1.1] text-plum', wide ? 'text-[1.6rem]' : 'text-[1.35rem]')}>{title}</h4>
        <p className="mt-2 text-[1rem] leading-[1.55] text-foreground/75">{body}</p>
        <div className="mt-auto flex flex-wrap gap-2 pt-5">
          {chips.map((c, i) => (
            <span key={c} className={cn('inline-flex h-9 items-center rounded-full px-3.5 text-[0.86rem] font-medium tabular',
              tone === 'lagoon' && i === 0 ? 'bg-lagoon-deep text-white' : 'bg-surface text-plum shadow-1')}>{c}</span>
          ))}
        </div>
      </div>
    </div>
  )
}

// Small, real pieces of the shop's UI, one per step. They wake when the
// drawn line reaches their node (group-data-[on=true]).
function StepToy({ n }: { n: number }) {
  const { t } = useI18n()
  const ease = 'ease-[cubic-bezier(.22,1,.36,1)]'
  if (n === 1) {
    return (
      <div className="flex flex-wrap items-center gap-2">
        {[{ img: '/products/powder-pouch.webp', k: 'how.chip.powder' }, { img: '/products/tea-pouch.webp', k: 'how.chip.tea' }].map((p) => (
          <span key={p.k} className="inline-flex h-10 items-center gap-2 rounded-full bg-shell py-1 pl-1 pr-3.5 text-[0.86rem] font-medium text-plum">
            <span className="relative h-8 w-8 overflow-hidden rounded-full bg-surface"><Image src={p.img} alt="" fill sizes="32px" className="object-contain p-1" /></span>
            {t(p.k)}
          </span>
        ))}
        <span className={cn('inline-flex h-10 items-center gap-1.5 rounded-full bg-lagoon-deep px-3.5 text-[0.86rem] font-medium text-white',
          'translate-y-1 scale-90 opacity-0 transition-[transform,opacity] duration-300 group-data-[on=true]:translate-y-0 group-data-[on=true]:scale-100 group-data-[on=true]:opacity-100', ease)}>
          <Check aria-hidden className="h-4 w-4" />{t('how.chip.added')}
        </span>
      </div>
    )
  }
  if (n === 2) {
    // The choice pill slides across to "Delivery", like the checkout's own.
    return (
      <div className="relative inline-grid grid-cols-3 rounded-full bg-shell p-1">
        <span aria-hidden className={cn('absolute bottom-1 left-1 top-1 w-[calc((100%-0.5rem)/3)] translate-x-[200%] rounded-full bg-surface shadow-1 transition-transform duration-500 group-data-[on=true]:translate-x-0', ease)} />
        {['how.chip.local', 'how.chip.pickup', 'how.chip.ferry'].map((k, i) => (
          <span key={k} className={cn('relative z-[1] inline-flex h-9 items-center justify-center px-3.5 text-[0.86rem] font-medium transition-colors duration-300',
            i === 0 ? 'text-muted-foreground group-data-[on=true]:text-plum' : i === 2 ? 'text-plum group-data-[on=true]:text-muted-foreground' : 'text-muted-foreground')}>{t(k)}</span>
        ))}
      </div>
    )
  }
  if (n === 3) {
    return (
      <div className={cn('max-w-[22rem] origin-bottom-left translate-y-2 opacity-40 transition-[transform,opacity] duration-500 group-data-[on=true]:translate-y-0 group-data-[on=true]:opacity-100', ease)}>
        <div className="rounded-[18px] rounded-bl-[6px] bg-[var(--wa-bubble)] px-4 py-3 text-[0.92rem] leading-[1.45] text-[var(--wa-ink)]">
          {t('how.bubble')}
          <span className="mt-1.5 flex items-center justify-end gap-1 text-[0.78rem] text-[var(--wa-ink)]/70">
            {t('how.bubbleMeta')}<CheckCheck aria-hidden className="h-3.5 w-3.5" style={{ color: WA_GREEN }} />
          </span>
        </div>
      </div>
    )
  }
  return (
    <ol className="flex flex-wrap items-center gap-1.5" aria-label={t('how.4.t')}>
      {['how.st.confirmed', 'how.st.shipped', 'how.st.delivered'].map((k, i) => (
        <li key={k} className="flex items-center gap-1.5">
          <span className={cn('inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-[0.86rem] font-medium transition-colors duration-300',
            'bg-shell text-muted-foreground', i === 0 && 'group-data-[on=true]:bg-plum group-data-[on=true]:text-porcelain', i === 1 && 'group-data-[on=true]:bg-plum/85 group-data-[on=true]:text-porcelain group-data-[on=true]:delay-150')}>
            {i < 2 && <Check aria-hidden className="h-3.5 w-3.5" />}{t(k)}
          </span>
          {i < 2 && <span aria-hidden className="h-px w-3 bg-plum/25" />}
        </li>
      ))}
    </ol>
  )
}
