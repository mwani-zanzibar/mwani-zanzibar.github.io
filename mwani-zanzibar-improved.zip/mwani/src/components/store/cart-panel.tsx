'use client'

import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, motion, useAnimationControls, useReducedMotion } from 'framer-motion'
import { Drawer } from 'vaul'
import { ArrowRight, ArrowUpRight, Check, Minus, Plus, ShoppingBag, Truck, X } from 'lucide-react'
import type { ApiSettings } from '@/lib/api'
import { useCart, type CartItem } from '@/lib/cart-store'
import { useUI } from '@/lib/ui-store'
import { registerCartTarget } from '@/lib/cart-fx'
import { getTier } from '@/lib/perf'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { NumberRoll } from '@/components/motion/number-roll'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { useIsDesktop } from '@/components/store/overlay-shell'
import { EASE_OUT, SPRING_POP, SPRING_SNAPPY, SPRING_SOFT } from '@/components/shared/reveal'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'
import { BubbleBurst } from '@/components/motion/effects'

const useIsoLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect
// Literal (not a CSS var) so framer can scale-correct it during the morph.
const SHADOW_3 = '0 4px 10px rgb(31 7 14 / 0.06), 0 30px 60px -24px rgb(31 7 14 / 0.36)'
const MORPH = { type: 'spring', stiffness: 300, damping: 34, mass: 0.9 } as const

const countOf = (items: CartItem[]) => items.reduce((n, i) => n + i.qty, 0)
const totalOf = (items: CartItem[]) => items.reduce((n, i) => n + i.price * i.qty, 0)

export function CartPanel({ settings }: { settings: ApiSettings | null }) {
  const desktop = useIsDesktop()
  // The store persists `open`; a reload should never land with the bag open.
  useEffect(() => { useCart.getState().setOpen(false) }, [])
  return desktop ? <DesktopBag settings={settings} /> : <MobileBag settings={settings} />
}

/* ─────────────────────────────── Desktop: pill ⇄ panel ─────────────────────────────── */

function DesktopBag({ settings }: { settings: ApiSettings | null }) {
  const { t } = useI18n()
  const money = useMoney()
  const items = useCart((s) => s.items)
  const open = useCart((s) => s.open)
  const setOpen = useCart((s) => s.setOpen)
  const count = countOf(items)
  const total = totalOf(items)
  const show = open || count > 0
  const wrapRef = useRef<HTMLDivElement>(null)
  const pillRef = useRef<HTMLButtonElement>(null)
  const lastFocus = useRef<HTMLElement | null>(null)
  const pending = usePendingThumbs(items)

  // The fixed wrapper is the fly-to-cart target. It never carries a framer
  // transform, so its box is the pill's resting box even while the pill is
  // still springing in for the first item.
  useIsoLayoutEffect(() => {
    if (open || !wrapRef.current) return
    return registerCartTarget(wrapRef.current, 3)
  }, [open])

  // Focus in on open, back out on close, Esc closes.
  const wasOpen = useRef(false)
  useEffect(() => {
    if (open && !wasOpen.current) {
      lastFocus.current = document.activeElement as HTMLElement | null
    } else if (!open && wasOpen.current) {
      const back = lastFocus.current
      requestAnimationFrame(() => (pillRef.current ?? back)?.focus?.({ preventScroll: true }))
    }
    wasOpen.current = open
    if (!open) return
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open, setOpen])

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div
            key="scrim"
            aria-hidden
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-[68] bg-night/20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.26 } }}
            transition={{ duration: 0.3 }}
          />
        )}
      </AnimatePresence>

      <motion.div ref={wrapRef} layoutRoot className="fixed bottom-6 right-6 z-[70] flex flex-col items-end [&_:focus-visible]:outline-on-night">
        <AnimatePresence>
          {show && (
            <motion.div
              key="cart-shell"
              layout
              initial={{ opacity: 0, y: 40, scale: 0.9, borderRadius: 32 }}
              animate={{ opacity: 1, y: 0, scale: 1, borderRadius: open ? 28 : 32 }}
              exit={{ opacity: 0, y: 28, scale: 0.94, transition: { duration: 0.26, ease: EASE_OUT } }}
              transition={{ ...SPRING_SOFT, opacity: { duration: 0.25, ease: EASE_OUT }, layout: MORPH, borderRadius: MORPH }}
              style={{ boxShadow: SHADOW_3, transformOrigin: '100% 100%' }}
              className="overflow-hidden bg-night text-on-night"
            >
              <AnimatePresence mode="popLayout" initial={false}>
                {open ? (
                  <motion.div
                    key="panel"
                    layout
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="bag-title"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.06, duration: 0.22 } }}
                    exit={{ opacity: 0, transition: { duration: 0.1 } }}
                    onKeyDown={trapTab}
                    className="flex max-h-[min(78vh,760px)] w-[400px] flex-col"
                  >
                    <BagBody settings={settings} variant="panel" onClose={() => setOpen(false)} titleId="bag-title" />
                  </motion.div>
                ) : (
                  <motion.button
                    key="pill"
                    ref={pillRef}
                    layout
                    type="button"
                    onClick={() => setOpen(true)}
                    aria-haspopup="dialog"
                    aria-expanded={false}
                    aria-label={t('cart.openAria', { count: count === 1 ? t('cart.oneItem') : t('cart.nItems', { n: count }), total: money(total) })}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1, transition: { delay: 0.12, duration: 0.22 } }}
                    exit={{ opacity: 0, transition: { duration: 0.08 } }}
                    className="group flex h-16 items-center gap-3 pl-3 pr-3 text-left"
                  >
                    <Thumbs items={items} pending={pending} />
                    <span className="flex flex-col gap-1 pr-1 leading-none">
                      <span className="text-[0.95rem] font-semibold">{t('cart.viewBag')}</span>
                      <span className="flex items-center gap-1.5 text-[0.84rem] text-on-night/65">
                        <span className="whitespace-nowrap">{count === 1 ? t('cart.oneItem') : t('cart.nItems', { n: count })}</span>
                        <span aria-hidden>·</span>
                        <NumberRoll value={money(total)} />
                      </span>
                    </span>
                    <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-on-night text-night transition-colors duration-200 group-hover:bg-white">
                      <ArrowUpRight className="h-[18px] w-[18px] transition-transform duration-200 ease-out group-hover:-translate-y-0.5 group-hover:translate-x-0.5" strokeWidth={2.2} aria-hidden />
                    </span>
                  </motion.button>
                )}
              </AnimatePresence>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </>
  )
}

// Stacked thumbnails, newest on the left. A new item's slot opens straight
// away (so the flying image has somewhere to land) and its photo drops in when
// the flight lands ('cart:landed').
function Thumbs({ items, pending }: { items: CartItem[]; pending: string[] }) {
  const controls = useAnimationControls()
  const reduce = useReducedMotion()
  useEffect(() => {
    if (reduce) return
    const on = () => { controls.start({ scale: [1, 1.12, 0.97, 1], transition: { duration: 0.45, ease: EASE_OUT } }) }
    window.addEventListener('cart:landed', on)
    return () => window.removeEventListener('cart:landed', on)
  }, [controls, reduce])
  const shown = [...items].reverse().slice(0, 3)
  return (
    <motion.span animate={controls} className="flex items-center" aria-hidden>
      <AnimatePresence mode="popLayout" initial={false}>
        {shown.map((it, i) => {
          const waiting = pending.includes(it.productId)
          return (
            <motion.span
              key={it.productId}
              layout
              initial={{ x: -18, opacity: 0, scale: 0.7 }}
              animate={{ x: 0, opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.7, transition: { duration: 0.18 } }}
              transition={{ ...SPRING_SNAPPY, layout: SPRING_SNAPPY }}
              style={{ zIndex: 3 - i }}
              className={cn(
                'relative grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-full ring-2 ring-night transition-colors duration-300',
                i > 0 && '-ml-3',
                waiting ? 'bg-white/10' : 'bg-white',
              )}
            >
              <motion.span
                className="absolute inset-0"
                initial={false}
                animate={waiting ? { opacity: 0, scale: 0.4 } : { opacity: 1, scale: 1 }}
                transition={waiting ? { duration: 0 } : SPRING_POP}
              >
                <Image src={it.image} alt="" fill sizes="40px" className={fit(it.image, 'sm')} />
              </motion.span>
              {waiting && <span className="absolute inset-[5px] rounded-full border border-dashed border-on-night/40" />}
            </motion.span>
          )
        })}
      </AnimatePresence>
    </motion.span>
  )
}

// Product ids whose flying image hasn't landed yet.
function usePendingThumbs(items: CartItem[]) {
  const [pending, setPending] = useState<string[]>([])
  const prev = useRef<string[] | null>(null)
  const timers = useRef<number[]>([])
  useIsoLayoutEffect(() => {
    const ids = items.map((i) => i.productId)
    const before = prev.current
    prev.current = ids
    if (!before || getTier() === 0) return
    const fresh = ids.filter((id) => !before.includes(id))
    if (!fresh.length) return
    setPending((p) => [...p, ...fresh])
    // Fallback if nothing flies (e.g. added from somewhere without an image).
    timers.current.push(window.setTimeout(() => setPending((p) => p.filter((id) => !fresh.includes(id))), 1500))
  }, [items])
  useEffect(() => {
    const on = () => setPending((p) => p.slice(1))
    window.addEventListener('cart:landed', on)
    const ts = timers.current
    return () => { window.removeEventListener('cart:landed', on); ts.forEach(clearTimeout) }
  }, [])
  return pending
}

function trapTab(e: React.KeyboardEvent<HTMLElement>) {
  if (e.key !== 'Tab') return
  const f = [...e.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input, [tabindex]:not([tabindex="-1"])')]
  if (!f.length) return
  const first = f[0], last = f[f.length - 1]
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus() }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus() }
}

/* ─────────────────────────────── Phones: bottom sheet ─────────────────────────────── */

function MobileBag({ settings }: { settings: ApiSettings | null }) {
  const { t } = useI18n()
  const open = useCart((s) => s.open)
  const setOpen = useCart((s) => s.setOpen)
  return (
    <Drawer.Root open={open} onOpenChange={setOpen} shouldScaleBackground={false}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-[80] bg-night/45 backdrop-blur-[6px]" />
        <Drawer.Content
          data-lenis-prevent
          className="fixed inset-x-0 bottom-0 z-[81] flex max-h-[90svh] flex-col rounded-t-[28px] bg-night text-on-night outline-none [&_:focus-visible]:outline-on-night"
          style={{ boxShadow: SHADOW_3 }}
        >
          <div className="mx-auto mt-3 h-1.5 w-11 shrink-0 rounded-full bg-on-night/25" aria-hidden />
          <Drawer.Description className="sr-only">{t('cart.sheetDesc')}</Drawer.Description>
          <BagBody settings={settings} variant="sheet" onClose={() => setOpen(false)} />
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  )
}

/* ─────────────────────────────── Shared body ─────────────────────────────── */

function BagBody({ settings, variant, onClose, titleId }: {
  settings: ApiSettings | null; variant: 'panel' | 'sheet'; onClose: () => void; titleId?: string
}) {
  const { t } = useI18n()
  const money = useMoney()
  const items = useCart((s) => s.items)
  const count = countOf(items)
  const total = totalOf(items)
  const sheet = variant === 'sheet'
  const closeRef = useRef<HTMLButtonElement>(null)
  const autoId = useId()
  const hid = titleId ?? autoId

  useEffect(() => {
    if (sheet) return
    const id = requestAnimationFrame(() => closeRef.current?.focus({ preventScroll: true }))
    return () => cancelAnimationFrame(id)
  }, [sheet])

  const checkout = () => {
    useCart.getState().setOpen(false)
    // Let the phone sheet leave before the checkout sheet arrives.
    if (sheet) window.setTimeout(() => useUI.getState().setCheckoutOpen(true), 320)
    else useUI.getState().setCheckoutOpen(true)
  }
  const browse = () => {
    onClose()
    window.setTimeout(() => scrollToId('shop'), sheet ? 380 : 60)
  }

  const Title = sheet ? Drawer.Title : 'h2'
  return (
    <>
      <div className={cn('flex shrink-0 items-center gap-3', sheet ? 'px-5 pb-3 pt-3' : 'px-5 pb-3 pt-5')}>
        <span className="grid h-10 w-10 place-items-center rounded-full bg-white/10" aria-hidden>
          <ShoppingBag className="h-[18px] w-[18px]" strokeWidth={2} />
        </span>
        <Title id={hid} className="font-display text-[1.55rem] leading-none text-on-night">{t('cart.bag')}</Title>
        <AnimatePresence initial={false}>
          {count > 0 && (
            <motion.span
              key="count"
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.6 }}
              transition={SPRING_POP}
              className="grid h-7 min-w-7 place-items-center rounded-full bg-on-night px-2 text-[0.8rem] font-semibold text-night"
            >
              <NumberRoll value={String(count)} />
            </motion.span>
          )}
        </AnimatePresence>
        <button
          ref={closeRef}
          type="button"
          onClick={onClose}
          aria-label={t('cart.close')}
          className="press ml-auto grid h-11 w-11 place-items-center rounded-full bg-white/10 text-on-night hover:bg-white/[0.16]"
        >
          <X className="h-[18px] w-[18px]" strokeWidth={2.2} aria-hidden />
        </button>
      </div>

      {items.length === 0 ? (
        <EmptyBag onBrowse={browse} sheet={sheet} />
      ) : (
        <>
          <motion.ul
            layoutScroll
            data-lenis-prevent
            className="relative min-h-0 flex-1 space-y-2 overflow-y-auto overscroll-contain px-3 pb-1 pt-1 [scrollbar-color:rgb(255_255_255/0.18)_transparent] [scrollbar-width:thin]"
          >
            <AnimatePresence initial={true} mode="popLayout">
              {items.map((it, i) => <BagRow key={it.productId} item={it} index={i} />)}
            </AnimatePresence>
          </motion.ul>

          <div className={cn('shrink-0 px-3 pt-2', sheet ? 'pb-[max(16px,env(safe-area-inset-bottom))]' : 'pb-4')}>
            <ShipProgress subtotal={total} settings={settings} />
            <div className="mt-4 flex items-baseline justify-between px-2">
              <span className="text-[0.95rem] text-on-night/70">{t('cart.subtotalLabel')}</span>
              <NumberRoll value={money(total)} className="text-[1.4rem] font-semibold" />
            </div>
            <p className="mt-1.5 px-2 text-[0.8rem] text-on-night/50">{t('cart.payNote')}</p>
            <button
              type="button"
              onClick={checkout}
              className="press group mt-4 flex h-14 w-full items-center justify-center gap-2 rounded-full bg-on-night text-[1rem] font-semibold text-night hover:bg-white"
            >
              {t('cart.goCheckout')}
              <ArrowRight className="h-[18px] w-[18px] transition-transform duration-200 ease-out group-hover:translate-x-1" strokeWidth={2.2} aria-hidden />
            </button>
            <button type="button" onClick={onClose} className="mt-1 h-11 w-full text-[0.92rem] font-medium text-on-night/70 transition-colors duration-150 hover:text-on-night">
              {t('cart.keepShopping')}
            </button>
          </div>
        </>
      )}
    </>
  )
}

function BagRow({ item: it, index, ref }: { item: CartItem; index: number; ref?: React.Ref<HTMLLIElement> }) {
  const { t } = useI18n()
  const money = useMoney()
  const reduce = useReducedMotion()
  const blur = !reduce && getTier() >= 2
  const atMax = it.stock > 0 && it.qty >= it.stock
  const setQty = useCart((s) => s.setQty)
  const remove = useCart((s) => s.remove)
  return (
    <motion.li
      ref={ref}
      layout
      initial={reduce ? false : { opacity: 0, y: 12, filter: blur ? 'blur(6px)' : 'blur(0px)' }}
      animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      exit={{ opacity: 0, x: 28, transition: { duration: 0.2, ease: EASE_OUT } }}
      transition={{ duration: 0.5, ease: EASE_OUT, delay: 0.16 + Math.min(index, 6) * 0.05, layout: SPRING_SNAPPY }}
      className="flex gap-3 rounded-2xl bg-white/[0.06] p-2.5"
    >
      <span className="relative h-[52px] w-[52px] shrink-0 overflow-hidden rounded-xl bg-white">
        <Image src={it.image} alt="" fill sizes="52px" className={fit(it.image, 'sm')} />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-start gap-2">
          <div className="min-w-0 flex-1 pt-0.5">
            <p className="truncate text-[0.95rem] font-semibold leading-tight text-on-night">{it.name}</p>
            <p className="mt-1 truncate text-[0.82rem] text-on-night/55">{it.unit} · {t('cart.each', { price: money(it.price) })}</p>
          </div>
          <button
            type="button"
            onClick={() => remove(it.productId)}
            aria-label={t('cart.remove', { name: it.name })}
            className="press -mr-1 -mt-1 grid h-9 w-9 shrink-0 place-items-center rounded-full text-on-night/55 after:absolute after:-inset-1 after:content-[''] hover:bg-white/10 hover:text-on-night relative"
          >
            <X className="h-4 w-4" strokeWidth={2.2} aria-hidden />
          </button>
        </div>
        <div className="mt-2 flex items-center justify-between gap-2">
          <NumberRoll value={money(it.price * it.qty)} className="text-[0.98rem] font-semibold" />
          <div className="flex h-11 items-center rounded-full bg-white/[0.08]" role="group" aria-label={t('cart.qty', { name: it.name })}>
            <button
              type="button"
              onClick={() => setQty(it.productId, it.qty - 1)}
              aria-label={t('cart.dec', { name: it.name })}
              className="press grid h-11 w-11 place-items-center rounded-full text-on-night/80 hover:bg-white/10 hover:text-on-night"
            >
              <Minus className="h-4 w-4" strokeWidth={2.4} aria-hidden />
            </button>
            <NumberRoll value={String(it.qty)} className="min-w-5 justify-center text-[0.95rem] font-semibold" />
            <button
              type="button"
              onClick={() => setQty(it.productId, it.qty + 1)}
              disabled={atMax}
              aria-label={t('cart.inc', { name: it.name })}
              className="press grid h-11 w-11 place-items-center rounded-full text-on-night/80 hover:bg-white/10 hover:text-on-night disabled:opacity-35 disabled:hover:bg-transparent"
            >
              <Plus className="h-4 w-4" strokeWidth={2.4} aria-hidden />
            </button>
          </div>
        </div>
      </div>
    </motion.li>
  )
}

function ShipProgress({ subtotal, settings }: { subtotal: number; settings: ApiSettings | null }) {
  const { t } = useI18n()
  const money = useMoney()
  const threshold = settings?.freeShippingThreshold || 150000
  const fee = settings?.shippingFeeMainland ?? 0
  const left = Math.max(0, threshold - subtotal)
  const done = left === 0
  const pct = Math.min(1, subtotal / threshold)
  const [before, after] = t('cart.shipMore').split('{amount}')
  const first = useRef(true)
  useEffect(() => { first.current = false }, [])
  // Unlocking free shipping gets a little celebration.
  const [party, setParty] = useState(0)
  const was = useRef(done)
  useEffect(() => { if (done && !was.current) setParty((n) => n + 1); was.current = done }, [done])
  return (
    <div className="relative rounded-2xl bg-white/[0.06] p-3.5">
      <BubbleBurst fire={party} count={16} spread={90} className="[&>span]:bottom-2" />
      <div className="flex items-center gap-2.5">
        <span className="relative grid h-7 w-7 shrink-0 place-items-center" aria-hidden>
          <AnimatePresence initial={false}>
            {done ? (
              <motion.span
                key="ok"
                initial={{ scale: 0.4, opacity: 0, rotate: -30 }}
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                exit={{ scale: 0.4, opacity: 0 }}
                transition={SPRING_POP}
                className="absolute inset-0 grid place-items-center rounded-full bg-lagoon text-night"
              >
                <Check className="h-4 w-4" strokeWidth={3} />
              </motion.span>
            ) : (
              <motion.span key="truck" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 grid place-items-center rounded-full bg-white/10">
                <Truck className="h-4 w-4 text-on-night/80" strokeWidth={2} />
              </motion.span>
            )}
          </AnimatePresence>
        </span>
        <p className="text-[0.9rem] leading-snug text-on-night" aria-live="polite">
          {done ? t('cart.shipFree') : (
            <>
              {before}
              <NumberRoll value={money(left)} className="font-semibold align-[-0.12em]" />
              {after}
            </>
          )}
        </p>
      </div>
      <div
        className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10"
        role="progressbar"
        aria-label={t('cart.progress')}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Math.round(pct * 100)}
      >
        {/* Fill slides in (transform only) so its rounded end stays round. */}
        <motion.div
          className="h-full w-full rounded-full bg-lagoon"
          initial={{ x: '-100%' }}
          animate={{ x: `${(pct - 1) * 100}%` }}
          transition={{ type: 'spring', stiffness: 120, damping: 20, delay: first.current ? 0.3 : 0 }}
        />
      </div>
      <div className="mt-3 flex items-center justify-between gap-3 text-[0.8rem]">
        <span className="text-on-night/55">{t('cart.shipLine')}</span>
        {fee > 0 && (
          <span className="flex items-center gap-1.5 tabular">
            <span className={cn('transition-colors duration-300', done ? 'text-on-night/40 line-through' : 'text-on-night/75')}>{money(fee)}</span>
            <AnimatePresence initial={false}>
              {done && (
                <motion.span key="free" initial={{ opacity: 0, x: -4 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} className="font-semibold text-lagoon">
                  {t('cart.free')}
                </motion.span>
              )}
            </AnimatePresence>
          </span>
        )}
      </div>
      <p className="mt-1 text-[0.8rem] text-on-night/55">{t('cart.zanzibarNote')}</p>
    </div>
  )
}

function EmptyBag({ onBrowse, sheet }: { onBrowse: () => void; sheet: boolean }) {
  const { t } = useI18n()
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1, ease: EASE_OUT }}
      className={cn('flex flex-col items-center px-8 pt-6 text-center', sheet ? 'pb-[max(28px,env(safe-area-inset-bottom))]' : 'pb-8')}
    >
      <span className="grid h-24 w-24 place-items-center rounded-full bg-white/[0.06]">
        <Image src="/brand/mwani-mark-light.png" alt="" width={56} height={56} className="h-14 w-14 object-contain" />
      </span>
      <p className="mt-5 font-display text-[1.6rem] leading-tight text-on-night">{t('cart.emptyHead')}</p>
      <p className="mt-2 max-w-[16rem] text-[0.95rem] text-on-night/60">{t('cart.emptyText')}</p>
      <button
        type="button"
        onClick={onBrowse}
        className="press group mt-6 flex h-12 items-center gap-2 rounded-full bg-on-night px-6 text-[0.95rem] font-semibold text-night hover:bg-white"
      >
        {t('cart.browse')}
        <ArrowRight className="h-4 w-4 transition-transform duration-200 ease-out group-hover:translate-x-1" strokeWidth={2.2} aria-hidden />
      </button>
    </motion.div>
  )
}
