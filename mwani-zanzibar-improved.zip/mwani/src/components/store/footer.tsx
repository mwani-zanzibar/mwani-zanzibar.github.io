'use client'

import { useRef } from 'react'
import Image from 'next/image'
import { ArrowUpRight } from 'lucide-react'
import type { ApiSettings } from '@/lib/api'
import { gsap, useGSAP } from '@/lib/gsap'
import { reducedMotion } from '@/lib/perf'
import { whatsappLink } from '@/lib/format'
import { useI18n } from '@/lib/i18n'
import { useUI } from '@/lib/ui-store'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { Reveal, Stagger, StaggerItem } from '@/components/shared/reveal'
import { useImg } from '@/lib/content-store'

const WORD = 'Mwani'

// Continues the night slab that the closing call to action starts. The giant
// wordmark's letters rise out of the floor as it scrolls into view.
export function SiteFooter({ settings, onCatalog }: { settings: ApiSettings | null; onCatalog?: () => void }) {
  const footerLogo = useImg('brand.footer', '/brand/mwani-lockup-light.png')
  const { t } = useI18n()
  const s = settings
  const root = useRef<HTMLElement>(null)

  useGSAP(() => {
    if (reducedMotion()) return
    gsap.fromTo('[data-letter]', { yPercent: 108, rotate: 6 }, {
      yPercent: 0, rotate: 0, ease: 'none', stagger: 0.12, transformOrigin: '0% 100%',
      scrollTrigger: { trigger: '[data-wordmark]', start: 'top bottom', end: 'bottom bottom', scrub: 0.6 },
    })
  }, { scope: root })

  const link = 'link-draw inline-flex min-h-11 items-center text-left text-[1rem] text-on-night/75 transition-colors duration-200 hover:text-on-night'
  const jump = (id: string) => (e: React.MouseEvent) => { e.preventDefault(); scrollToId(id) }
  const heading = 'text-[0.92rem] font-medium text-rose'

  return (
    <footer id="contact" ref={root} className="px-3 pb-3">
      <div className="relative overflow-hidden rounded-b-[32px] bg-night text-on-night sm:rounded-b-[40px]">
        <div className="mx-auto max-w-[88rem] px-5 sm:px-10 lg:px-14">
          <div className="grid gap-12 border-t border-on-night/10 pt-14 sm:pt-16 lg:grid-cols-12 lg:gap-8">
            <Reveal className="lg:col-span-4">
              <Image src={footerLogo} alt="Mwani Zanzibar Seaweed" width={907} height={666} className="h-auto w-[168px]" />
              <p className="mt-5 max-w-[20rem] text-[1rem] leading-[1.6] text-on-night/70">{s?.tagline || t('foot.tagline')}</p>
            </Reveal>

            <Stagger className="grid grid-cols-2 gap-x-6 gap-y-10 sm:grid-cols-3 lg:col-span-8">
              <StaggerItem>
                <nav aria-label={t('foot.shop')}>
                  <h3 className={heading}>{t('foot.shop')}</h3>
                  <ul className="mt-3">
                    <li><a className={link} href="#duo" onClick={jump('duo')}>{t('foot.duo')}</a></li>
                    <li><a className={link} href="#ranges" onClick={jump('ranges')}>{t('foot.ranges')}</a></li>
                    <li><a className={link} href="#shop" onClick={jump('shop')}>{t('foot.all')}</a></li>
                    <li><a className={link} href="#story" onClick={jump('story')}>{t('foot.story')}</a></li>
                    <li><a className={link} href="#recipes" onClick={jump('recipes')}>{t('foot.recipes')}</a></li>
                    {onCatalog && <li><button type="button" className={link} onClick={onCatalog}>{t('foot.catalog')}</button></li>}
                  </ul>
                </nav>
              </StaggerItem>
              <StaggerItem>
                <nav aria-label={t('foot.help')}>
                  <h3 className={heading}>{t('foot.help')}</h3>
                  <ul className="mt-3">
                    <li><a className={link} href="#how" onClick={jump('how')}>{t('foot.how')}</a></li>
                    <li><button type="button" className={link} onClick={() => useUI.getState().openTrack()}>{t('foot.track')}</button></li>
                    <li><button type="button" className={link} onClick={() => useUI.getState().setMyOrdersOpen(true)}>{t('foot.orders')}</button></li>
                    <li><a className={link} href="#faq" onClick={jump('faq')}>{t('foot.faq')}</a></li>
                  </ul>
                </nav>
              </StaggerItem>
              <StaggerItem className="col-span-2 sm:col-span-1">
                <h3 className={heading}>{t('foot.contact')}</h3>
                <address className="mt-3 not-italic">
                  <ul>
                    {s?.whatsappPrimary && (
                      <li><a className={link} href={whatsappLink(s.whatsappPrimary, t('foot.waMsg'))} target="_blank" rel="noopener noreferrer">
                        {t('foot.wa', { phone: s.phonePrimary || s.whatsappPrimary })}
                      </a></li>
                    )}
                    {s?.email && <li><a className={`${link} break-all`} href={`mailto:${s.email}`}>{s.email}</a></li>}
                    {s?.instagram && (
                      <li><a className={`${link} gap-1`} href={`https://instagram.com/${s.instagram.replace(/^@/, '')}`} target="_blank" rel="noopener noreferrer">
                        <span className="min-w-0">@{s.instagram.replace(/^@/, '').replace(/_/g, '_\u200B')}</span><ArrowUpRight aria-hidden className="h-4 w-4 shrink-0" />
                      </a></li>
                    )}
                    {s?.address && <li className="mt-2 max-w-[16rem] text-[0.95rem] leading-[1.55] text-on-night/55">{s.address}</li>}
                  </ul>
                </address>
              </StaggerItem>
            </Stagger>
          </div>

          <p data-wordmark aria-hidden
            className="font-logo mt-14 select-none overflow-clip pb-[0.04em] text-center text-[clamp(6rem,22vw,20rem)] leading-[0.82] tracking-[-0.02em] text-rose sm:mt-20">
            {WORD.split('').map((c, i) => (
              <span key={i} data-letter className="inline-block will-change-transform">{c}</span>
            ))}
          </p>

          <div className="flex flex-col gap-2 border-t border-on-night/10 pb-8 pt-5 text-[0.9rem] text-on-night/55 sm:flex-row sm:items-center sm:justify-between lg:pb-6">
            <p>{t('foot.rights', { year: new Date().getFullYear() })}</p>
            <a className="link-draw inline-flex min-h-11 items-center self-start text-on-night/70 hover:text-on-night sm:self-auto" href="?admin=1">{t('foot.staff')}</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
