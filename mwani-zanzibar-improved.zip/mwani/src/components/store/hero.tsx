'use client'

import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, motion, useMotionValue, useReducedMotion, useScroll, useSpring, useTransform } from 'framer-motion'
import { ArrowRight, Check, Minus, Plus, MessageCircle, CookingPot, Leaf, PlayCircle } from 'lucide-react'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { useCart } from '@/lib/cart-store'
import { flyToCart } from '@/lib/cart-fx'
import { whatsappLink } from '@/lib/format'
import { isTouch } from '@/lib/perf'
import { pickHeroes, useHeroImages, type HeroKey } from '@/lib/hero-products'
import { SplitReveal } from '@/components/motion/split-reveal'
import { NumberRoll } from '@/components/motion/number-roll'
import { scrollToId } from '@/components/motion/smooth-scroll'
import { EASE_OUT, SPRING_SNAPPY } from '@/components/shared/reveal'
import { BubbleBurst, Magnetic } from '@/components/motion/effects'
import type { ApiProduct, ApiSettings } from '@/lib/api'
import { useImg } from '@/lib/content-store'

const THEME: Record<HeroKey, string> = {
  powder: 'radial-gradient(110% 85% at 78% 30%, var(--powder-hi) 0%, var(--powder-a) 38%, var(--powder-b) 100%)',
  tea: 'radial-gradient(110% 85% at 78% 30%, var(--tea-hi) 0%, var(--tea-a) 38%, var(--tea-b) 100%)',
}

const clean = (s: string) => s.replace(/\s*\(.*?\)\s*/g, '').replace(/^100% (organic )?/i, '').replace(/^organic /i, '')

export function Hero({ settings, products }: { settings: ApiSettings | null; products: ApiProduct[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const reduce = useReducedMotion()
  const add = useCart((s) => s.add)
  const heroes = pickHeroes(products)
  const { cut: HERO_CUT, pouch: HERO_POUCH } = useHeroImages()
  const coopLogo = useImg('brand.coop', '/wakulima-hai-logo.png')
  const [key, setKey] = useState<HeroKey>('powder')
  const [qty, setQty] = useState(1)
  const [switches, setSwitches] = useState(0)
  const [added, setAdded] = useState(false)
  const root = useRef<HTMLElement>(null)
  const stage = useRef<HTMLDivElement>(null)
  const p = heroes[key]
  const dir = key === 'tea' ? 1 : -1

  useEffect(() => { setQty(1) }, [key])

  // Scroll: copy drifts up, the product sinks a little as the hero leaves.
  const { scrollYProgress } = useScroll({ target: root, offset: ['start start', 'end start'] })
  const productY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 70])
  const textY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -60])
  const discScale = useTransform(scrollYProgress, [0, 1], [1, reduce ? 1 : 1.25])

  // Pointer: a little depth on the product and the floating cards (mouse only).
  const mx = useMotionValue(0), my = useMotionValue(0)
  const sx = useSpring(mx, { stiffness: 120, damping: 18 }), sy = useSpring(my, { stiffness: 120, damping: 18 })
  const cardA = { x: useTransform(sx, (v) => v * -14), y: useTransform(sy, (v) => v * 10) }
  const cardB = { x: useTransform(sx, (v) => v * 18), y: useTransform(sy, (v) => v * -12) }
  const poster = { x: useTransform(sx, (v) => v * 10), y: useTransform(sy, (v) => v * 6) }
  const onMove = (e: React.PointerEvent) => {
    if (e.pointerType !== 'mouse' && isTouch()) return
    const r = root.current!.getBoundingClientRect()
    const x = ((e.clientX - r.left) / r.width) * 2 - 1, y = 1 - ((e.clientY - r.top) / r.height) * 2
    mx.set(x); my.set(-y)
  }

  const onAdd = () => {
    if (!p || p.stock <= 0) return
    add({ productId: p.id, name: p.name, price: p.price, unit: p.unit, image: p.image, stock: p.stock }, qty)
    flyToCart(stage.current)
    setAdded(true)
    setTimeout(() => setAdded(false), 1600)
  }

  const wa = whatsappLink(settings?.whatsappPrimary || '+255774870703', 'Habari! Nina swali kuhusu bidhaa za Mwani Zanzibar.')
  const chips = (p?.ingredients || []).map(clean).filter((c) => c && c.length <= 22).slice(0, 4)
  const intro = (d: number) => ({ initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 }, transition: { delay: d, duration: 0.7, ease: EASE_OUT } })

  return (
    <section id="top" ref={root} onPointerMove={onMove} className="relative px-2 pt-2 sm:px-3 sm:pt-3">
      <div className="relative overflow-hidden rounded-[30px] sm:rounded-[40px]">
        {(['powder', 'tea'] as HeroKey[]).map((k) => (
          <motion.div key={k} aria-hidden className="absolute inset-0" style={{ background: THEME[k] }}
            initial={false} animate={{ opacity: key === k ? 1 : 0 }} transition={{ duration: 0.8, ease: EASE_OUT }} />
        ))}

        <div className="relative mx-auto grid max-w-[88rem] gap-4 px-5 pb-32 pt-24 sm:px-10 sm:pb-36 sm:pt-28 lg:grid-cols-12 lg:gap-6 lg:px-14 lg:pb-32 lg:pt-24">
          {/* Copy */}
          <motion.div style={{ y: textY }} className="relative z-10 lg:col-span-6 lg:pt-6">
            <motion.div {...intro(0.05)} role="tablist" aria-label={t('hx.switch')} className="inline-flex rounded-full bg-surface/70 p-1 shadow-1">
              {(['powder', 'tea'] as HeroKey[]).map((k) => (
                <button key={k} role="tab" aria-selected={key === k} onClick={() => { if (k !== key) { setKey(k); setSwitches((n) => n + 1) } }}
                  className={`relative flex h-11 items-center gap-2 rounded-full pl-1.5 pr-5 text-[0.95rem] font-semibold transition-colors duration-200 ${key === k ? 'text-porcelain' : 'text-plum/70 hover:text-plum'}`}>
                  {key === k && <motion.span layoutId="hero-switch" className="absolute inset-0 rounded-full bg-plum" transition={SPRING_SNAPPY} />}
                  <span className="relative grid h-8 w-8 place-items-center overflow-hidden rounded-full bg-surface">
                    <Image src={HERO_POUCH[k]} alt="" width={24} height={32} className="h-7 w-auto object-contain" />
                  </span>
                  <span className="relative">{t(`hx.${k}`)}</span>
                </button>
              ))}
            </motion.div>

            <h1 className="mt-7 text-plum" aria-label={`${t(`hx.${key}.l1`)} ${t(`hx.${key}.l2`)}`}>
              <SplitReveal as="span" immediate delay={0.12} text={t(`hx.${key}.l1`)} className="font-display block text-[clamp(2.75rem,5.6vw,5.4rem)] leading-[0.95]" />
              <SplitReveal as="span" immediate delay={0.3} text={t(`hx.${key}.l2`)} className="font-display-italic block text-[clamp(2.75rem,5.6vw,5.4rem)] leading-[1.02]" />
            </h1>

            <AnimatePresence mode="wait" initial={false}>
              <motion.p key={key} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0, transition: { delay: 0.15, duration: 0.5, ease: EASE_OUT } }} exit={{ opacity: 0, y: -6, transition: { duration: 0.18 } }}
                className="mt-6 max-w-[30rem] text-[1.06rem] leading-relaxed text-foreground/80">
                {t(`hx.${key}.body`)}
              </motion.p>
            </AnimatePresence>

            <motion.div {...intro(0.6)} className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-4">
              <Magnetic>
              <motion.button whileTap={{ scale: 0.97 }} onClick={() => scrollToId('shop')}
                className="group inline-flex h-14 items-center gap-3 rounded-full bg-plum pl-7 pr-2 text-[1rem] font-semibold text-porcelain shadow-2 transition-colors duration-200 hover:bg-plum-2">
                {t('hx.shopAll')}
                <span className="grid h-10 w-10 place-items-center overflow-hidden rounded-full bg-white/15">
                  <span className="relative block h-4 w-4 overflow-hidden">
                    <ArrowRight className="absolute inset-0 h-4 w-4 transition-transform duration-300 ease-out group-hover:translate-x-5" aria-hidden />
                    <ArrowRight className="absolute inset-0 h-4 w-4 -translate-x-5 transition-transform duration-300 ease-out group-hover:translate-x-0" aria-hidden />
                  </span>
                </span>
              </motion.button>
              </Magnetic>
              <button onClick={() => scrollToId('story')} className="group inline-flex items-center gap-2.5 text-[0.98rem] font-semibold text-plum">
                <PlayCircle className="h-9 w-9 stroke-[1.4] transition-transform duration-300 ease-out group-hover:scale-110" aria-hidden />
                <span className="link-draw">{t('hx.how')}</span>
              </button>
            </motion.div>

            <motion.div {...intro(0.75)} className="mt-8 hidden items-center gap-3 sm:flex">
              <span className="relative h-11 w-11 overflow-hidden rounded-full bg-surface shadow-1">
                <Image src={coopLogo} alt="" fill sizes="44px" className="object-contain p-1" />
              </span>
              <p className="max-w-[16rem] text-sm leading-snug text-foreground/75">{t('hx.coop')}</p>
            </motion.div>
          </motion.div>

          {/* Stage */}
          <div className="relative lg:col-span-6">
            <div className="relative mx-auto h-[380px] max-w-[34rem] sm:h-[500px] lg:h-[560px]">
              <motion.div aria-hidden style={{ scale: discScale }} className="absolute left-1/2 top-1/2 aspect-square w-[92%] -translate-x-1/2 -translate-y-1/2">
                <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1.1, ease: EASE_OUT }}
                  className="absolute inset-0 rounded-full bg-surface/45" />
                <div className="absolute -inset-[9%] rounded-full border border-[var(--hairline)]" />
                <div className="absolute -inset-[20%] rounded-full border border-[var(--hairline)] opacity-60" />
              </motion.div>

              {/* The product: real photography with the background removed. Switching
                  slides one scene out and the next in, in the direction of the tab. */}
              <motion.div style={{ y: productY }} className="absolute inset-x-0 bottom-[6%] top-[24%] sm:top-[12%]">
                <div aria-hidden className="absolute -bottom-[3%] left-1/2 h-[14%] w-[78%] -translate-x-1/2 rounded-[50%] bg-[radial-gradient(closest-side,rgba(31,7,14,0.26),rgba(31,7,14,0))]" />
                <motion.div ref={stage} style={reduce ? undefined : poster} className="absolute inset-0">
                  <BubbleBurst fire={switches} count={14} />
                  <AnimatePresence initial={false} mode="popLayout" custom={dir}>
                    <motion.div key={key} custom={dir} className="absolute inset-0"
                      variants={{
                        enter: (d: number) => ({ opacity: 0, x: reduce ? 0 : 90 * d, scale: reduce ? 1 : 0.94 }),
                        center: { opacity: 1, x: 0, scale: 1 },
                        exit: (d: number) => ({ opacity: 0, x: reduce ? 0 : -90 * d, scale: reduce ? 1 : 0.94 }),
                      }}
                      initial="enter" animate="center" exit="exit" transition={{ duration: 0.6, ease: EASE_OUT }}>
                      <motion.div className="absolute inset-0" initial={{ y: 36, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.15, duration: 0.9, ease: EASE_OUT }}>
                        <Image src={HERO_CUT[key]} alt={p?.name || ''} fill priority sizes="(max-width: 640px) 92vw, (max-width: 1024px) 70vw, 560px"
                          className="object-contain object-bottom drop-shadow-[0_22px_26px_rgba(31,7,14,0.22)]" />
                      </motion.div>
                    </motion.div>
                  </AnimatePresence>
                </motion.div>
              </motion.div>

              {/* Floating facts */}
              {p && (
                <>
                  <motion.div style={reduce ? undefined : cardA} initial={{ opacity: 0, scale: 0.9, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ delay: 0.85, duration: 0.6, ease: EASE_OUT }}
                    className="absolute -left-1 top-[1%] z-10 w-[9.75rem] rounded-[20px] bg-surface p-3 shadow-3 sm:left-0 sm:top-[12%] sm:w-[13rem] sm:p-3.5 lg:-left-4">
                    <div className="flex items-center gap-2.5">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-shell text-plum"><CookingPot className="h-4 w-4" aria-hidden /></span>
                      <span className="text-xs font-semibold text-muted-foreground">{t('hx.use')}</span>
                    </div>
                    <AnimatePresence mode="wait" initial={false}>
                      <motion.p key={key} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.22 }} className="mt-2 text-[0.9rem] font-semibold leading-snug text-plum">
                        {t(`hx.${key}.use`)}
                      </motion.p>
                    </AnimatePresence>
                  </motion.div>

                  <motion.div style={reduce ? undefined : cardB} initial={{ opacity: 0, scale: 0.9, y: 16 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ delay: 1, duration: 0.6, ease: EASE_OUT }}
                    className="absolute bottom-[14%] right-0 z-10 hidden w-[14.5rem] rounded-[22px] bg-surface p-3.5 shadow-3 sm:block lg:-right-2">
                    <div className="flex items-center gap-2.5">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-shell text-plum"><Leaf className="h-4 w-4" aria-hidden /></span>
                      <span className="text-xs font-semibold text-muted-foreground">{t('hx.inside')}</span>
                    </div>
                    <AnimatePresence mode="wait" initial={false}>
                      <motion.ul key={key} className="mt-2.5 flex flex-wrap gap-1.5" initial="h" animate="s" exit="h" variants={{ h: {}, s: { transition: { staggerChildren: 0.05 } } }}>
                        {chips.map((c) => (
                          <motion.li key={c} variants={{ h: { opacity: 0, scale: 0.9 }, s: { opacity: 1, scale: 1 } }} className="rounded-full bg-shell px-2.5 py-1 text-xs font-medium text-plum">{c}</motion.li>
                        ))}
                      </motion.ul>
                    </AnimatePresence>
                  </motion.div>

                  <motion.div initial={{ opacity: 0, scale: 0.9, rotate: -6 }} animate={{ opacity: 1, scale: 1, rotate: 4 }} transition={{ delay: 1.1, duration: 0.6, ease: EASE_OUT }}
                    className="absolute right-[4%] top-[5%] z-10 rounded-[18px] bg-plum px-3.5 py-2.5 text-porcelain shadow-3">
                    <p className="text-[0.72rem] opacity-75">{p.unit}</p>
                    <NumberRoll value={money(p.price)} className="text-[1.05rem] font-semibold" />
                  </motion.div>
                </>
              )}

            </div>
          </div>
        </div>
      </div>

      {/* Order dock: overlaps the bottom edge of the hero (Travorra) */}
      {p && (
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7, duration: 0.8, ease: EASE_OUT }}
          className="relative z-20 mx-auto -mt-24 max-w-[70rem] px-3 sm:-mt-20 sm:px-6">
          <div className="grid grid-cols-[auto_1fr] items-center gap-x-3 gap-y-3 rounded-[28px] bg-surface p-3 shadow-3 md:flex md:gap-2 md:rounded-full md:p-2.5">
            <div className="flex min-w-0 items-center gap-3 md:flex-1 md:pl-1">
              <span className="relative grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full bg-shell">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span key={key} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -30, opacity: 0 }} transition={{ duration: 0.3, ease: EASE_OUT }} className="absolute inset-0 grid place-items-center">
                    <Image src={HERO_POUCH[key]} alt="" width={30} height={40} className="h-10 w-auto object-contain" />
                  </motion.span>
                </AnimatePresence>
              </span>
              <div className="min-w-0 flex-1">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.p key={key} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.2 }} className="truncate font-semibold text-plum"><span className="md:hidden">{t(`duo.${key}.name`)}</span><span className="hidden md:inline">{p.name}</span></motion.p>
                </AnimatePresence>
                <p className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="whitespace-nowrap">{p.unit}</span><span aria-hidden className="hidden h-1 w-1 rounded-full bg-foreground/25 sm:block" />
                  <span className="hidden items-center gap-1.5 whitespace-nowrap text-lagoon-deep sm:inline-flex"><span className="h-1.5 w-1.5 rounded-full bg-lagoon-deep" />{t('hx.inStock')}</span>
                </p>
              </div>
            </div>
            {/* Phones: the running total sits on the first row so the button stays roomy. */}
            <div className="pr-1 text-right md:hidden">
              <p className="text-xs text-muted-foreground">{t('hx.total')}</p>
              <NumberRoll value={money(p.price * qty)} className="text-[1.05rem] font-semibold text-plum" />
            </div>

            <div className="col-span-2 flex items-center gap-2 md:contents">
              <div className="flex h-12 shrink-0 items-center rounded-full bg-shell p-1 md:h-14" role="group" aria-label={t('hx.qty')}>
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} disabled={qty <= 1} aria-label="−" className="press grid h-10 w-10 place-items-center md:h-12 md:w-12 rounded-full text-plum hover:bg-surface disabled:opacity-35"><Minus className="h-4 w-4" /></button>
                <NumberRoll value={String(qty)} className="w-7 justify-center text-[1.05rem] font-semibold text-plum" />
                <button onClick={() => setQty((q) => Math.min(p.stock || 99, q + 1))} aria-label="+" className="press grid h-10 w-10 place-items-center md:h-12 md:w-12 rounded-full text-plum hover:bg-surface"><Plus className="h-4 w-4" /></button>
              </div>
              <div className="hidden px-4 text-right lg:block">
                <p className="text-xs text-muted-foreground">{t('hx.total')}</p>
                <NumberRoll value={money(p.price * qty)} className="text-[1.15rem] font-semibold text-plum" />
              </div>
              <motion.button layout whileTap={{ scale: 0.97 }} onClick={onAdd} transition={SPRING_SNAPPY}
                className={`relative flex h-12 min-w-0 flex-1 items-center justify-center gap-2 overflow-hidden whitespace-nowrap rounded-full px-4 text-[1rem] font-semibold text-porcelain md:h-14 md:flex-none md:px-7 ${added ? 'bg-lagoon-deep' : 'bg-plum hover:bg-plum-2'} transition-colors duration-200`}>
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span key={added ? 'y' : 'n'} initial={{ y: 22, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -22, opacity: 0 }} transition={{ duration: 0.22, ease: EASE_OUT }} className="flex items-center gap-2">
                    {added ? <Check className="h-5 w-5" aria-hidden /> : <Plus className="h-5 w-5" aria-hidden />}
                    {added ? t('hx.added') : <>{t('hx.add')}<span className="hidden opacity-60 md:inline lg:hidden">·</span><span className="hidden md:inline lg:hidden"><NumberRoll value={money(p.price * qty)} /></span></>}
                  </motion.span>
                </AnimatePresence>
              </motion.button>
              <a href={wa} target="_blank" rel="noopener noreferrer" aria-label={t('hx.askWa')}
                className="press grid h-12 w-12 shrink-0 place-items-center rounded-full bg-[#1f8a5a] md:h-14 md:w-14 text-white hover:bg-[#197349]">
                <MessageCircle className="h-5 w-5" aria-hidden />
              </a>
            </div>
          </div>
        </motion.div>
      )}
    </section>
  )
}
