'use client'

import { useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, motion } from 'framer-motion'
import { Plus, Check } from 'lucide-react'
import { useMoney } from '@/lib/use-money'
import { useCart } from '@/lib/cart-store'
import { useI18n } from '@/lib/i18n'
import { showCartNotification } from '@/components/store/cart-notification'
import type { ApiProduct } from '@/lib/api'

export function ProductCard({ product, onSelect, priority = false }: { product: ApiProduct; onSelect: (p: ApiProduct) => void; priority?: boolean }) {
  const add = useCart((s) => s.add)
  const money = useMoney()
  const { t } = useI18n()
  const [added, setAdded] = useState(false)
  const out = product.stock <= 0
  const low = !out && product.stock <= product.lowStockThreshold
  const alt = product.gallery?.[0]

  const onAdd = () => {
    if (out) return
    add({ productId: product.id, name: product.name, price: product.price, unit: product.unit, image: product.image, stock: product.stock })
    showCartNotification({ id: product.id, name: product.name, price: product.price, image: product.image, unit: product.unit })
    setAdded(true); setTimeout(() => setAdded(false), 1600)
  }

  return (
    <article className="group">
      <div className="relative aspect-[4/5] overflow-hidden rounded-[18px] bg-blush">
        <button onClick={() => onSelect(product)} className="absolute inset-0" aria-label={product.name}>
          <Image src={product.image} alt="" fill priority={priority} sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className={`object-cover transition-[transform,opacity] duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.04] ${alt ? '[@media(hover:hover)]:group-hover:opacity-0' : ''} ${out ? 'opacity-50 grayscale' : ''}`} />
          {alt && <Image src={alt} alt="" fill sizes="(max-width: 1024px) 33vw, 25vw" className="hidden scale-[1.04] object-cover opacity-0 transition-[transform,opacity] duration-700 ease-[cubic-bezier(.22,1,.36,1)] [@media(hover:hover)]:block group-hover:scale-100 group-hover:opacity-100" />}
        </button>
        {(out || low) && (
          <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-background/92 px-2.5 py-1 text-[0.78rem] font-medium text-foreground">
            {out ? t('shop.out') : t('shop.left', { n: product.stock })}
          </span>
        )}
        {/* Quick add: slides up on hover (mouse), always-available button on touch */}
        {!out && (
          <>
            <div className="absolute inset-x-3 bottom-3 hidden translate-y-[calc(100%+12px)] transition-transform duration-300 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-y-0 group-focus-within:translate-y-0 [@media(hover:hover)]:block">
              <motion.button whileTap={{ scale: 0.98 }} onClick={onAdd} className="flex h-11 w-full items-center justify-center gap-2 rounded-full bg-background/95 text-[0.9rem] font-medium text-brand backdrop-blur">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span key={added ? 'a' : 'b'} initial={{ y: 10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -10, opacity: 0 }} transition={{ duration: 0.2 }} className="inline-flex items-center gap-2">
                    {added ? <Check className="h-4 w-4" aria-hidden /> : <Plus className="h-4 w-4" aria-hidden />}
                    {added ? t('shop.added') : t('shop.addToBag')}
                  </motion.span>
                </AnimatePresence>
              </motion.button>
            </div>
            <motion.button whileTap={{ scale: 0.92 }} onClick={onAdd} aria-label={`${t('shop.addToBag')}: ${product.name}`}
              className="absolute bottom-2.5 right-2.5 grid h-10 w-10 place-items-center rounded-full bg-background/95 text-brand shadow-sm [@media(hover:hover)]:hidden">
              <AnimatePresence mode="popLayout" initial={false}>
                <motion.span key={added ? 'a' : 'b'} initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }} transition={{ duration: 0.18 }}>
                  {added ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                </motion.span>
              </AnimatePresence>
            </motion.button>
          </>
        )}
      </div>
      <button onClick={() => onSelect(product)} className="mt-3.5 flex w-full flex-col gap-1 text-left sm:flex-row sm:items-start sm:justify-between sm:gap-3">
        <span className="min-w-0">
          <span className="block text-[0.98rem] font-medium leading-snug text-foreground">{product.name}</span>
          <span className="mt-0.5 block text-[0.88rem] text-muted-foreground">{product.unit}</span>
        </span>
        <span className="order-last whitespace-nowrap text-[0.95rem] tabular-nums text-foreground sm:order-none sm:shrink-0">{money(product.price)}</span>
      </button>
    </article>
  )
}
