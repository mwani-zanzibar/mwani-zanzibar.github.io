'use client'

import { useCallback, useEffect, useState } from 'react'
import { toast } from 'sonner'
import { api, isDemo, type ApiProduct, type ApiSettings } from '@/lib/api'
import { useCurrency } from '@/lib/currency-store'
import { useCart } from '@/lib/cart-store'
import { useWishlist } from '@/lib/wishlist-store'
import { useUI } from '@/lib/ui-store'
import { I18nProvider, useI18n } from '@/lib/i18n'
import { openCatalog } from '@/lib/catalog'
import { SmoothScroll, scrollToId } from '@/components/motion/smooth-scroll'
import { Navbar } from '@/components/store/navbar'
import { Hero } from '@/components/store/hero'
import { DuoSection } from '@/components/store/duo-section'
import { RangesSection } from '@/components/store/ranges-section'
import { ProductsSection } from '@/components/store/products-section'
import { StorySection } from '@/components/store/story-section'
import { RecipesSection } from '@/components/store/recipes-section'
import { HowItWorks } from '@/components/store/how-it-works'
import { TestimonialsSection } from '@/components/store/testimonials'
import { FaqSection } from '@/components/store/faq-section'
import { ClosingCta } from '@/components/store/closing-cta'
import { SiteFooter } from '@/components/store/footer'
import { CartPanel } from '@/components/store/cart-panel'
import { ProductModal } from '@/components/store/product-modal'
import { SearchOverlay } from '@/components/store/search-overlay'
import { WishlistDrawer } from '@/components/store/wishlist-drawer'
import { NavPanel } from '@/components/store/side-nav'
import { CheckoutDialog } from '@/components/store/checkout-dialog'
import { TrackDialog } from '@/components/store/track-dialog'
import { MyOrdersDialog } from '@/components/store/my-orders-dialog'
import { ScrollTopRing } from '@/components/motion/effects'
import { useContent } from '@/lib/content-store'

export function Storefront() {
  const { t } = useI18n()
  const [products, setProducts] = useState<ApiProduct[]>([])
  const [settings, setSettings] = useState<ApiSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState('')
  const [category, setCategory] = useState('all')
  const setRate = useCurrency((s) => s.setRate)

  const load = useCallback(async () => {
    try {
      const [p, s] = await Promise.all([api.products(), api.settings()])
      setProducts(p.products)
      setSettings(s.settings)
      useContent.getState().setContent(s.settings.content)
      if (s.settings.usdRate) setRate(s.settings.usdRate)
      useCart.getState().sync(p.products) // keep saved bags honest: current prices and stock
      useWishlist.getState().sync(p.products)
      setLoadError('')
    } catch (e) {
      console.error(e)
      setLoadError('The shop could not load. Check your connection and reload the page.')
    } finally {
      setLoading(false)
    }
  }, [setRate])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    // Handy for testing overlays from the console / Playwright.
    ;(window as unknown as Record<string, unknown>).__mwani = { ui: useUI, cart: useCart, wishlist: useWishlist }
  }, [])

  useEffect(() => {
    if (!isDemo) return
    try { if (sessionStorage.getItem('mwani-demo-note')) return; sessionStorage.setItem('mwani-demo-note', '1') } catch { /* ignore */ }
    const id = setTimeout(() => toast(t('demo.banner'), { duration: 5000, position: 'bottom-center' }), 2600)
    return () => clearTimeout(id)
  }, [t])

  const pickCategory = (c: string) => { setCategory(c); setTimeout(() => scrollToId('shop'), 30) }

  return (
    <div className="relative flex min-h-screen flex-col">
      <SmoothScroll />
      <Navbar settings={settings} />
      <main className="flex-1">
        <Hero settings={settings} products={products} />
        {loadError && <p role="alert" className="mx-auto mt-8 max-w-7xl px-5 text-destructive">{loadError}</p>}
        {/* The full shop comes straight after the hero: one short scroll to every product. */}
        <ProductsSection products={products} loading={loading} category={category} setCategory={setCategory} />
        <DuoSection products={products} />
        <RangesSection products={products} onPick={pickCategory} />
        <StorySection settings={settings} />
        <RecipesSection />
        <HowItWorks settings={settings} />
        <TestimonialsSection />
        <FaqSection settings={settings} />
        <ClosingCta settings={settings} />
      </main>
      <SiteFooter settings={settings} onCatalog={() => openCatalog(products, settings)} />

      <CartPanel settings={settings} />
      <ScrollTopRing label={t('nav.top')} />
      <ProductModal allProducts={products} />
      <SearchOverlay products={products} />
      <WishlistDrawer products={products} />
      <NavPanel settings={settings} />
      <CheckoutDialog settings={settings} onDone={() => load()} />
      <TrackDialog />
      <MyOrdersDialog />
    </div>
  )
}

export function StorefrontWithI18n() {
  return (
    <I18nProvider>
      <Storefront />
    </I18nProvider>
  )
}
