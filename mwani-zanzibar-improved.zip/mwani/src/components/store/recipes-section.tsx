'use client'

import { Fragment, useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { ArrowRight, Clock, Users } from 'lucide-react'
import { api, type ApiRecipe } from '@/lib/api'
import { gsap, ScrollTrigger, useGSAP } from '@/lib/gsap'
import { reducedMotion } from '@/lib/perf'
import { useI18n } from '@/lib/i18n'
import { Reveal, SplitReveal, Stagger, StaggerItem } from '@/components/shared/reveal'
import { RecipeModal } from './recipe-modal'

export { RecipeModal } from './recipe-modal'

const STICK_TOP = 96 // px from the top of the viewport where the stack sits
const STICK_STEP = 16 // each later card sits this much lower, so the deck shows

// Recipes are dealt onto a stack: each card sticks, and the one arriving over
// it pushes it back (scale 0.93, slightly dimmed). Featured recipes first.
export function RecipesSection() {
  const { t, lang } = useI18n()
  const [recipes, setRecipes] = useState<ApiRecipe[]>([])
  const [selected, setSelected] = useState<ApiRecipe | null>(null)
  const root = useRef<HTMLElement>(null)

  useEffect(() => {
    let live = true
    api.recipes()
      .then((d) => { if (live) setRecipes([...d.recipes].sort((a, b) => Number(b.featured) - Number(a.featured))) })
      .catch(() => { if (live) setRecipes([]) })
    return () => { live = false }
  }, [])

  const top = recipes.slice(0, 4)
  const rest = recipes.slice(4)

  useGSAP(() => {
    if (!top.length) return
    // The section just grew; everything below it has moved.
    ScrollTrigger.refresh()
    if (reducedMotion()) return
    const cards = gsap.utils.toArray<HTMLElement>('[data-stack-card]')
    const marks = gsap.utils.toArray<HTMLElement>('[data-stack-mark]')
    cards.forEach((card, i) => {
      const nextMark = marks[i + 1]
      if (!nextMark) return
      const st = {
        trigger: nextMark, // un-stuck flow position of the next card
        start: 'top bottom',
        end: () => `top ${STICK_TOP + (i + 1) * STICK_STEP}px`,
        scrub: true,
        invalidateOnRefresh: true,
      }
      gsap.fromTo(card, { scale: 1 }, { scale: 0.93, ease: 'none', scrollTrigger: st })
      const shade = card.querySelector('[data-shade]')
      if (shade) gsap.fromTo(shade, { opacity: 0 }, { opacity: 1, ease: 'none', scrollTrigger: { ...st } })
    })
  }, { scope: root, dependencies: [top.length, lang] })

  if (recipes.length === 0) return null

  return (
    <section id="recipes" ref={root} className="relative pb-16 pt-16 sm:pb-32 sm:pt-32">
      <div className="mx-auto max-w-[88rem] px-4 sm:px-8 lg:px-12">
        <div className="grid gap-5 lg:grid-cols-12 lg:items-end">
          <SplitReveal as="h2" text={t('rec.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-[1] text-plum lg:col-span-7" />
          <Reveal delay={0.12} className="lg:col-span-4 lg:col-start-9 lg:pb-2">
            <p className="max-w-[26rem] text-[1.05rem] leading-[1.6] text-foreground/75">{t('rec.body')}</p>
          </Reveal>
        </div>

        <div className="relative mt-10 sm:mt-14">
          {top.map((r, i) => (
            <Fragment key={r.id}>
              <div data-stack-mark aria-hidden className="h-0" />
              <div className="sticky mb-[7vh] last:mb-0" style={{ top: `calc(${STICK_TOP}px + ${i * STICK_STEP}px)` }}>
                <RecipeCard recipe={r} onOpen={() => setSelected(r)} priority={i === 0} />
              </div>
            </Fragment>
          ))}
        </div>

        {rest.length > 0 && (
          <div className="mt-12 flex flex-col gap-4 sm:mt-16 sm:flex-row sm:items-center">
            <Reveal y={10}><p className="shrink-0 text-[0.95rem] font-medium text-muted-foreground">{t('rec.more')}</p></Reveal>
            <Stagger as="ul" className="flex flex-wrap gap-2.5">
              {rest.map((r) => (
                <StaggerItem as="li" key={r.id}>
                  <button type="button" onClick={() => setSelected(r)}
                    className="group press flex min-h-11 items-center gap-2.5 rounded-full bg-surface py-1.5 pl-1.5 pr-4 text-left text-[0.92rem] font-medium text-plum shadow-1 hover:-translate-y-0.5 hover:shadow-2">
                    <span className="relative h-8 w-8 shrink-0 overflow-hidden rounded-full bg-shell">
                      <Image src={r.image} alt="" fill sizes="32px" className="object-cover" />
                    </span>
                    <span>{r.title}</span>
                    <ArrowRight aria-hidden className="h-4 w-4 -translate-x-1 opacity-0 transition-[transform,opacity] duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-0 group-hover:opacity-100" />
                  </button>
                </StaggerItem>
              ))}
            </Stagger>
          </div>
        )}
      </div>

      <RecipeModal recipe={selected} onClose={() => setSelected(null)} />
    </section>
  )
}

function RecipeCard({ recipe: r, onOpen, priority }: { recipe: ApiRecipe; onOpen: () => void; priority: boolean }) {
  const { t } = useI18n()
  const catKey = `rec.cat.${r.category}`
  const cat = t(catKey) === catKey ? r.category : t(catKey)
  return (
    <article data-stack-card
      className="relative origin-top overflow-hidden rounded-[30px] bg-surface shadow-3 will-change-transform sm:rounded-[36px] lg:grid lg:h-[min(540px,calc(100svh-150px))] lg:grid-cols-[1.05fr_1fr]">
      <div className="p-2 sm:p-2.5 lg:h-full">
        <button type="button" onClick={onOpen} tabIndex={-1} aria-hidden
          className="group relative block aspect-[16/11] w-full overflow-hidden rounded-[24px] bg-shell sm:rounded-[28px] lg:aspect-auto lg:h-full">
          <Image src={r.image} alt="" fill priority={priority} sizes="(min-width: 1024px) 45vw, 100vw"
            className="object-cover transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.04]" />
        </button>
      </div>
      <div className="flex flex-col justify-center px-5 pb-6 pt-3 sm:px-8 sm:pb-8 lg:px-12 lg:py-10">
        <div className="flex flex-wrap gap-2">
          {r.category && <span className="inline-flex h-9 items-center rounded-full bg-plum px-3.5 text-[0.84rem] font-medium text-porcelain">{cat}</span>}
          {r.prepTime && (
            <span className="inline-flex h-9 items-center gap-1.5 rounded-full bg-shell px-3.5 text-[0.84rem] font-medium text-plum">
              <Clock aria-hidden className="h-3.5 w-3.5" /><span className="sr-only">{t('rec.prep')}: </span>{r.prepTime}
            </span>
          )}
          {r.servings && (
            <span className="inline-flex h-9 items-center gap-1.5 rounded-full bg-shell px-3.5 text-[0.84rem] font-medium text-plum">
              <Users aria-hidden className="h-3.5 w-3.5" /><span className="sr-only">{t('rec.serves')}: </span>{r.servings}
            </span>
          )}
        </div>
        <h3 className="font-display mt-5 text-[clamp(1.75rem,3vw,2.9rem)] leading-[1.04] text-plum lg:mt-7">{r.title}</h3>
        <p className="mt-3 max-w-[30rem] text-[1.02rem] leading-[1.55] text-foreground/75 lg:mt-4 lg:text-[1.08rem]">{r.excerpt}</p>
        {(r.ingredients.length > 0 || r.steps.length > 0) && (
          <p className="mt-3 text-[0.92rem] text-muted-foreground">{t('rec.meta', { i: r.ingredients.length, s: r.steps.length })}</p>
        )}
        <div className="mt-6 lg:mt-9">
          <button type="button" onClick={onOpen}
            className="group press inline-flex h-12 items-center gap-2.5 rounded-full bg-plum pl-6 pr-5 text-[0.98rem] font-medium text-porcelain hover:bg-plum-2 sm:h-[52px]">
            {t('rec.see')}
            <ArrowRight aria-hidden className="h-4 w-4 transition-transform duration-200 ease-[cubic-bezier(.22,1,.36,1)] group-hover:translate-x-1" />
          </button>
        </div>
      </div>
      <div data-shade aria-hidden className="pointer-events-none absolute inset-0 bg-night/[0.14] opacity-0" />
    </article>
  )
}
