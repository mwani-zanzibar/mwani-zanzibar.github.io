'use client'

import { useEffect, useState } from 'react'
import { Share2, Loader2 } from 'lucide-react'
import { api, type ApiProduct, type ApiSettings } from '@/lib/api'
import { formatTZS, whatsappLink } from '@/lib/format'
import { toast } from 'sonner'

export function ShareButton({ product }: { product: ApiProduct }) {
  const [settings, setSettings] = useState<ApiSettings | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    api.settings().then((d) => setSettings(d.settings)).catch(() => {})
  }, [])

  const waNumber = settings?.whatsappPrimary || '+255774870703'
  const url = typeof window !== 'undefined' ? window.location.origin : ''
  const message = `Habari! Nina nia ya kupata bidhaa hii:\n\n• ${product.name} (${product.unit}) — ${formatTZS(product.price)}\n\n${product.tagline}\n\nTazama kwenye tovuti: ${url}/#products\n\nNingeplenda maelezo zaidi. Asante!`

  const copyLink = () => {
    navigator.clipboard?.writeText(`${url}/#products`).then(() => {
      setCopied(true)
      toast.success('Product link copied')
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className="flex items-center gap-1.5">
      <a
        href={whatsappLink(waNumber, message)}
        target="_blank"
        rel="noreferrer"
        className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-[#25D366] text-white shadow-soft hover:brightness-105 active:scale-95 transition"
        aria-label="Share to WhatsApp"
        title="Ask about this on WhatsApp"
      >
        <Share2 className="h-4 w-4" />
      </a>
      <button
        onClick={copyLink}
        className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-border/70 bg-background hover:bg-accent/40 active:scale-95 transition"
        aria-label="Copy product link"
        title="Copy product link"
      >
        {copied ? <span className="text-[10px] font-bold text-leaf">✓</span> : <Share2 className="h-4 w-4 text-muted-foreground" />}
      </button>
    </div>
  )
}
