'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import Image from 'next/image'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { Check, ChevronLeft, ChevronRight, Heart, Loader2, MapPin, Minus, Plus, ShoppingBag, Star, Sprout } from 'lucide-react'
import { ResponsiveSheet, useIsDesktop } from '@/components/store/overlay-shell'
import { NumberRoll } from '@/components/motion/number-roll'
import { EASE_OUT, SPRING_POP, SPRING_SNAPPY } from '@/components/shared/reveal'
import { useUI } from '@/lib/ui-store'
import { useCart } from '@/lib/cart-store'
import { useWishlist } from '@/lib/wishlist-store'
import { useRecentlyViewed } from '@/lib/recently-viewed'
import { useMoney } from '@/lib/use-money'
import { useI18n } from '@/lib/i18n'
import { flyToCart } from '@/lib/cart-fx'
import { api, type ApiProduct, type ApiReview } from '@/lib/api'
import { cn } from '@/lib/utils'
import { fit } from '@/lib/img-fit'

type TFn = (key: string, vars?: Record<string, string | number>) => string

// t() returns the key itself when a string is missing; fall back to raw data then.
export function catLabel(t: TFn, category: string) {
  const k = `qv.cat.${category}`
  const s = t(k)
  return s === k ? category : s
}

function typing(el: EventTarget | null) {
  const n = el as HTMLElement | null
  return !!n?.closest?.('input, textarea, select, [contenteditable="true"], [role="tablist"], [role="radiogroup"]')
}

/**
 * Quick view. Opens when useUI.quick is set. Desktop: gallery and details side
 * by side. Phones: a bottom sheet with a swipeable gallery and a sticky buy bar.
 */
export function ProductModal({ allProducts }: { allProducts: ApiProduct[] }) {
  const quick = useUI((s) => s.quick)
  const setQuick = useUI((s) => s.setQuick)
  // Keep the last product rendered while the sheet animates closed.
  const [last, setLast] = useState<ApiProduct | null>(quick)
  useEffect(() => { if (quick) setLast(quick) }, [quick])
  const product = quick ?? last
  const rootRef = useRef<HTMLDivElement>(null)

  if (!product) return null
  return (
    <ResponsiveSheet
      open={!!quick}
      onOpenChange={(v) => { if (!v) setQuick(null) }}
      title={product.name}
      description={product.tagline}
      hideTitle
      size="xl"
      className="md:max-h-[90vh]"
    >
      <MotionConfig reducedMotion="user">
        <div ref={rootRef}>
          <AnimatePresence
            mode="wait"
            initial={false}
            onExitComplete={() => rootRef.current?.parentElement?.scrollTo({ top: 0 })}
          >
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: EASE_OUT }}
            >
              <QuickBody product={product} allProducts={allProducts} />
            </motion.div>
          </AnimatePresence>
        </div>
      </MotionConfig>
    </ResponsiveSheet>
  )
}

function QuickBody({ product, allProducts }: { product: ApiProduct; allProducts: ApiProduct[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const desktop = useIsDesktop()
  const addViewed = useRecentlyViewed((s) => s.add)

  const images = useMemo(() => [product.image, ...(product.gallery || [])].filter(Boolean), [product])
  const [idx, setIdx] = useState(0)
  const [qty, setQty] = useState(1)
  const [added, setAdded] = useState(false)
  const addedTimer = useRef(0)
  const wellRef = useRef<HTMLDivElement>(null)
  const trackRef = useRef<HTMLDivElement>(null)
  const reviewsRef = useRef<HTMLElement>(null)
  const out = product.stock <= 0
  const low = !out && product.stock <= (product.lowStockThreshold || 0)
  const maxQty = Math.max(1, Math.min(product.stock || 99, 99))

  // Approved reviews only, as before.
  const [reviews, setReviews] = useState<ApiReview[]>([])
  const [loadingRev, setLoadingRev] = useState(true)
  const loadReviews = useCallback(() => {
    let live = true
    setLoadingRev(true)
    api.reviews(product.id)
      .then((r) => { if (live) setReviews(r.reviews) })
      .catch(() => { if (live) setReviews([]) })
      .finally(() => { if (live) setLoadingRev(false) })
    return () => { live = false }
  }, [product.id])
  useEffect(() => loadReviews(), [loadReviews])

  useEffect(() => {
    addViewed({ id: product.id, name: product.name, price: product.price, image: product.image, category: product.category })
  }, [product.id, product.name, product.price, product.image, product.category, addViewed])

  useEffect(() => () => clearTimeout(addedTimer.current), [])

  const go = useCallback((i: number) => {
    const n = images.length
    const next = ((i % n) + n) % n
    setIdx(next)
    const track = trackRef.current
    if (track && track.offsetParent) track.scrollTo({ left: next * track.clientWidth, behavior: 'smooth' })
  }, [images.length])

  // Arrow keys switch photos.
  useEffect(() => {
    if (images.length < 2) return
    const onKey = (e: KeyboardEvent) => {
      if (!useUI.getState().quick || typing(e.target)) return
      if (e.key === 'ArrowRight') { e.preventDefault(); go(idx + 1) }
      if (e.key === 'ArrowLeft') { e.preventDefault(); go(idx - 1) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [go, idx, images.length])

  const addToBag = () => {
    if (out) return
    useCart.getState().add({ productId: product.id, name: product.name, price: product.price, unit: product.unit, image: product.image, stock: product.stock }, qty)
    const from = desktop ? wellRef.current : (trackRef.current?.children[idx] as HTMLElement | undefined) ?? null
    flyToCart(from)
    setAdded(true)
    clearTimeout(addedTimer.current)
    addedTimer.current = window.setTimeout(() => setAdded(false), 1600)
  }

  const avg = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0

  const buy = (
    <div className="flex items-center gap-2.5">
      <Stepper qty={qty} setQty={setQty} max={maxQty} disabled={out} t={t} />
      <AddButton onClick={addToBag} added={added} out={out} t={t} />
      {desktop && <HeartButton product={product} t={t} />}
    </div>
  )

  return (
    <div className="relative">
      <div className="grid gap-6 md:grid-cols-[minmax(0,1.02fr)_minmax(0,1fr)] md:gap-10">
        {/* Gallery */}
        <div className="min-w-0">
          {desktop ? (
            <DesktopGallery images={images} idx={idx} go={go} name={product.name} wellRef={wellRef} t={t} />
          ) : (
            <MobileGallery images={images} idx={idx} setIdx={setIdx} name={product.name} trackRef={trackRef} />
          )}
          <p className="sr-only" aria-live="polite">{t('qv.photo', { n: idx + 1, total: images.length })}</p>
        </div>

        {/* Details */}
        <div className="min-w-0 md:pt-1">
          <div className="flex flex-wrap items-center gap-2 md:pr-12">
            <span className="inline-flex h-8 items-center rounded-full bg-shell px-3.5 text-[0.84rem] font-medium text-plum">
              {catLabel(t, product.category)}
            </span>
            <StockChip out={out} low={low} stock={product.stock} t={t} />
          </div>

          <div className="mt-4 flex items-start gap-3">
            <h2 className="min-w-0 flex-1 font-display text-[clamp(1.85rem,3.2vw,2.6rem)] leading-[1.02] text-plum">{product.name}</h2>
            {!desktop && <HeartButton product={product} t={t} small />}
          </div>
          {product.tagline && <p className="mt-2 text-[1.02rem] text-muted-foreground">{product.tagline}</p>}

          {reviews.length > 0 && (
            <button
              onClick={() => reviewsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
              className="link-draw mt-2 inline-flex items-center gap-1.5 text-[0.9rem] text-foreground/80"
            >
              <Star className="h-4 w-4 fill-coral text-coral" aria-hidden />
              <span className="tabular">{avg.toFixed(1)}</span>
              <span className="text-muted-foreground">({reviews.length === 1 ? t('qv.reviewsOne') : t('qv.reviewsMany', { n: reviews.length })})</span>
            </button>
          )}

          <div className="mt-5 flex flex-wrap items-end gap-x-3 gap-y-1">
            <span className="font-display text-[2.1rem] leading-none text-plum">
              <NumberRoll value={money(product.price * qty)} />
            </span>
            <span className="pb-0.5 text-[0.92rem] text-muted-foreground">
              {qty > 1 ? t('qv.each', { n: qty, price: money(product.price) }) : product.unit}
            </span>
          </div>

          {product.description && <p className="mt-4 max-w-[52ch] text-[0.98rem] leading-relaxed text-foreground/80">{product.description}</p>}

          {desktop && <div className="mt-6">{buy}</div>}

          <DetailTabs product={product} t={t} />
        </div>
      </div>

      <ReviewsBlock
        sectionRef={reviewsRef}
        product={product}
        reviews={reviews}
        loading={loadingRev}
        avg={avg}
        reload={loadReviews}
        t={t}
      />

      <Related product={product} allProducts={allProducts} t={t} />

      {!desktop && (
        <div className="sticky bottom-[calc(-1*max(20px,env(safe-area-inset-bottom)))] z-20 -mx-5 mt-8 border-t border-border bg-card px-5 pb-[max(14px,env(safe-area-inset-bottom))] pt-3 shadow-[0_-14px_28px_-20px_rgb(31_7_14/0.35)]">
          {buy}
        </div>
      )}
    </div>
  )
}

/* ---------------------------------------------------------------- gallery */

function DesktopGallery({ images, idx, go, name, wellRef, t }: {
  images: string[]; idx: number; go: (i: number) => void; name: string
  wellRef: React.RefObject<HTMLDivElement | null>; t: TFn
}) {
  const many = images.length > 1
  return (
    <div>
      <div ref={wellRef} className="group relative aspect-square overflow-hidden rounded-[24px] bg-shell">
        <AnimatePresence initial={false}>
          <motion.div
            key={idx}
            className="absolute inset-0"
            initial={{ opacity: 0, scale: 1.045 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.42, ease: EASE_OUT }}
          >
            <Image src={images[idx]} alt={idx === 0 ? name : ''} fill sizes="(min-width: 1024px) 480px, 50vw" className={fit(images[idx], 'lg')} priority={idx === 0} />
          </motion.div>
        </AnimatePresence>
        {many && (
          <>
            <button
              onClick={() => go(idx - 1)}
              aria-label={t('qv.prevPhoto')}
              className="press absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-card text-plum opacity-0 shadow-2 group-hover:opacity-100 focus-visible:opacity-100"
            >
              <ChevronLeft className="h-5 w-5" aria-hidden />
            </button>
            <button
              onClick={() => go(idx + 1)}
              aria-label={t('qv.nextPhoto')}
              className="press absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-card text-plum opacity-0 shadow-2 group-hover:opacity-100 focus-visible:opacity-100"
            >
              <ChevronRight className="h-5 w-5" aria-hidden />
            </button>
            <span className="tabular absolute bottom-3 left-3 rounded-full bg-card px-2.5 py-1 text-[0.8rem] font-medium text-plum shadow-1" aria-hidden>
              {idx + 1} / {images.length}
            </span>
          </>
        )}
      </div>
      {many && (
        <div className="mt-3 flex gap-2" aria-label={t('qv.photos')} role="group">
          {images.map((src, i) => (
            <button
              key={`${src}-${i}`}
              onClick={() => go(i)}
              aria-label={t('qv.showPhoto', { n: i + 1 })}
              aria-current={i === idx}
              className="press relative h-[70px] w-[70px] shrink-0 rounded-[17px] p-[4px]"
            >
              {i === idx && (
                <motion.span layoutId="qv-thumb-ring" className="absolute inset-0 rounded-[17px] border-2 border-plum" transition={SPRING_SNAPPY} />
              )}
              <span className="relative block h-full w-full overflow-hidden rounded-[13px] bg-shell">
                <Image src={src} alt="" fill sizes="70px" className={cn(fit(src, 'sm'), 'transition-opacity duration-200', i === idx ? 'opacity-100' : 'opacity-65 hover:opacity-100')} />
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function MobileGallery({ images, idx, setIdx, name, trackRef }: {
  images: string[]; idx: number; setIdx: (i: number) => void; name: string
  trackRef: React.RefObject<HTMLDivElement | null>
}) {
  useEffect(() => {
    const track = trackRef.current
    if (!track || images.length < 2) return
    const io = new IntersectionObserver((entries) => {
      for (const e of entries) if (e.isIntersecting) setIdx(Number((e.target as HTMLElement).dataset.i))
    }, { root: track, threshold: 0.6 })
    Array.from(track.children).forEach((c) => io.observe(c))
    return () => io.disconnect()
  }, [images.length, setIdx, trackRef])

  return (
    <div className="-mx-5">
      <div ref={trackRef} className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto overscroll-x-contain">
        {images.map((src, i) => (
          <div key={`${src}-${i}`} data-i={i} className="w-full shrink-0 snap-center px-5">
            <div className="relative aspect-square overflow-hidden rounded-[24px] bg-shell">
              <Image src={src} alt={i === 0 ? name : ''} fill sizes="100vw" className={fit(src, 'lg')} priority={i === 0} />
            </div>
          </div>
        ))}
      </div>
      {images.length > 1 && (
        <div className="mt-3 flex justify-center gap-2" aria-hidden>
          {images.map((_, i) => (
            <span key={i} className="relative grid h-1.5 w-1.5 place-items-center">
              <span className="h-1.5 w-1.5 rounded-full bg-plum/20" />
              {i === idx && <motion.span layoutId="qv-dot" className="absolute h-1.5 w-[18px] rounded-full bg-plum" transition={SPRING_SNAPPY} />}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

/* ------------------------------------------------------------- buy parts */

function StockChip({ out, low, stock, t }: { out: boolean; low: boolean; stock: number; t: TFn }) {
  if (out) return (
    <span className="inline-flex h-8 items-center gap-2 rounded-full bg-foreground/[0.06] px-3.5 text-[0.84rem] font-medium text-muted-foreground">
      <span className="h-1.5 w-1.5 rounded-full bg-muted-foreground" aria-hidden />{t('qv.out')}
    </span>
  )
  if (low) return (
    <span className="inline-flex h-8 items-center gap-2 rounded-full bg-coral/15 px-3.5 text-[0.84rem] font-medium text-plum">
      <span className="h-1.5 w-1.5 rounded-full bg-coral" aria-hidden />{t('qv.lowStock', { n: stock })}
    </span>
  )
  return (
    <span className="inline-flex h-8 items-center gap-2 rounded-full bg-lagoon-deep/10 px-3.5 text-[0.84rem] font-medium text-lagoon-deep">
      <span className="h-1.5 w-1.5 rounded-full bg-lagoon-deep" aria-hidden />{t('qv.inStock')}
    </span>
  )
}

function Stepper({ qty, setQty, max, disabled, t }: { qty: number; setQty: (fn: (q: number) => number) => void; max: number; disabled: boolean; t: TFn }) {
  return (
    <div className="flex h-14 shrink-0 items-center rounded-full bg-shell p-1" role="group" aria-label={t('qv.qty')}>
      <button
        onClick={() => setQty((q) => Math.max(1, q - 1))}
        disabled={disabled || qty <= 1}
        aria-label={t('qv.less')}
        className="press grid h-12 w-12 place-items-center rounded-full text-plum hover:bg-card disabled:opacity-35 disabled:hover:bg-transparent"
      >
        <Minus className="h-[18px] w-[18px]" aria-hidden />
      </button>
      <span className="grid w-7 place-items-center text-[1.08rem] font-semibold text-plum" aria-live="polite">
        <NumberRoll value={String(qty)} />
      </span>
      <button
        onClick={() => setQty((q) => Math.min(max, q + 1))}
        disabled={disabled || qty >= max}
        aria-label={t('qv.more')}
        className="press grid h-12 w-12 place-items-center rounded-full text-plum hover:bg-card disabled:opacity-35 disabled:hover:bg-transparent"
      >
        <Plus className="h-[18px] w-[18px]" aria-hidden />
      </button>
    </div>
  )
}

function AddButton({ onClick, added, out, t }: { onClick: () => void; added: boolean; out: boolean; t: TFn }) {
  return (
    <button
      onClick={onClick}
      disabled={out}
      className={cn(
        'press relative flex h-14 min-w-0 flex-1 items-center justify-center overflow-hidden rounded-full px-5 text-[1rem] font-semibold',
        out ? 'bg-foreground/10 text-muted-foreground' : added ? 'bg-lagoon-deep text-porcelain' : 'bg-plum text-porcelain hover:bg-plum-2',
      )}
    >
      <AnimatePresence mode="popLayout" initial={false}>
        {added ? (
          <motion.span key="added" className="inline-flex items-center gap-2 whitespace-nowrap"
            initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -20, opacity: 0 }} transition={{ duration: 0.22, ease: EASE_OUT }}>
            <motion.span className="grid h-6 w-6 place-items-center rounded-full bg-porcelain/20" initial={{ scale: 0.5 }} animate={{ scale: 1 }} transition={SPRING_POP}>
              <Check className="h-4 w-4" strokeWidth={3} aria-hidden />
            </motion.span>
            {t('qv.added')}
          </motion.span>
        ) : (
          <motion.span key="add" className="inline-flex items-center gap-2 whitespace-nowrap"
            initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: -20, opacity: 0 }} transition={{ duration: 0.22, ease: EASE_OUT }}>
            {!out && <ShoppingBag className="h-[18px] w-[18px]" aria-hidden />}
            {out ? t('qv.out') : t('qv.add')}
          </motion.span>
        )}
      </AnimatePresence>
      <span className="sr-only" aria-live="polite">{added ? t('qv.added') : ''}</span>
    </button>
  )
}

export function HeartButton({ product, t, small = false }: { product: ApiProduct; t: TFn; small?: boolean }) {
  const saved = useWishlist((s) => s.items.some((i) => i.id === product.id))
  const toggle = useWishlist((s) => s.toggle)
  const [burst, setBurst] = useState(0)
  return (
    <button
      onClick={() => {
        toggle({ id: product.id, name: product.name, price: product.price, image: product.image, category: product.category, unit: product.unit })
        if (!saved) setBurst((b) => b + 1)
      }}
      aria-pressed={saved}
      aria-label={saved ? t('qv.unsave') : t('qv.save')}
      className={cn('press relative grid shrink-0 place-items-center rounded-full bg-card shadow-1 ring-1 ring-border/70 hover:ring-plum/30', small ? 'h-12 w-12' : 'h-14 w-14')}
    >
      <motion.span key={burst} className="grid place-items-center" initial={burst ? { scale: 0.55 } : false} animate={{ scale: 1 }} transition={SPRING_POP}>
        <Heart className={cn('h-[22px] w-[22px] transition-colors duration-200', saved ? 'fill-coral text-coral' : 'text-plum')} aria-hidden />
      </motion.span>
      {burst > 0 && (
        <motion.span
          key={`ring-${burst}`}
          className="pointer-events-none absolute inset-0 rounded-full border-2 border-coral"
          initial={{ scale: 0.75, opacity: 0.9 }}
          animate={{ scale: 1.55, opacity: 0 }}
          transition={{ duration: 0.55, ease: EASE_OUT }}
          aria-hidden
        />
      )}
    </button>
  )
}

/* ------------------------------------------------------------------ tabs */

function DetailTabs({ product, t }: { product: ApiProduct; t: TFn }) {
  const [tab, setTab] = useState<'benefits' | 'ingredients' | 'use'>('benefits')
  const tabs = [
    { k: 'benefits' as const, label: t('qv.benefits') },
    { k: 'ingredients' as const, label: t('qv.ingredients') },
    { k: 'use' as const, label: t('qv.howToUse') },
  ]
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return
    e.preventDefault()
    const i = tabs.findIndex((x) => x.k === tab)
    const n = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length].k
    setTab(n)
    document.getElementById(`qv-tab-${n}`)?.focus()
  }
  return (
    <div className="mt-8">
      <div role="tablist" aria-label={t('qv.details')} onKeyDown={onKey} className="no-scrollbar inline-flex max-w-full overflow-x-auto rounded-full bg-shell p-1">
        {tabs.map((x) => {
          const on = tab === x.k
          return (
            <button
              key={x.k}
              id={`qv-tab-${x.k}`}
              role="tab"
              aria-selected={on}
              aria-controls="qv-tabpanel"
              tabIndex={on ? 0 : -1}
              onClick={() => setTab(x.k)}
              className={cn('relative h-11 shrink-0 rounded-full px-4 text-[0.92rem] font-medium transition-colors duration-200', on ? 'text-plum' : 'text-muted-foreground hover:text-plum')}
            >
              {on && <motion.span layoutId="qv-tab-pill" className="absolute inset-0 rounded-full bg-card shadow-1" transition={SPRING_SNAPPY} />}
              <span className="relative whitespace-nowrap">{x.label}</span>
            </button>
          )
        })}
      </div>
      <div id="qv-tabpanel" role="tabpanel" aria-labelledby={`qv-tab-${tab}`} className="mt-4 min-h-[9.5rem]">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4, transition: { duration: 0.14 } }}
            transition={{ duration: 0.22, ease: EASE_OUT }}
          >
            {tab === 'benefits' && (
              product.benefits?.length ? (
                <ul className="space-y-2.5">
                  {product.benefits.map((b, i) => (
                    <motion.li
                      key={b}
                      className="flex items-start gap-3 text-[0.98rem] text-foreground/85"
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.04 + i * 0.05, ease: EASE_OUT }}
                    >
                      <motion.span
                        className="mt-[1px] grid h-6 w-6 shrink-0 place-items-center rounded-full bg-lagoon-deep/12 text-lagoon-deep"
                        initial={{ scale: 0.6 }}
                        animate={{ scale: 1 }}
                        transition={{ ...SPRING_POP, delay: 0.06 + i * 0.05 }}
                      >
                        <Check className="h-3.5 w-3.5" strokeWidth={3} aria-hidden />
                      </motion.span>
                      <span>{b}</span>
                    </motion.li>
                  ))}
                </ul>
              ) : <p className="text-[0.95rem] text-muted-foreground">{t('qv.none')}</p>
            )}
            {tab === 'ingredients' && (
              product.ingredients?.length ? (
                <ul className="flex flex-wrap gap-2">
                  {product.ingredients.map((ing, i) => (
                    <motion.li
                      key={ing}
                      className="inline-flex h-9 items-center rounded-full bg-card px-3.5 text-[0.92rem] text-plum shadow-1 ring-1 ring-border/60"
                      initial={{ opacity: 0, y: 6, scale: 0.96 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.26, delay: i * 0.04, ease: EASE_OUT }}
                    >
                      {ing}
                    </motion.li>
                  ))}
                </ul>
              ) : <p className="text-[0.95rem] text-muted-foreground">{t('qv.none')}</p>
            )}
            {tab === 'use' && (
              <div className="flex gap-3.5 rounded-[20px] bg-porcelain p-4 ring-1 ring-border/60">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-card text-lagoon-deep shadow-1">
                  <Sprout className="h-5 w-5" aria-hidden />
                </span>
                <p className="pt-1.5 text-[0.98rem] leading-relaxed text-foreground/85">{product.howToUse || t('qv.none')}</p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  )
}

/* --------------------------------------------------------------- reviews */

function Stars({ value, size = 'h-3.5 w-3.5' }: { value: number; size?: string }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-hidden>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={cn(size, i < Math.round(value) ? 'fill-coral text-coral' : 'text-foreground/20')} />
      ))}
    </span>
  )
}

function ReviewsBlock({ sectionRef, product, reviews, loading, avg, reload, t }: {
  sectionRef: React.RefObject<HTMLElement | null>; product: ApiProduct; reviews: ApiReview[]; loading: boolean; avg: number; reload: () => void; t: TFn
}) {
  const { lang } = useI18n()
  const date = (iso: string) => {
    try { return new Date(iso).toLocaleDateString(lang === 'sw' ? 'sw-TZ' : 'en-GB', { month: 'short', year: 'numeric' }) } catch { return '' }
  }
  return (
    <section ref={sectionRef} className="mt-12 scroll-mt-4 border-t border-border pt-8" aria-labelledby="qv-reviews">
      <div className="grid gap-8 md:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)] md:gap-10">
        <div className="min-w-0">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h3 id="qv-reviews" className="font-display text-[1.7rem] leading-none text-plum">{t('qv.reviews')}</h3>
            {reviews.length > 0 && (
              <div className="flex items-center gap-2.5 text-[0.9rem] text-muted-foreground">
                <span className="font-display text-[1.5rem] leading-none text-plum tabular">{avg.toFixed(1)}</span>
                <Stars value={avg} size="h-4 w-4" />
                <span>{reviews.length === 1 ? t('qv.reviewsOne') : t('qv.reviewsMany', { n: reviews.length })}</span>
              </div>
            )}
          </div>
          <div className="mt-5">
            {loading ? (
              <p className="flex items-center gap-2 py-6 text-[0.95rem] text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" aria-hidden />{t('qv.reviewsLoading')}</p>
            ) : reviews.length === 0 ? (
              <div className="flex items-start gap-3.5 rounded-[22px] bg-porcelain p-5 ring-1 ring-border/60">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-card text-plum shadow-1"><Star className="h-[18px] w-[18px]" aria-hidden /></span>
                <p className="pt-1 text-[0.96rem] text-foreground/80">{t('qv.reviewsNone')}</p>
              </div>
            ) : (
              <ul className="space-y-3">
                {reviews.map((r, i) => (
                  <motion.li
                    key={r.id}
                    className="rounded-[22px] bg-card p-5 shadow-1 ring-1 ring-border/60"
                    initial={{ opacity: 0, y: 14 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: Math.min(i, 5) * 0.05, ease: EASE_OUT }}
                  >
                    <div className="flex items-center gap-3">
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-shell font-display text-[1.05rem] text-plum" aria-hidden>
                        {r.name.trim().charAt(0).toUpperCase()}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[0.95rem] font-semibold text-foreground">{r.name}</div>
                        <div className="flex items-center gap-1 text-[0.82rem] text-muted-foreground">
                          {r.location && <><MapPin className="h-3.5 w-3.5" aria-hidden /><span className="truncate">{r.location}</span></>}
                          {r.createdAt && <span className="ml-auto shrink-0">{date(r.createdAt)}</span>}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center gap-2">
                      <Stars value={r.rating} />
                      <span className="sr-only">{t('qv.stars', { n: r.rating })}</span>
                    </div>
                    <p className="mt-2 text-[0.96rem] leading-relaxed text-foreground/85">{r.comment}</p>
                  </motion.li>
                ))}
              </ul>
            )}
          </div>
        </div>
        <ReviewForm product={product} reload={reload} t={t} />
      </div>
    </section>
  )
}

function ReviewForm({ product, reload, t }: { product: ApiProduct; reload: () => void; t: TFn }) {
  const [name, setName] = useState('')
  const [town, setTown] = useState('')
  const [rating, setRating] = useState(5)
  const [hover, setHover] = useState(0)
  const [comment, setComment] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [sent, setSent] = useState(false)
  const shown = hover || rating

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !comment.trim()) { setError(t('qv.missing')); return }
    setError('')
    setBusy(true)
    try {
      await api.addReview({ productId: product.id, name: name.trim(), location: town.trim() || 'Zanzibar', rating, comment: comment.trim() })
      setComment('')
      setSent(true)
      reload()
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  const input = 'h-12 w-full rounded-[14px] border border-input bg-card px-3.5 text-[1rem] text-foreground outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-muted-foreground focus:border-plum focus:ring-2 focus:ring-plum/25'

  return (
    <div className="self-start rounded-[26px] bg-porcelain p-5 ring-1 ring-border/70 md:p-6">
      <AnimatePresence mode="wait" initial={false}>
        {sent ? (
          <motion.div key="sent" className="flex flex-col items-start gap-4 py-2" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25, ease: EASE_OUT }}>
            <motion.span className="grid h-12 w-12 place-items-center rounded-full bg-lagoon-deep text-white" initial={{ scale: 0.6 }} animate={{ scale: 1 }} transition={SPRING_POP}>
              <Check className="h-6 w-6" strokeWidth={3} aria-hidden />
            </motion.span>
            <p className="text-[1rem] text-foreground/85" role="status">{t('qv.thanks')}</p>
            <button onClick={() => setSent(false)} className="press inline-flex h-11 items-center rounded-full bg-card px-5 text-[0.95rem] font-medium text-plum shadow-1">{t('qv.another')}</button>
          </motion.div>
        ) : (
          <motion.form key="form" onSubmit={submit} noValidate initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            <h4 className="font-display text-[1.3rem] leading-tight text-plum">{t('qv.write')}</h4>

            <div className="mt-4">
              <span id="qv-rate-label" className="text-[0.88rem] font-medium text-foreground/80">{t('qv.yourRating')}</span>
              <div role="radiogroup" aria-labelledby="qv-rate-label" className="-ml-2 mt-1 flex items-center" onMouseLeave={() => setHover(0)}>
                {Array.from({ length: 5 }).map((_, i) => {
                  const n = i + 1
                  const on = n <= shown
                  return (
                    <motion.button
                      type="button"
                      key={n}
                      role="radio"
                      aria-checked={rating === n}
                      aria-label={t('qv.stars', { n })}
                      onClick={() => setRating(n)}
                      onMouseEnter={() => setHover(n)}
                      onFocus={() => setHover(n)}
                      onBlur={() => setHover(0)}
                      onKeyDown={(e) => {
                        if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); setRating(Math.min(5, rating + 1)) }
                        if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); setRating(Math.max(1, rating - 1)) }
                      }}
                      tabIndex={rating === n ? 0 : -1}
                      className="grid h-11 w-11 place-items-center rounded-full"
                      whileHover={{ scale: 1.18, rotate: -8 }}
                      whileTap={{ scale: 0.88 }}
                      transition={SPRING_SNAPPY}
                    >
                      <Star className={cn('h-[26px] w-[26px] transition-colors duration-150', on ? 'fill-coral text-coral' : 'text-foreground/25')} aria-hidden />
                    </motion.button>
                  )
                })}
              </div>
            </div>

            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="text-[0.88rem] font-medium text-foreground/80">{t('qv.name')}</span>
                <input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={cn(input, 'mt-1.5')} />
              </label>
              <label className="block">
                <span className="text-[0.88rem] font-medium text-foreground/80">{t('qv.town')}</span>
                <input value={town} onChange={(e) => setTown(e.target.value)} placeholder={t('qv.townPh')} autoComplete="address-level2" className={cn(input, 'mt-1.5')} />
              </label>
            </div>
            <label className="mt-3 block">
              <span className="text-[0.88rem] font-medium text-foreground/80">{t('qv.comment')}</span>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
                placeholder={t('qv.commentPh')}
                aria-invalid={!!error}
                aria-describedby={error ? 'qv-review-error' : undefined}
                className={cn(input, 'mt-1.5 h-auto resize-none py-3 leading-normal')}
              />
            </label>
            {error && <p id="qv-review-error" role="alert" className="mt-2 text-[0.88rem] text-destructive">{error}</p>}
            <button
              type="submit"
              disabled={busy}
              className="press mt-4 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-plum px-6 text-[0.98rem] font-semibold text-porcelain hover:bg-plum-2 disabled:opacity-60"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              {busy ? t('qv.sending') : t('qv.send')}
            </button>
            <p className="mt-2.5 text-center text-[0.82rem] text-muted-foreground">{t('qv.note')}</p>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  )
}

/* --------------------------------------------------------------- related */

function Related({ product, allProducts, t }: { product: ApiProduct; allProducts: ApiProduct[]; t: TFn }) {
  const money = useMoney()
  const setQuick = useUI((s) => s.setQuick)
  const related = useMemo(() => {
    const others = allProducts.filter((p) => p.id !== product.id && p.active !== false)
    const same = others.filter((p) => p.category === product.category)
    const rest = others.filter((p) => p.category !== product.category).sort((a, b) => Number(b.featured) - Number(a.featured))
    return [...same, ...rest].slice(0, 4)
  }, [allProducts, product.id, product.category])
  if (!related.length) return null
  return (
    <section className="mt-12 border-t border-border pt-8" aria-labelledby="qv-related">
      <h3 id="qv-related" className="font-display text-[1.7rem] leading-none text-plum">{t('qv.related')}</h3>
      <ul className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {related.map((p, i) => (
          <motion.li
            key={p.id}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.05, ease: EASE_OUT }}
          >
            <button onClick={() => setQuick(p)} aria-label={t('qv.open', { name: p.name })} className="group block w-full rounded-[22px] text-left">
              <span className="relative block aspect-square overflow-hidden rounded-[20px] bg-shell">
                <Image src={p.image} alt="" fill sizes="(min-width: 768px) 230px, 45vw" className={`${fit(p.image, 'lg')} transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]`} />
              </span>
              <span className="mt-2.5 block truncate px-1 text-[0.95rem] font-medium text-foreground group-hover:text-plum">{p.name}</span>
              <span className="block px-1 text-[0.9rem] text-muted-foreground tabular">{money(p.price)}</span>
            </button>
          </motion.li>
        ))}
      </ul>
    </section>
  )
}
