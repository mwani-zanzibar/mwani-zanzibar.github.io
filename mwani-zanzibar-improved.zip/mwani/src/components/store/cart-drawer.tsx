'use client'

import Image from 'next/image'
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet'
import { useCart } from '@/lib/cart-store'
import { useMoney } from '@/lib/use-money'
import { motion, AnimatePresence } from 'framer-motion'

export function CartDrawer({ onCheckout }: { onCheckout: () => void }) {
  const open = useCart((s) => s.open)
  const setOpen = useCart((s) => s.setOpen)
  const money = useMoney()
  const items = useCart((s) => s.items)
  const setQty = useCart((s) => s.setQty)
  const remove = useCart((s) => s.remove)
  const clear = useCart((s) => s.clear)

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full sm:max-w-md p-0 flex flex-col">
        <SheetHeader className="px-5 pt-5 pb-3 border-b border-border/60">
          <SheetTitle className="flex items-center gap-2 font-display text-lg">
            <ShoppingBag className="h-5 w-5 text-coral" /> Your Bag
          </SheetTitle>
          <SheetDescription>
            {items.length === 0 ? 'Your bag is empty.' : `${items.reduce((n, i) => n + i.qty, 0)} item(s) selected`}
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto scrollbar-thin px-5 py-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-16">
              <div className="grid h-20 w-20 place-items-center rounded-full bg-brand/10">
                <ShoppingBag className="h-9 w-9 text-brand/50" />
              </div>
              <p className="mt-4 font-display text-lg font-bold">Your bag is empty</p>
              <p className="mt-1 text-sm text-muted-foreground">Browse our seaweed collection and add your favourites.</p>
              <button
                onClick={() => setOpen(false)}
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-semibold hover:opacity-95 transition"
              >
                Start shopping <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <ul className="space-y-3">
              <AnimatePresence initial={false}>
                {items.map((it) => (
                  <motion.li
                    key={it.productId}
                    layout
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 30, height: 0 }}
                    transition={{ duration: 0.25 }}
                    className="flex gap-3 rounded-2xl border border-border/60 bg-card p-3"
                  >
                    <div className="relative h-20 w-20 shrink-0 rounded-xl overflow-hidden bg-muted/30">
                      <Image src={it.image} alt={it.name} fill className="object-cover" sizes="80px" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold leading-tight line-clamp-2">{it.name}</div>
                      <div className="text-[11px] text-muted-foreground">{it.unit}</div>
                      <div className="mt-1.5 font-bold text-brand">{money(it.price)}</div>
                      <div className="mt-2 flex items-center justify-between">
                        <div className="inline-flex items-center rounded-full border border-border/60">
                          <button
                            onClick={() => setQty(it.productId, it.qty - 1)}
                            className="grid h-7 w-7 place-items-center rounded-full hover:bg-accent/40 transition"
                            aria-label="decrease"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-7 text-center text-xs font-bold">{it.qty}</span>
                          <button
                            onClick={() => setQty(it.productId, Math.min(it.qty + 1, it.stock || 99))}
                            className="grid h-7 w-7 place-items-center rounded-full hover:bg-accent/40 transition"
                            aria-label="increase"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <button
                          onClick={() => remove(it.productId)}
                          className="grid h-7 w-7 place-items-center rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition"
                          aria-label="remove"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </motion.li>
                ))}
              </AnimatePresence>
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-border/60 p-5 space-y-3 bg-card/50">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-display text-xl font-bold text-brand">{money(subtotal)}</span>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Shipping & ferry fees are calculated at checkout based on your delivery location.
            </p>
            <button
              onClick={() => { setOpen(false); onCheckout() }}
              className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-brand text-primary-foreground py-3.5 text-sm font-bold shadow-glow hover:opacity-95 transition"
            >
              Checkout <ArrowRight className="h-4 w-4" />
            </button>
            <button
              onClick={clear}
              className="w-full text-xs text-muted-foreground hover:text-destructive transition py-1"
            >
              Clear bag
            </button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  )
}
