'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { Clock, ArrowRight } from 'lucide-react'
import { useRecentlyViewed } from '@/lib/recently-viewed'
import { Reveal } from '@/components/shared/reveal'
import { formatTZS } from '@/lib/format'
import type { ApiProduct } from '@/lib/api'

export function RecentlyViewed({ onSelect }: { onSelect: (p: ApiProduct) => void }) {
  const items = useRecentlyViewed((s) => s.items)
  if (items.length === 0) return null

  return (
    <section className="relative py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="flex items-end justify-between gap-4 mb-8">
          <div>
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-coral">
              <Clock className="h-3.5 w-3.5" /> Pick up where you left off
            </span>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl font-bold tracking-tight">Recently viewed</h2>
          </div>
        </Reveal>

        <div className="flex gap-4 overflow-x-auto scrollbar-thin pb-3 -mx-4 px-4 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
          {items.map((it, i) => (
            <motion.button
              key={it.id}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              onClick={() => onSelect({ id: it.id, name: it.name, price: it.price, image: it.image, category: it.category } as ApiProduct)}
              whileHover={{ y: -4 }}
              className="group relative shrink-0 w-44 sm:w-48 rounded-2xl border border-border/60 bg-card overflow-hidden shadow-soft hover:shadow-glow transition-shadow text-left"
            >
              <div className="relative aspect-square overflow-hidden bg-muted/30">
                <Image src={it.image} alt={it.name} fill loading="eager" className="object-cover transition-transform duration-500 group-hover:scale-105" sizes="192px" />
                <span className="absolute top-2 left-2 rounded-full bg-background/85 backdrop-blur px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-brand">{it.category}</span>
              </div>
              <div className="p-3">
                <div className="text-xs font-bold line-clamp-1">{it.name}</div>
                <div className="mt-1 flex items-center justify-between">
                  <span className="text-sm font-bold text-brand">{formatTZS(it.price)}</span>
                  <ArrowRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-brand group-hover:translate-x-0.5 transition-all" />
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  )
}
