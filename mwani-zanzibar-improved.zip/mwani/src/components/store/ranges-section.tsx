'use client'

import { useMemo } from 'react'
import Image from 'next/image'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { ArrowRight } from 'lucide-react'
import type { ApiProduct } from '@/lib/api'
import { useI18n } from '@/lib/i18n'
import { useMoney } from '@/lib/use-money'
import { useUI } from '@/lib/ui-store'
import { SplitReveal } from '@/components/motion/split-reveal'
import { Reveal, ImageReveal, EASE_OUT } from '@/components/shared/reveal'
import { CAT_SW } from '@/components/store/products-section'
import { cn } from '@/lib/utils'
import { useImg } from '@/lib/content-store'

type Cell = { cat: string; slot: string; img: string; cls: string; size: 'big' | 'tall' | 'small'; pos?: string }

// Varied bento. Desktop 4×2: Food big (2×2), Skin tall (1×2), Hair + Wellness single.
// Phones 2 columns: Food spans both, Skin tall on the left, Hair + Wellness stacked right.
const CELLS: Cell[] = [
  { cat: 'Food & Beverage', slot: 'ranges.food', img: '/products/seaweed-jelly.webp', cls: 'col-span-2 row-span-2', size: 'big', pos: 'object-[50%_58%]' },
  { cat: 'Skin Care', slot: 'ranges.skin', img: '/products/scrub-powder.webp', cls: 'row-span-2', size: 'tall', pos: 'object-[50%_50%]' },
  { cat: 'Hair Care', slot: 'ranges.hair', img: '/products/hair-oil.webp', cls: '', size: 'small', pos: 'object-[50%_45%]' },
  { cat: 'Health & Wellness', slot: 'ranges.wellness', img: '/products/capsules.webp', cls: '', size: 'small', pos: 'object-[50%_42%]' },
]

export function RangesSection({ products, onPick }: { products: ApiProduct[]; onPick: (category: string) => void }) {
  const { t, lang } = useI18n()
  const imgs: Record<string, string> = {
    'ranges.food': useImg('ranges.food', CELLS[0].img), 'ranges.skin': useImg('ranges.skin', CELLS[1].img),
    'ranges.hair': useImg('ranges.hair', CELLS[2].img), 'ranges.wellness': useImg('ranges.wellness', CELLS[3].img),
  }
  const counts = useMemo(() => {
    const m = new Map<string, number>()
    for (const p of products) m.set(p.category, (m.get(p.category) || 0) + 1)
    return m
  }, [products])
  const stars = useMemo(() => {
    const food = products.filter((p) => p.category === 'Food & Beverage')
    return [
      { key: 'powder', label: t('ranges.powder'), p: food.find((p) => /powder/i.test(p.name)) },
      { key: 'tea', label: t('ranges.tea'), p: food.find((p) => /\btea\b/i.test(p.name)) },
    ].filter((s): s is { key: string; label: string; p: ApiProduct } => !!s.p)
  }, [products, t])

  const label = (c: string) => (lang === 'sw' ? CAT_SW[c] || c : c)

  return (
    <section id="ranges" className="mx-auto max-w-[88rem] scroll-mt-24 px-5 pt-16 sm:px-8 sm:pt-32 lg:px-12">
      <div className="flex flex-wrap items-end justify-between gap-x-10 gap-y-4">
        <SplitReveal as="h2" text={t('ranges.title')} className="font-display text-[clamp(2.3rem,4.6vw,4.4rem)] leading-none text-plum" />
        <Reveal delay={0.1}>
          <p className="max-w-sm text-[1.02rem] text-foreground/70">{t('ranges.sub')}</p>
        </Reveal>
      </div>

      <div className="mt-9 grid auto-rows-[172px] grid-cols-2 gap-3 sm:auto-rows-[230px] sm:gap-4 md:h-[600px] md:auto-rows-auto md:grid-cols-4 md:grid-rows-2 lg:h-[680px] lg:gap-5">
        {CELLS.map((cell, i) => {
          const n = counts.get(cell.cat) || 0
          const name = label(cell.cat)
          const line = cell.size === 'big' ? t('ranges.stars') : cell.size === 'tall' ? t('ranges.skinLine') : ''
          return (
            <div key={cell.cat} className={cn('group relative min-h-0 overflow-hidden rounded-[28px] bg-shell', cell.cls)}>
              <ImageReveal className="absolute inset-0" delay={0.05 + i * 0.1}>
                <Image
                  src={imgs[cell.slot] || cell.img}
                  alt=""
                  fill
                  sizes={cell.size === 'big' ? '(max-width: 767px) 100vw, 50vw' : '(max-width: 767px) 50vw, 25vw'}
                  className={cn('object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06] group-has-[:focus-visible]:scale-[1.06]', cell.pos)}
                />
              </ImageReveal>
              {/* Scrim at the bottom only, so the label reads over any photo. */}
              <div aria-hidden className={cn('pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-night/85 via-night/40 to-transparent', cell.size === 'small' ? 'h-3/4' : 'h-1/2')} />

              <button
                type="button"
                onClick={() => onPick(cell.cat)}
                aria-label={t('ranges.shop', { range: name })}
                className="absolute inset-0 z-[1] rounded-[28px] focus-visible:outline-offset-[-4px] focus-visible:outline-porcelain"
              />

              <div className={cn('pointer-events-none absolute inset-x-0 bottom-0 z-[2] flex items-end justify-between gap-3', cell.size === 'small' ? 'p-3.5 sm:p-5' : 'p-4 sm:p-6 lg:p-7')}>
                <div className="min-w-0">
                  <h3
                    className={cn(
                      'font-display leading-[0.98] text-on-night',
                      cell.size === 'big' ? 'text-[2.1rem] sm:text-[2.8rem] lg:text-[3.4rem]' : cell.size === 'tall' ? 'text-[1.6rem] sm:text-[2.1rem] lg:text-[2.4rem]' : 'text-[1.25rem] sm:text-[1.7rem] lg:text-[1.9rem]',
                    )}
                  >
                    {name}
                  </h3>
                  {line && <p className={cn('mt-2 max-w-[22rem] text-on-night/85', cell.size === 'big' ? 'text-[0.98rem] sm:text-[1.05rem]' : 'hidden text-[0.95rem] sm:block')}>{line}</p>}
                  <p className={cn('text-on-night/70', cell.size === 'small' ? 'mt-1 text-[0.82rem] sm:text-[0.9rem]' : 'mt-1.5 text-[0.9rem]')}>
                    {n > 0 ? (n === 1 ? t('ranges.count1') : t('ranges.count', { n })) : ' '}
                  </p>
                </div>
                <span
                  aria-hidden
                  className={cn(
                    'grid shrink-0 place-items-center rounded-full bg-porcelain text-plum shadow-1 transition-transform duration-300 ease-out group-hover:-rotate-45 group-has-[:focus-visible]:-rotate-45',
                    cell.size === 'small' ? 'h-10 w-10 sm:h-11 sm:w-11' : 'h-11 w-11',
                  )}
                >
                  <ArrowRight className="h-[18px] w-[18px]" strokeWidth={2.2} />
                </span>
              </div>

              {cell.size === 'big' && <StarChips stars={stars} />}
            </div>
          )
        })}
      </div>
    </section>
  )
}

// Two floating mini cards on the big cell: the hero products with real prices.
function StarChips({ stars }: { stars: { key: string; label: string; p: ApiProduct }[] }) {
  const { t } = useI18n()
  const money = useMoney()
  const reduce = useReducedMotion()
  return (
    <div className="absolute left-3.5 top-3.5 z-[3] flex flex-col items-start gap-2 sm:left-6 sm:top-6">
      <AnimatePresence>
        {stars.map((s, i) => (
          <motion.button
            key={s.key}
            type="button"
            onClick={() => useUI.getState().setQuick(s.p)}
            aria-label={t('ranges.view', { name: s.p.name })}
            initial={reduce ? false : { opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '0px 0px -10% 0px' }}
            transition={{ duration: 0.6, delay: 0.7 + i * 0.12, ease: EASE_OUT }}
            whileHover={reduce ? undefined : { y: -2 }}
            whileTap={{ scale: 0.97 }}
            className={cn('flex h-12 items-center gap-2.5 rounded-full bg-surface pl-1.5 pr-4 text-left shadow-3 focus-visible:outline-porcelain', i === 1 && 'ml-5 sm:ml-8')}
          >
            <span className="relative h-9 w-9 shrink-0 overflow-hidden rounded-full bg-shell">
              <Image src={s.p.image} alt="" fill sizes="36px" className="object-cover" />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-[0.84rem] font-semibold text-foreground">{s.label}</span>
              <span className="tabular text-[0.8rem] font-semibold text-plum">{money(s.p.price)}</span>
            </span>
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  )
}
