'use client'

import { useEffect, useRef } from 'react'

// Hero-only live gradient: shallow lagoon light in the brand's blush, rose
// and aqua. Smooth (quintic noise, 3 soft octaves, no grain), full
// resolution up to DPR 1.5, slow. A soft light follows the pointer.
// Paused off-screen and in hidden tabs; a still under reduced motion.
const VERT = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}'
const FRAG = `
precision highp float;
uniform vec2 r; uniform float t; uniform vec2 m;
float h(vec2 p){ return fract(sin(dot(p,vec2(41.3,289.1)))*45758.5453); }
float n(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.-15.)+10.);
  return mix(mix(h(i),h(i+vec2(1,0)),u.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),u.x), u.y); }
float fbm(vec2 p){ return .55*n(p) + .3*n(p*1.9+3.1) + .15*n(p*3.7-1.7); }
vec3 c(float r,float g,float b){ return vec3(r,g,b)/255.; }
void main(){
  vec2 uv = gl_FragCoord.xy/r; vec2 p = uv*vec2(r.x/r.y,1.)*1.15;
  float s = t*.045;
  vec2 q = vec2(fbm(p+vec2(s,-s*.6)), fbm(p+vec2(-s*.7,s)+4.2));
  float v = fbm(p + 1.35*q + vec2(0.,s*.5));
  vec3 base = c(251.,246.,245.);
  vec3 col = base;
  col = mix(col, c(245.,214.,222.), smoothstep(.26,.58,v));
  col = mix(col, c(234.,172.,189.), smoothstep(.54,.84,v));
  col = mix(col, c(196.,234.,238.), smoothstep(.5,.88,q.x)*.7*(1.-uv.y*.3));
  col = mix(col, base, smoothstep(.75,1.,1.-uv.y)*.22);
  vec2 mp = m*vec2(r.x/r.y,1.)*1.15; float d = distance(p,mp);
  col = mix(col, vec3(1.), .28*exp(-d*d*3.2));
  col += (h(gl_FragCoord.xy)-.5)/255.;
  gl_FragColor = vec4(col,1.);
}`

export function LagoonCanvas() {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = ref.current
    const host = canvas?.parentElement
    if (!canvas || !host) return
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'low-power' })
    if (!gl) return
    const mk = (type: number, src: string) => { const s = gl.createShader(type)!; gl.shaderSource(s, src); gl.compileShader(s); return s }
    const pr = gl.createProgram()!
    gl.attachShader(pr, mk(gl.VERTEX_SHADER, VERT)); gl.attachShader(pr, mk(gl.FRAGMENT_SHADER, FRAG)); gl.linkProgram(pr)
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return
    gl.useProgram(pr)
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer())
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
    const a = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0)
    const uR = gl.getUniformLocation(pr, 'r'), uT = gl.getUniformLocation(pr, 't'), uM = gl.getUniformLocation(pr, 'm')
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5)
    const tgt = { x: 0.7, y: 0.6 }, cur = { x: 0.7, y: 0.6 }
    const t0 = performance.now()
    const draw = (now: number) => {
      cur.x += (tgt.x - cur.x) * 0.05; cur.y += (tgt.y - cur.y) * 0.05
      gl.uniform2f(uR, canvas.width, canvas.height)
      gl.uniform1f(uT, reduce ? 20 : (now - t0) / 1000)
      gl.uniform2f(uM, cur.x, cur.y)
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
    }
    const size = () => {
      canvas.width = Math.max(1, Math.round(host.clientWidth * dpr)); canvas.height = Math.max(1, Math.round(host.clientHeight * dpr))
      gl.viewport(0, 0, canvas.width, canvas.height)
      if (reduce) draw(0)
    }
    const ro = new ResizeObserver(size); ro.observe(host); size()
    const move = (e: PointerEvent) => { const b = host.getBoundingClientRect(); tgt.x = (e.clientX - b.left) / b.width; tgt.y = 1 - (e.clientY - b.top) / b.height }
    host.addEventListener('pointermove', move)
    let visible = true
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting }); io.observe(host)
    let raf = 0
    const loop = (now: number) => { raf = requestAnimationFrame(loop); if (visible && !document.hidden) draw(now) }
    if (!reduce) raf = requestAnimationFrame(loop)
    canvas.style.opacity = '1'
    return () => { cancelAnimationFrame(raf); ro.disconnect(); io.disconnect(); host.removeEventListener('pointermove', move); gl.getExtension('WEBGL_lose_context')?.loseContext() }
  }, [])
  return <canvas ref={ref} aria-hidden className="absolute inset-0 h-full w-full opacity-0 transition-opacity duration-700" />
}
