'use client'

import { useEffect, useState } from 'react'
import { Plus, Trash2, Loader2, X, Tag, Percent, DollarSign, Calendar, Copy, Power } from 'lucide-react'
import { api, type ApiPromoCode } from '@/lib/api'
import { formatTZS } from '@/lib/format'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

export function AdminPromos() {
  const [codes, setCodes] = useState<ApiPromoCode[]>([])
  const [loading, setLoading] = useState(true)
  const [adding, setAdding] = useState(false)

  const load = () => {
    setLoading(true)
    api.promoCodes().then((d) => setCodes(d.codes)).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const toggle = async (c: ApiPromoCode) => {
    try {
      await api.updatePromo(c.id, { active: !c.active })
      toast.success(`Code ${c.code} ${c.active ? 'disabled' : 'enabled'}`)
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const del = async (c: ApiPromoCode) => {
    if (!confirm(`Delete code "${c.code}"?`)) return
    try {
      await api.deletePromo(c.id)
      toast.success('Promo code deleted')
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const copy = (code: string) => {
    navigator.clipboard?.writeText(code)
    toast.success(`Copied "${code}"`)
  }

  return (
    <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-display text-base font-bold flex items-center gap-2">
            <Tag className="h-4 w-4 text-coral" /> Promo codes
          </h3>
          <p className="text-xs text-muted-foreground">Discount codes customers can apply at checkout.</p>
        </div>
        <button onClick={() => setAdding(true)} className="inline-flex items-center gap-1.5 rounded-full bg-brand text-primary-foreground px-4 py-2 text-xs font-bold hover:opacity-95 transition">
          <Plus className="h-3.5 w-3.5" /> New code
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
      ) : codes.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-8">No promo codes yet. Create one to offer discounts.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {codes.map((c) => {
            const expired = c.expiresAt && new Date(c.expiresAt) < new Date()
            const exhausted = c.usageLimit > 0 && c.usedCount >= c.usageLimit
            const dim = !c.active || expired || exhausted
            return (
              <div key={c.id} className={cn('rounded-xl border p-3.5 transition', dim ? 'border-border/50 bg-muted/20 opacity-70' : 'border-border/60 bg-background hover:border-brand/40')}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <button onClick={() => copy(c.code)} className="group inline-flex items-center gap-1.5">
                      <span className="font-mono font-bold text-brand text-base tracking-wide">{c.code}</span>
                      <Copy className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition" />
                    </button>
                    <div className="mt-0.5 text-xs text-muted-foreground">{c.description || 'No description'}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button onClick={() => toggle(c)} className={cn('grid h-7 w-7 place-items-center rounded-lg transition', c.active ? 'text-leaf hover:bg-leaf/10' : 'text-muted-foreground hover:bg-accent/40')} aria-label="toggle">
                      <Power className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => del(c)} className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition" aria-label="delete">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[11px]">
                  <span className={cn('inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-bold', c.type === 'percentage' ? 'bg-coral/15 text-coral' : 'bg-brand/10 text-brand')}>
                    {c.type === 'percentage' ? <><Percent className="h-3 w-3" />{c.value}% off</> : <><DollarSign className="h-3 w-3" />{formatTZS(c.value)} off</>}
                  </span>
                  {c.minOrder > 0 && <span className="text-muted-foreground">min {formatTZS(c.minOrder)}</span>}
                  {c.maxDiscount > 0 && c.type === 'percentage' && <span className="text-muted-foreground">max {formatTZS(c.maxDiscount)}</span>}
                  {c.usageLimit > 0 ? (
                    <span className="text-muted-foreground">{c.usedCount}/{c.usageLimit} used</span>
                  ) : (
                    <span className="text-muted-foreground">{c.usedCount} used</span>
                  )}
                  {c.expiresAt && (
                    <span className={cn('inline-flex items-center gap-1', expired ? 'text-destructive' : 'text-muted-foreground')}>
                      <Calendar className="h-3 w-3" /> {new Date(c.expiresAt).toLocaleDateString()}
                    </span>
                  )}
                  {expired && <span className="text-destructive font-bold">EXPIRED</span>}
                  {exhausted && !expired && <span className="text-amber-600 font-bold">EXHAUSTED</span>}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {adding && <PromoEditor onClose={() => setAdding(false)} onSaved={() => { setAdding(false); load() }} />}
    </div>
  )
}

function PromoEditor({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [code, setCode] = useState('')
  const [description, setDescription] = useState('')
  const [type, setType] = useState<'percentage' | 'fixed'>('percentage')
  const [value, setValue] = useState(10)
  const [minOrder, setMinOrder] = useState(0)
  const [maxDiscount, setMaxDiscount] = useState(0)
  const [usageLimit, setUsageLimit] = useState(0)
  const [expiresAt, setExpiresAt] = useState('')
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    if (!code.trim()) { toast.error('Enter a code'); return }
    setSaving(true)
    try {
      await api.createPromo({
        code: code.trim(),
        description: description.trim(),
        type,
        value: Number(value),
        minOrder: Number(minOrder),
        maxDiscount: Number(maxDiscount),
        usageLimit: Number(usageLimit),
        active: true,
        expiresAt: expiresAt || undefined,
      } as Partial<ApiPromoCode>)
      toast.success('Promo code created')
      onSaved()
    } catch (e) {
      toast.error((e as Error).message)
      setSaving(false)
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md max-h-[92vh] overflow-y-auto scrollbar-thin rounded-3xl">
        <DialogTitle className="sr-only">New promo code</DialogTitle>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold flex items-center gap-2"><Tag className="h-5 w-5 text-coral" /> New promo code</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent/40"><X className="h-4 w-4" /></button>
        </div>

        <div className="mt-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Code *</label>
            <input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm font-mono font-bold uppercase outline-none focus:border-brand/50" placeholder="MWANI10" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Description</label>
            <input value={description} onChange={(e) => setDescription(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="10% off your first order" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Discount type</label>
            <div className="mt-1 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setType('percentage')} className={cn('rounded-xl border p-3 text-left transition', type === 'percentage' ? 'border-brand bg-brand/5' : 'border-border/60 hover:border-brand/40')}>
                <Percent className={cn('h-4 w-4', type === 'percentage' ? 'text-brand' : 'text-muted-foreground')} />
                <div className="text-xs font-bold mt-1">Percentage</div>
                <div className="text-[10px] text-muted-foreground">e.g. 10% off</div>
              </button>
              <button type="button" onClick={() => setType('fixed')} className={cn('rounded-xl border p-3 text-left transition', type === 'fixed' ? 'border-brand bg-brand/5' : 'border-border/60 hover:border-brand/40')}>
                <DollarSign className={cn('h-4 w-4', type === 'fixed' ? 'text-brand' : 'text-muted-foreground')} />
                <div className="text-xs font-bold mt-1">Fixed amount</div>
                <div className="text-[10px] text-muted-foreground">e.g. TSh 5,000 off</div>
              </button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground">{type === 'percentage' ? 'Percentage (%) *' : 'Amount (TSh) *'}</label>
              <input type="number" value={value} onChange={(e) => setValue(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Min order (TSh)</label>
              <input type="number" value={minOrder} onChange={(e) => setMinOrder(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
          </div>
          {type === 'percentage' && (
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Max discount cap (TSh, 0 = none)</label>
              <input type="number" value={maxDiscount} onChange={(e) => setMaxDiscount(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Usage limit (0 = unlimited)</label>
              <input type="number" value={usageLimit} onChange={(e) => setUsageLimit(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Expiry date</label>
              <input type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button onClick={onClose} className="rounded-full border border-border/70 px-5 py-2.5 text-sm font-semibold hover:bg-accent/40 transition">Cancel</button>
          <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-glow hover:opacity-95 transition disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Create code
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
