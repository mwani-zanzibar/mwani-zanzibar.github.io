'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { Search, Loader2, MessageCircle, X, Phone, MapPin, Ship, Store, Clock, Filter, CheckCircle2, DollarSign, Download, FileText, CalendarClock } from 'lucide-react'
import { api, type ApiOrder } from '@/lib/api'
import { formatTZS, statusLabel, statusOrder, normalizePhone, whatsappLink, toCSV, downloadCSV, deliveryEta } from '@/lib/format'
import { openInvoice } from '@/lib/invoice'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

const STATUSES = statusOrder().concat(['cancelled'])

function statusColor(s: string) {
  const m: Record<string, string> = {
    pending: 'bg-amber-500/15 text-amber-600',
    confirmed: 'bg-blue-500/15 text-blue-600',
    processing: 'bg-turquoise/15 text-turquoise',
    shipped: 'bg-brand/15 text-brand',
    ready_for_pickup: 'bg-coral/15 text-coral',
    delivered: 'bg-leaf/15 text-leaf',
    cancelled: 'bg-destructive/15 text-destructive',
  }
  return m[s] || 'bg-muted text-muted-foreground'
}

export function AdminOrders() {
  const [orders, setOrders] = useState<ApiOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [q, setQ] = useState('')
  const [selected, setSelected] = useState<ApiOrder | null>(null)

  const load = () => {
    setLoading(true)
    api.orders().then((d) => setOrders(d.orders)).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const filtered = orders.filter((o) => {
    if (filter !== 'all' && o.status !== filter) return false
    if (q.trim()) {
      const s = q.toLowerCase()
      return o.orderNumber.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s) || o.customerPhone.includes(s)
    }
    return true
  })

  const exportCSV = () => {
    if (filtered.length === 0) { toast.error('No orders to export'); return }
    const csv = toCSV(
      ['Order #', 'Date', 'Customer', 'Phone', 'Location', 'Channel', 'Items', 'Subtotal', 'Shipping', 'Total', 'Status', 'Payment'],
      filtered.map((o) => [
        o.orderNumber,
        new Date(o.createdAt).toLocaleString(),
        o.customerName,
        o.customerPhone,
        o.customerLocation,
        o.deliveryChannel,
        o.items.map((i) => `${i.qty}x ${i.name}`).join(' | '),
        o.subtotal,
        o.shipping,
        o.total,
        statusLabel(o.status),
        o.paymentStatus,
      ])
    )
    downloadCSV(`mwani-orders-${new Date().toISOString().slice(0, 10)}.csv`, csv)
    toast.success(`Exported ${filtered.length} orders`)
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search order #, name, phone…" className="w-full rounded-full border border-border/70 bg-background pl-10 pr-4 py-2.5 text-sm outline-none focus:border-brand/50" />
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-thin pb-1">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          <button onClick={() => setFilter('all')} className={cn('rounded-full px-3 py-1.5 text-xs font-semibold whitespace-nowrap', filter === 'all' ? 'bg-brand text-primary-foreground' : 'bg-background border border-border/60 text-muted-foreground hover:text-foreground')}>All</button>
          {STATUSES.map((s) => (
            <button key={s} onClick={() => setFilter(s)} className={cn('rounded-full px-3 py-1.5 text-xs font-semibold whitespace-nowrap capitalize', filter === s ? 'bg-brand text-primary-foreground' : 'bg-background border border-border/60 text-muted-foreground hover:text-foreground')}>{statusLabel(s)}</button>
          ))}
          <button onClick={exportCSV} className="ml-1 inline-flex items-center gap-1.5 rounded-full bg-leaf/15 text-leaf border border-leaf/30 px-3 py-1.5 text-xs font-semibold whitespace-nowrap hover:bg-leaf/25 transition">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
        </div>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Clock className="h-10 w-10 text-muted-foreground/40 mx-auto" />
          <p className="mt-3 text-sm text-muted-foreground">No orders found.</p>
        </div>
      ) : (
        <div className="grid gap-3">
          {filtered.map((o) => (
            <button key={o.id} onClick={() => setSelected(o)} className="text-left rounded-2xl border border-border/60 bg-card p-4 hover:shadow-soft hover:border-brand/30 transition-all">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand">
                    <Store className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="font-mono font-bold text-brand">{o.orderNumber}</div>
                    <div className="text-xs text-muted-foreground">{o.customerName} · {new Date(o.createdAt).toLocaleString()}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold', statusColor(o.status))}>{statusLabel(o.status)}</span>
                  <span className={cn('inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-bold', o.paymentStatus === 'paid' ? 'bg-leaf/15 text-leaf' : 'bg-amber-500/15 text-amber-600')}>{o.paymentStatus === 'paid' ? 'Paid' : 'Unpaid'}</span>
                  <span className="font-display font-bold text-brand">{formatTZS(o.total)}</span>
                </div>
              </div>
              <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" /> {o.customerLocation}
                <span className="mx-1">·</span>
                {o.deliveryChannel === 'ferry' ? <><Ship className="h-3.5 w-3.5" /> Azam Ferry</> : o.deliveryChannel === 'pickup' ? <><Store className="h-3.5 w-3.5" /> Pickup</> : <><Store className="h-3.5 w-3.5" /> Local</>}
                <span className="mx-1">·</span>
                <Phone className="h-3.5 w-3.5" /> {o.customerPhone}
              </div>
            </button>
          ))}
        </div>
      )}

      {selected && <OrderDetail order={selected} onClose={() => setSelected(null)} onUpdated={(o) => { setSelected(o); load() }} />}
    </div>
  )
}

function OrderDetail({ order, onClose, onUpdated }: { order: ApiOrder; onClose: () => void; onUpdated: (o: ApiOrder) => void }) {
  const [updating, setUpdating] = useState(false)

  const update = async (status?: string, paymentStatus?: string) => {
    setUpdating(true)
    try {
      const body: Record<string, unknown> = {}
      if (status) body.status = status
      if (paymentStatus) body.paymentStatus = paymentStatus
      const r = await api.updateOrder(order.id, body)
      onUpdated(r)
      toast.success(status ? `Order marked as ${statusLabel(status)}` : `Payment ${paymentStatus}`)
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setUpdating(false)
    }
  }

  const channelLabel = order.deliveryChannel === 'ferry' ? 'Azam Ferry (Mainland)' : order.deliveryChannel === 'pickup' ? 'Pickup in Zanzibar' : 'Local delivery Zanzibar'

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto scrollbar-thin rounded-3xl">
        <DialogTitle className="sr-only">Order detail</DialogTitle>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-mono font-bold text-lg text-brand">{order.orderNumber}</h2>
            <p className="text-xs text-muted-foreground">{new Date(order.createdAt).toLocaleString()}</p>
          </div>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent/40"><X className="h-4 w-4" /></button>
        </div>

        {/* Customer */}
        <div className="mt-4 rounded-2xl bg-sand/40 border border-border/50 p-4 space-y-2 text-sm">
          <div className="flex items-start gap-2"><span className="font-semibold w-20 text-muted-foreground">Name</span><span>{order.customerName}</span></div>
          <div className="flex items-start gap-2"><span className="font-semibold w-20 text-muted-foreground">Phone</span><span>{order.customerPhone}</span></div>
          <div className="flex items-start gap-2"><span className="font-semibold w-20 text-muted-foreground">Location</span><span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5 text-coral" /> {order.customerLocation}</span></div>
          <div className="flex items-start gap-2"><span className="font-semibold w-20 text-muted-foreground">Delivery</span><span>{channelLabel}</span></div>
          {order.notes && <div className="flex items-start gap-2"><span className="font-semibold w-20 text-muted-foreground">Notes</span><span className="italic">{order.notes}</span></div>}
        </div>

        {/* ETA */}
        {(() => {
          const eta = deliveryEta(order.deliveryChannel, order.status, order.createdAt)
          if (!eta) return null
          const toneCls = eta.tone === 'green' ? 'bg-leaf/15 text-leaf border-leaf/30'
            : eta.tone === 'blue' ? 'bg-turquoise/15 text-turquoise border-turquoise/30'
            : eta.tone === 'amber' ? 'bg-amber-500/15 text-amber-700 border-amber-500/30'
            : 'bg-muted text-muted-foreground border-border/50'
          return (
            <div className={`mt-2 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-bold ${toneCls}`}>
              <CalendarClock className="h-3.5 w-3.5" /> {eta.label}
            </div>
          )
        })()}

        {/* Items */}
        <div className="mt-4 rounded-2xl border border-border/60 divide-y divide-border/50">
          {order.items.map((it) => (
            <div key={it.productId} className="flex items-center gap-3 p-3">
              <div className="relative h-12 w-12 rounded-lg overflow-hidden bg-muted/30 shrink-0">
                <Image src={it.image} alt={it.name} fill className="object-cover" sizes="48px" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold line-clamp-1">{it.name}</div>
                <div className="text-[11px] text-muted-foreground">{it.qty} × {formatTZS(it.price)}</div>
              </div>
              <div className="font-bold text-brand">{formatTZS(it.price * it.qty)}</div>
            </div>
          ))}
          <div className="p-3 space-y-1 text-sm bg-sand/30">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatTZS(order.subtotal)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>{order.shipping > 0 ? formatTZS(order.shipping) : '—'}</span></div>
            {order.discount > 0 && (
              <div className="flex justify-between text-leaf"><span className="text-muted-foreground">Discount ({order.promoCode})</span><span>−{formatTZS(order.discount)}</span></div>
            )}
            <div className="flex justify-between pt-1 border-t border-border/50"><span className="font-bold">Total</span><span className="font-display text-lg font-bold text-brand">{formatTZS(order.total)}</span></div>
          </div>
        </div>

        {/* Status control */}
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold">Update status</h3>
            <button onClick={() => update(undefined, order.paymentStatus === 'paid' ? 'unpaid' : 'paid')} className={cn('inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition', order.paymentStatus === 'paid' ? 'bg-leaf text-white' : 'bg-amber-500 text-white')}>
              <DollarSign className="h-3.5 w-3.5" /> {order.paymentStatus === 'paid' ? 'Mark unpaid' : 'Mark paid'}
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {STATUSES.map((s) => (
              <button
                key={s}
                disabled={updating}
                onClick={() => update(s)}
                className={cn('rounded-full px-3 py-1.5 text-xs font-semibold border transition', order.status === s ? 'bg-brand text-primary-foreground border-brand' : 'bg-background border-border/60 text-muted-foreground hover:text-foreground hover:border-brand/40')}
              >
                {statusLabel(s)}
              </button>
            ))}
          </div>
          {order.status === 'cancelled' && (
            <p className="mt-2 text-xs text-destructive">Order is cancelled.</p>
          )
          }
        </div>

        {/* Status history */}
        <div className="mt-4">
          <h3 className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Status history</h3>
          <ul className="mt-2 space-y-1.5">
            {order.statusHistory.map((h, i) => (
              <li key={i} className="flex items-start gap-2 text-xs">
                <CheckCircle2 className="h-3.5 w-3.5 text-brand mt-0.5 shrink-0" />
                <div>
                  <span className="font-semibold">{statusLabel(h.status)}</span>
                  <span className="text-muted-foreground"> · {new Date(h.at).toLocaleString()}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact customer */}
        <div className="mt-5 flex flex-wrap gap-2">
          <a
            href={whatsappLink(order.customerPhone, `Habari ${order.customerName}! Kuhusu order yako ${order.orderNumber} ya Mwani Zanzibar Seaweed...`)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-[#25D366] text-white px-4 py-2.5 text-xs font-bold hover:brightness-105"
          >
            <MessageCircle className="h-4 w-4" /> WhatsApp customer
          </a>
          <a href={`tel:${order.customerPhone.replace(/\s/g, '')}`} className="inline-flex items-center gap-2 rounded-full border border-border/70 px-4 py-2.5 text-xs font-bold hover:bg-accent/40">
            <Phone className="h-4 w-4" /> Call
          </a>
          <button
            onClick={() => openInvoice(order, null)}
            className="inline-flex items-center gap-2 rounded-full bg-brand/10 text-brand border border-brand/25 px-4 py-2.5 text-xs font-bold hover:bg-brand/20 transition"
          >
            <FileText className="h-4 w-4" /> Invoice / Receipt
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
