'use client'

import { useEffect, useState } from 'react'
import { Star, Check, X, Trash2, Loader2, MapPin, CheckCircle2, Clock } from 'lucide-react'
import { api, type ApiReview, type ApiProduct } from '@/lib/api'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

export function AdminReviews() {
  const [reviews, setReviews] = useState<ApiReview[]>([])
  const [products, setProducts] = useState<ApiProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'pending' | 'approved'>('pending')

  const load = () => {
    setLoading(true)
    Promise.all([
      api.allReviews(),
      api.products({ admin: '1' }),
    ]).then(([d, p]) => {
      setReviews((d as { reviews: ApiReview[] }).reviews)
      setProducts(p.products)
    }).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const productName = (id: string) => products.find((p) => p.id === id)?.name || 'Unknown product'

  const approve = async (r: ApiReview, approved: boolean) => {
    try {
      await api.approveReview(r.id, approved)
      toast.success(approved ? 'Review approved' : 'Review hidden')
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const del = async (r: ApiReview) => {
    if (!confirm('Delete this review?')) return
    try {
      await api.deleteReview(r.id)
      toast.success('Review deleted')
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const pending = reviews.filter((r) => !r.approved)
  const approved = reviews.filter((r) => r.approved)
  const shown = tab === 'pending' ? pending : approved

  return (
    <div className="space-y-4">
      <div className="inline-flex rounded-full bg-muted/60 p-1 text-xs font-semibold">
        <button onClick={() => setTab('pending')} className={cn('relative inline-flex items-center gap-1.5 rounded-full px-4 py-1.5', tab === 'pending' ? 'text-primary-foreground' : 'text-muted-foreground')}>
          {tab === 'pending' && <span className="absolute inset-0 rounded-full bg-brand" />}
          <Clock className="relative h-3.5 w-3.5" /> Pending ({pending.length})
        </button>
        <button onClick={() => setTab('approved')} className={cn('relative inline-flex items-center gap-1.5 rounded-full px-4 py-1.5', tab === 'approved' ? 'text-primary-foreground' : 'text-muted-foreground')}>
          {tab === 'approved' && <span className="absolute inset-0 rounded-full bg-brand" />}
          <CheckCircle2 className="relative h-3.5 w-3.5" /> Approved ({approved.length})
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : shown.length === 0 ? (
        <div className="text-center py-16">
          <Star className="h-10 w-10 text-muted-foreground/40 mx-auto" />
          <p className="mt-3 text-sm text-muted-foreground">{tab === 'pending' ? 'No pending reviews.' : 'No approved reviews yet.'}</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {shown.map((r) => (
            <div key={r.id} className="rounded-2xl border border-border/60 bg-card p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wide text-brand">{productName(r.productId)}</div>
                  <div className="mt-1 flex items-center gap-2">
                    <div className="grid h-8 w-8 place-items-center rounded-full bg-brand/10 text-brand font-bold text-xs">{r.name.charAt(0).toUpperCase()}</div>
                    <div>
                      <div className="text-sm font-bold">{r.name}</div>
                      <div className="flex items-center gap-1 text-[11px] text-muted-foreground"><MapPin className="h-3 w-3" />{r.location}</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={cn('h-3.5 w-3.5', i < r.rating ? 'fill-coral text-coral' : 'text-muted-foreground/30')} />
                  ))}
                </div>
              </div>
              <p className="mt-3 text-sm text-foreground/85 leading-relaxed">{r.comment}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">{new Date(r.createdAt).toLocaleDateString()}</span>
                <div className="flex items-center gap-1.5">
                  {!r.approved && (
                    <button onClick={() => approve(r, true)} className="inline-flex items-center gap-1 rounded-full bg-leaf text-white px-3 py-1.5 text-xs font-bold hover:opacity-90 transition">
                      <Check className="h-3.5 w-3.5" /> Approve
                    </button>
                  )}
                  {r.approved && (
                    <button onClick={() => approve(r, false)} className="inline-flex items-center gap-1 rounded-full border border-border/70 px-3 py-1.5 text-xs font-bold hover:bg-accent/40 transition">
                      <X className="h-3.5 w-3.5" /> Hide
                    </button>
                  )}
                  <button onClick={() => del(r)} className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
