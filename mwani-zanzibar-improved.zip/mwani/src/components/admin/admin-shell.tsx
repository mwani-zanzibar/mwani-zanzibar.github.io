'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import {
  LayoutDashboard, Package, ClipboardList, ShoppingBag, Star, Settings,
  LogOut, Store, Menu, X, ExternalLink, Mail, ChefHat, PenLine,
} from 'lucide-react'
import { AdminContent } from '@/components/admin/admin-content'
import { ThemeToggle } from '@/components/shared/theme-toggle'
import { AdminDashboard } from '@/components/admin/admin-dashboard'
import { AdminProducts } from '@/components/admin/admin-products'
import { AdminOrders } from '@/components/admin/admin-orders'
import { AdminSales } from '@/components/admin/admin-sales'
import { AdminReviews } from '@/components/admin/admin-reviews'
import { AdminRecipes } from '@/components/admin/admin-recipes'
import { AdminSubscribers } from '@/components/admin/admin-subscribers'
import { AdminSettings } from '@/components/admin/admin-settings'
import { cn } from '@/lib/utils'
import { motion, AnimatePresence } from 'framer-motion'

type Tab = 'dashboard' | 'products' | 'orders' | 'sales' | 'recipes' | 'content' | 'reviews' | 'subscribers' | 'settings'

const nav: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'products', label: 'Products', icon: Package },
  { id: 'orders', label: 'Orders', icon: ClipboardList },
  { id: 'sales', label: 'Sales Records', icon: ShoppingBag },
  { id: 'recipes', label: 'Recipes', icon: ChefHat },
  { id: 'content', label: 'Site content', icon: PenLine },
  { id: 'reviews', label: 'Reviews', icon: Star },
  { id: 'subscribers', label: 'Subscribers', icon: Mail },
  { id: 'settings', label: 'Settings', icon: Settings },
]

export function AdminShell({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<Tab>('dashboard')
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const read = () => {
      const h = location.hash.replace('#', '')
      if (h && nav.some((n) => n.id === h)) setTab(h as Tab)
    }
    read()
    window.addEventListener('hashchange', read)
    return () => window.removeEventListener('hashchange', read)
  }, [])

  useEffect(() => {
    history.replaceState(null, '', `#${tab}`)
  }, [tab])

  return (
    <div className="min-h-screen bg-sand/30 flex">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-72 bg-sidebar border-r border-sidebar-border flex flex-col transition-transform duration-300 lg:translate-x-0',
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="p-5 border-b border-sidebar-border flex items-center gap-3">
          <div className="relative h-11 w-11 rounded-full bg-surface shadow overflow-hidden ring-1 ring-border/60">
            <Image src="/brand/mwani-mark.png" alt="Mwani" fill className="object-contain p-1.5" sizes="44px" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-sm font-bold leading-tight text-sidebar-foreground">Mwani Admin</div>
            <div className="text-[11px] text-muted-foreground truncate">Wakulima Hai Co-op</div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto scrollbar-thin">
          {nav.map((n) => (
            <button
              key={n.id}
              onClick={() => { setTab(n.id); setMobileOpen(false) }}
              className={cn(
                'relative w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors group',
                tab === n.id ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-soft' : 'text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent'
              )}
            >
              <n.icon className="h-4 w-4 shrink-0" />
              {n.label}
              {tab === n.id && (
                <motion.span layoutId="admin-active" className="absolute right-3 h-1.5 w-1.5 rounded-full bg-coral" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-sidebar-border space-y-1">
          <a
            href="./"
            className="w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-muted-foreground hover:text-sidebar-foreground hover:bg-sidebar-accent transition-colors"
          >
            <Store className="h-4 w-4" /> View store <ExternalLink className="h-3 w-3 ml-auto" />
          </a>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 lg:ml-72 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 glass-strong border-b border-border/60">
          <div className="px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button onClick={() => setMobileOpen(true)} className="lg:hidden grid h-9 w-9 place-items-center rounded-full border border-border/60 bg-background/60">
                <Menu className="h-4 w-4" />
              </button>
              <div>
                <h1 className="font-display text-lg font-bold capitalize leading-none">{nav.find((n) => n.id === tab)?.label}</h1>
                <p className="text-[11px] text-muted-foreground mt-0.5">Manage your seaweed business</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <a href="./" target="_blank" className="hidden sm:inline-flex items-center gap-1.5 rounded-full border border-border/60 px-3 py-1.5 text-xs font-semibold text-muted-foreground hover:text-foreground">
                <ExternalLink className="h-3.5 w-3.5" /> Store
              </a>
              <ThemeToggle />
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
            >
              {tab === 'dashboard' && <AdminDashboard />}
              {tab === 'products' && <AdminProducts />}
              {tab === 'orders' && <AdminOrders />}
              {tab === 'sales' && <AdminSales />}
              {tab === 'reviews' && <AdminReviews />}
              {tab === 'recipes' && <AdminRecipes />}
              {tab === 'content' && <AdminContent />}
              {tab === 'subscribers' && <AdminSubscribers />}
              {tab === 'settings' && <AdminSettings />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
