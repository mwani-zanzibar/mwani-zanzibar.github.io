'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { Plus, Search, Pencil, Trash2, Loader2, Star, Eye, EyeOff, X, Package, Upload, ImagePlus, FileText } from 'lucide-react'
import { api, type ApiProduct } from '@/lib/api'
import { formatTZS, slugify } from '@/lib/format'
import { openCatalog } from '@/lib/catalog'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { motion, AnimatePresence } from 'framer-motion'

const CATEGORIES = ['Food & Beverage', 'Health & Wellness', 'Skin Care', 'Hair Care', 'Soap', 'Other']

type EditorState = {
  id?: string
  name: string
  tagline: string
  description: string
  price: number
  unit: string
  category: string
  image: string
  gallery: string[]
  benefits: string[]
  ingredients: string[]
  howToUse: string
  stock: number
  lowStockThreshold: number
  featured: boolean
  active: boolean
}

const blank: EditorState = {
  name: '', tagline: '', description: '', price: 0, unit: 'each', category: 'Food & Beverage',
  image: '/products/powder-cut.webp', gallery: [], benefits: [], ingredients: [], howToUse: '', stock: 0, lowStockThreshold: 5, featured: false, active: true,
}

export function AdminProducts() {
  const [products, setProducts] = useState<ApiProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [editing, setEditing] = useState<EditorState | null>(null)

  const load = () => {
    setLoading(true)
    api.products({ admin: '1' }).then((d) => setProducts(d.products)).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const filtered = products.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase()))

  const save = async (e: EditorState) => {
    try {
      if (e.id) {
        await api.updateProduct(e.id, e)
      } else {
        await api.createProduct(e)
      }
      toast.success(e.id ? 'Product updated' : 'Product created')
      setEditing(null)
      load()
    } catch (err) {
      toast.error((err as Error).message)
    }
  }

  const del = async (p: ApiProduct) => {
    if (!confirm(`Delete "${p.name}"? This cannot be undone.`)) return
    try {
      await api.deleteProduct(p.id)
      toast.success('Product deleted')
      load()
    } catch (err) {
      toast.error((err as Error).message)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products…"
            className="w-full rounded-full border border-border/70 bg-background pl-10 pr-4 py-2.5 text-sm outline-none focus:border-brand/50"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => openCatalog(products, null)}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-leaf/15 text-leaf border border-leaf/30 px-4 py-2.5 text-sm font-bold hover:bg-leaf/25 transition"
          >
            <FileText className="h-4 w-4" /> Price list
          </button>
          <button
            onClick={() => setEditing({ ...blank })}
            className="inline-flex items-center justify-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-soft hover:opacity-95 transition"
          >
            <Plus className="h-4 w-4" /> Add product
          </button>
        </div>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20">
          <Loader2 className="h-6 w-6 animate-spin text-brand" />
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <div className="hidden lg:block rounded-2xl border border-border/60 bg-card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-sand/40 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="text-left font-semibold px-4 py-3">Product</th>
                  <th className="text-left font-semibold px-4 py-3">Category</th>
                  <th className="text-right font-semibold px-4 py-3">Price</th>
                  <th className="text-center font-semibold px-4 py-3">Stock</th>
                  <th className="text-center font-semibold px-4 py-3">Featured</th>
                  <th className="text-center font-semibold px-4 py-3">Active</th>
                  <th className="text-right font-semibold px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {filtered.map((p) => (
                  <tr key={p.id} className="hover:bg-sand/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="relative h-11 w-11 rounded-lg overflow-hidden bg-muted/30 shrink-0">
                          <Image src={p.image} alt={p.name} fill className="object-cover" sizes="44px" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold line-clamp-1">{p.name}</div>
                          <div className="text-[11px] text-muted-foreground">{p.unit}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{p.category}</td>
                    <td className="px-4 py-3 text-right font-bold text-brand">{formatTZS(p.price)}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold ${p.stock <= 0 ? 'bg-destructive/15 text-destructive' : p.stock <= p.lowStockThreshold ? 'bg-amber-500/15 text-amber-600' : 'bg-leaf/15 text-leaf'}`}>
                        {p.stock}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {p.featured ? <Star className="h-4 w-4 text-coral fill-coral inline" /> : <span className="text-muted-foreground/40">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {p.active ? <Eye className="h-4 w-4 text-leaf inline" /> : <EyeOff className="h-4 w-4 text-muted-foreground inline" />}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => setEditing({ id: p.id, name: p.name, tagline: p.tagline, description: p.description, price: p.price, unit: p.unit, category: p.category, image: p.image, gallery: p.gallery || [], benefits: p.benefits, ingredients: p.ingredients, howToUse: p.howToUse, stock: p.stock, lowStockThreshold: p.lowStockThreshold, featured: p.featured, active: p.active })} className="grid h-8 w-8 place-items-center rounded-lg hover:bg-accent/40 transition" aria-label="edit">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button onClick={() => del(p)} className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition" aria-label="delete">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="lg:hidden grid sm:grid-cols-2 gap-3">
            {filtered.map((p) => (
              <div key={p.id} className="rounded-2xl border border-border/60 bg-card p-4">
                <div className="flex items-center gap-3">
                  <div className="relative h-12 w-12 rounded-lg overflow-hidden bg-muted/30 shrink-0">
                    <Image src={p.image} alt={p.name} fill className="object-cover" sizes="48px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold line-clamp-1 text-sm">{p.name}</div>
                    <div className="text-[11px] text-muted-foreground">{p.category}</div>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="font-bold text-brand">{formatTZS(p.price)}</div>
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-bold ${p.stock <= 0 ? 'bg-destructive/15 text-destructive' : p.stock <= p.lowStockThreshold ? 'bg-amber-500/15 text-amber-600' : 'bg-leaf/15 text-leaf'}`}>
                    Stock {p.stock}
                  </span>
                </div>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => setEditing({ id: p.id, name: p.name, tagline: p.tagline, description: p.description, price: p.price, unit: p.unit, category: p.category, image: p.image, gallery: p.gallery || [], benefits: p.benefits, ingredients: p.ingredients, howToUse: p.howToUse, stock: p.stock, lowStockThreshold: p.lowStockThreshold, featured: p.featured, active: p.active })} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-brand/10 text-brand py-2 text-xs font-bold hover:bg-brand/20 transition">
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </button>
                  <button onClick={() => del(p)} className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-destructive/10 text-destructive px-3 py-2 text-xs font-bold hover:bg-destructive/20 transition">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16">
              <Package className="h-10 w-10 text-muted-foreground/40 mx-auto" />
              <p className="mt-3 text-sm text-muted-foreground">No products found.</p>
            </div>
          )}
        </>
      )}

      <AnimatePresence>
        {editing && (
          <ProductEditor
            key={editing.id || 'new'}
            initial={editing}
            onClose={() => setEditing(null)}
            onSave={save}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

function ProductEditor({ initial, onClose, onSave }: { initial: EditorState; onClose: () => void; onSave: (e: EditorState) => void }) {
  const [f, setF] = useState<EditorState>(initial)
  const [benefitsStr, setBenefitsStr] = useState(initial.benefits.join('\n'))
  const [ingredientsStr, setIngredientsStr] = useState(initial.ingredients.join('\n'))
  const [saving, setSaving] = useState(false)

  const submit = async () => {
    if (!f.name.trim() || !f.description.trim() || !f.category) {
      toast.error('Name, description and category are required.')
      return
    }
    setSaving(true)
    const payload: EditorState = {
      ...f,
      price: Number(f.price) || 0,
      stock: Number(f.stock) || 0,
      lowStockThreshold: Number(f.lowStockThreshold) || 5,
      benefits: benefitsStr.split('\n').map((s) => s.trim()).filter(Boolean),
      ingredients: ingredientsStr.split('\n').map((s) => s.trim()).filter(Boolean),
    }
    await onSave(payload)
    setSaving(false)
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto scrollbar-thin rounded-3xl">
        <DialogTitle className="sr-only">{f.id ? 'Edit product' : 'New product'}</DialogTitle>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">{f.id ? 'Edit product' : 'New product'}</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent/40"><X className="h-4 w-4" /></button>
        </div>

        <div className="mt-3 grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2 flex gap-4">
            <div className="relative h-20 w-20 rounded-xl overflow-hidden bg-muted/30 shrink-0 ring-1 ring-border/60">
              <Image src={f.image} alt="preview" fill className="object-cover" sizes="80px" />
            </div>
            <div className="flex-1">
              <label className="text-xs font-semibold text-muted-foreground">Main image</label>
              <div className="mt-1 flex gap-2">
                <input value={f.image} onChange={(e) => setF({ ...f, image: e.target.value })} className="flex-1 rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="/products/….jpg" />
                <ImageUploadBtn onUploaded={(url) => setF({ ...f, image: url })} />
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">Paste a path like /products/powder-cut.webp, or upload your own.</p>
            </div>
          </div>

          {/* Gallery */}
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Gallery images (optional)</label>
            <div className="mt-1.5 flex flex-wrap items-center gap-2">
              {f.gallery.map((g, i) => (
                <div key={i} className="relative h-16 w-16 rounded-lg overflow-hidden border border-border/60 group">
                  <Image src={g} alt={`gallery ${i + 1}`} fill className="object-cover" sizes="64px" />
                  <button
                    onClick={() => setF({ ...f, gallery: f.gallery.filter((_, j) => j !== i) })}
                    className="absolute top-0.5 right-0.5 grid h-5 w-5 place-items-center rounded-full bg-destructive text-white opacity-0 group-hover:opacity-100 transition"
                    aria-label="remove"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              <ImageUploadBtn
                compact
                onUploaded={(url) => setF({ ...f, gallery: [...f.gallery, url] })}
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">Add multiple photos — shown as a swipeable gallery on the product page.</p>
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground">Name *</label>
            <input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Category *</label>
            <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Tagline</label>
            <input value={f.tagline} onChange={(e) => setF({ ...f, tagline: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Description *</label>
            <textarea value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} rows={3} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Price (TSh) *</label>
            <input type="number" value={f.price} onChange={(e) => setF({ ...f, price: Number(e.target.value) })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Unit</label>
            <input value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="e.g. 200g pouch" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Stock</label>
            <input type="number" value={f.stock} onChange={(e) => setF({ ...f, stock: Number(e.target.value) })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Low stock threshold</label>
            <input type="number" value={f.lowStockThreshold} onChange={(e) => setF({ ...f, lowStockThreshold: Number(e.target.value) })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Benefits (one per line)</label>
            <textarea value={benefitsStr} onChange={(e) => setBenefitsStr(e.target.value)} rows={4} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" placeholder={'Rich in iodine\nSupports thyroid health'} />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Ingredients (one per line)</label>
            <textarea value={ingredientsStr} onChange={(e) => setIngredientsStr(e.target.value)} rows={3} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">How to use</label>
            <textarea value={f.howToUse} onChange={(e) => setF({ ...f, howToUse: e.target.value })} rows={2} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div className="sm:col-span-2 flex items-center gap-4">
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={f.featured} onChange={(e) => setF({ ...f, featured: e.target.checked })} className="h-4 w-4 accent-brand" />
              Featured (bestseller)
            </label>
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} className="h-4 w-4 accent-brand" />
              Active (visible in store)
            </label>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button onClick={onClose} className="rounded-full border border-border/70 px-5 py-2.5 text-sm font-semibold hover:bg-accent/40 transition">Cancel</button>
          <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-glow hover:opacity-95 transition disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {f.id ? 'Save changes' : 'Create product'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function ImageUploadBtn({ onUploaded, compact }: { onUploaded: (url: string) => void; compact?: boolean }) {
  const [uploading, setUploading] = useState(false)

  const handle = async (file: File | undefined) => {
    if (!file) return
    setUploading(true)
    try {
      const r = await api.upload(file)
      onUploaded(r.url)
      toast.success('Image uploaded')
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setUploading(false)
    }
  }

  if (compact) {
    return (
      <label className={`relative grid h-16 w-16 place-items-center rounded-lg border-2 border-dashed border-border/70 text-muted-foreground hover:border-brand/50 hover:text-brand transition cursor-pointer ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
        {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
        <input type="file" accept="image/*" className="hidden" onChange={(e) => handle(e.target.files?.[0])} />
      </label>
    )
  }

  return (
    <label className={`relative inline-flex items-center gap-1.5 rounded-xl bg-brand/10 text-brand px-3.5 py-2.5 text-xs font-bold hover:bg-brand/20 transition cursor-pointer ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
      {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
      Upload
      <input type="file" accept="image/*" className="hidden" onChange={(e) => handle(e.target.files?.[0])} />
    </label>
  )
}
