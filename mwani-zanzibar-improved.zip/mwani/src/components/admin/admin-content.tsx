'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { ChevronDown, ImagePlus, Loader2, RotateCcw, Save, Search, Type, Image as ImageIcon, Undo2 } from 'lucide-react'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { CONTENT_GROUPS } from '@/lib/content-keys'
import { IMAGE_SLOTS } from '@/lib/content-slots'
import { useContent } from '@/lib/content-store'
import { builtinString, type Lang } from '@/lib/i18n'
import { asset } from '@/lib/asset'
import type { SiteContent } from '@/lib/types'
import { cn } from '@/lib/utils'

type Tab = 'text' | 'images'

// Readable label from a key: "hx.powder.body" -> "Powder · body"
function labelOf(key: string) {
  const parts = key.split('.').slice(1)
  return parts.join(' · ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^\w/, (c) => c.toUpperCase()) || key
}
const varsIn = (s: string) => Array.from(new Set(s.match(/\{\w+\}/g) || []))

/**
 * Site content: every piece of text on the shop (English and Kiswahili) and
 * every section picture. Empty means "use the original".
 */
export function AdminContent() {
  const [tab, setTab] = useState<Tab>('text')
  const [lang, setLang] = useState<Lang>('en')
  const [q, setQ] = useState('')
  const [saved, setSaved] = useState<SiteContent>({ en: {}, sw: {}, img: {} })
  const [draft, setDraft] = useState<SiteContent>({ en: {}, sw: {}, img: {} })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({ Hero: true })

  useEffect(() => {
    api.settings().then(({ settings }) => {
      const c = settings.content ?? { en: {}, sw: {}, img: {} }
      setSaved(c); setDraft(JSON.parse(JSON.stringify(c)))
    }).finally(() => setLoading(false))
  }, [])

  const changes = useMemo(() => {
    const diff = (a: Record<string, string>, b: Record<string, string>) => {
      const keys = new Set([...Object.keys(a), ...Object.keys(b)])
      let n = 0
      keys.forEach((k) => { if ((a[k] || '') !== (b[k] || '')) n++ })
      return n
    }
    return diff(saved.en, draft.en) + diff(saved.sw, draft.sw) + diff(saved.img, draft.img)
  }, [saved, draft])

  const setText = (key: string, v: string) => setDraft((d) => ({ ...d, [lang]: { ...d[lang], [key]: v } }))
  const setImg = (slot: string, v: string) => setDraft((d) => ({ ...d, img: { ...d.img, [slot]: v } }))

  const save = async () => {
    setSaving(true)
    try {
      const imgPatch: Record<string, string | null> = {}
      const slots = new Set([...Object.keys(saved.img), ...Object.keys(draft.img)])
      slots.forEach((s) => { if ((saved.img[s] || '') !== (draft.img[s] || '')) imgPatch[s] = draft.img[s] || null })
      const next = await api.updateContent({ en: draft.en, sw: draft.sw, img: imgPatch })
      const c = next.content ?? { en: {}, sw: {}, img: {} }
      setSaved(c); setDraft(JSON.parse(JSON.stringify(c)))
      useContent.getState().setContent(c)
      toast.success('Site content saved. The shop shows it straight away.')
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }
  const discard = () => setDraft(JSON.parse(JSON.stringify(saved)))

  const groups = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return CONTENT_GROUPS.map((g) => ({
      name: g.name,
      keys: needle
        ? g.keys.filter((k) => k.toLowerCase().includes(needle) || builtinString(lang, k).toLowerCase().includes(needle) || (draft[lang][k] || '').toLowerCase().includes(needle))
        : g.keys,
    })).filter((g) => g.keys.length)
  }, [q, lang, draft])

  if (loading) return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>

  return (
    <div className="max-w-5xl space-y-5 pb-24">
      <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-xl">
            <h2 className="font-display text-xl font-bold">Site content</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Change any wording or picture on the shop. Leave a text box empty to keep the original wording shown in grey.
              Product details, recipes and prices are edited in their own pages.
            </p>
          </div>
          <div className="flex rounded-full bg-muted p-1" role="tablist" aria-label="What to edit">
            {([['text', 'Text', Type], ['images', 'Pictures', ImageIcon]] as const).map(([id, label, Icon]) => (
              <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
                className={cn('inline-flex h-10 items-center gap-2 rounded-full px-4 text-sm font-semibold transition-colors', tab === id ? 'bg-brand text-brand-foreground shadow-soft' : 'text-muted-foreground hover:text-foreground')}>
                <Icon className="h-4 w-4" /> {label}
              </button>
            ))}
          </div>
        </div>

        {tab === 'text' && (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <div className="flex rounded-full bg-muted p-1" role="radiogroup" aria-label="Language">
              {(['en', 'sw'] as Lang[]).map((l) => (
                <button key={l} role="radio" aria-checked={lang === l} onClick={() => setLang(l)}
                  className={cn('h-9 rounded-full px-4 text-sm font-semibold transition-colors', lang === l ? 'bg-card text-foreground shadow-soft' : 'text-muted-foreground hover:text-foreground')}>
                  {l === 'en' ? 'English' : 'Kiswahili'}
                </button>
              ))}
            </div>
            <label className="relative min-w-[14rem] flex-1">
              <span className="sr-only">Search text</span>
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search wording, e.g. “spoonful” or “delivery”"
                className="h-11 w-full rounded-full border border-border/70 bg-background pl-10 pr-4 text-sm outline-none focus:border-brand/50" />
            </label>
          </div>
        )}
      </div>

      {tab === 'text' ? (
        <div className="space-y-3">
          {groups.map((g) => {
            const open = !!q.trim() || !!openGroups[g.name]
            const edited = g.keys.filter((k) => (draft[lang][k] || '').trim()).length
            return (
              <section key={g.name} className="overflow-hidden rounded-2xl border border-border/60 bg-card shadow-soft">
                <button type="button" onClick={() => setOpenGroups((o) => ({ ...o, [g.name]: !o[g.name] }))} aria-expanded={open}
                  className="flex w-full items-center gap-3 px-5 py-4 text-left">
                  <span className="font-display text-base font-bold">{g.name}</span>
                  <span className="text-xs text-muted-foreground">{g.keys.length} texts</span>
                  {edited > 0 && <span className="rounded-full bg-brand/10 px-2 py-0.5 text-[11px] font-semibold text-brand">{edited} changed</span>}
                  <ChevronDown className={cn('ml-auto h-4 w-4 text-muted-foreground transition-transform', open && 'rotate-180')} />
                </button>
                {open && (
                  <div className="divide-y divide-border/60 border-t border-border/60">
                    {g.keys.map((k) => <TextRow key={k} k={k} lang={lang} value={draft[lang][k] || ''} onChange={(v) => setText(k, v)} />)}
                  </div>
                )}
              </section>
            )
          })}
          {!groups.length && <p className="rounded-2xl border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">No text matches “{q}”.</p>}
        </div>
      ) : (
        <ImageSlots draft={draft.img} onChange={setImg} />
      )}

      {/* Save bar */}
      <div className="sticky bottom-4 z-10">
        <div className="flex items-center gap-3 rounded-2xl border border-border/60 bg-card/95 p-3 shadow-glow">
          <p className="hidden text-xs text-muted-foreground sm:block">{changes ? `${changes} unsaved change${changes === 1 ? '' : 's'}` : 'Everything is saved.'}</p>
          {changes > 0 && (
            <button onClick={discard} className="ml-auto inline-flex h-11 items-center gap-2 rounded-full px-4 text-sm font-semibold text-muted-foreground hover:text-foreground">
              <Undo2 className="h-4 w-4" /> Discard
            </button>
          )}
          <button onClick={save} disabled={saving || !changes}
            className={cn('inline-flex h-11 items-center gap-2 rounded-full bg-brand px-6 text-sm font-bold text-brand-foreground shadow-soft transition hover:opacity-95 disabled:opacity-50', !changes && 'ml-auto')}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save content
          </button>
        </div>
      </div>
    </div>
  )
}

function TextRow({ k, lang, value, onChange }: { k: string; lang: Lang; value: string; onChange: (v: string) => void }) {
  const original = builtinString(lang, k) || builtinString('en', k)
  const vars = varsIn(original)
  const missing = value.trim() ? vars.filter((v) => !value.includes(v)) : []
  const long = original.length > 70
  const ref = useRef<HTMLTextAreaElement>(null)
  useEffect(() => {
    const el = ref.current
    if (el) { el.style.height = 'auto'; el.style.height = `${el.scrollHeight}px` }
  }, [value, original])
  return (
    <div className="grid gap-2 px-5 py-3.5 sm:grid-cols-[13rem_1fr] sm:gap-4">
      <div className="min-w-0">
        <p className="text-sm font-semibold">{labelOf(k)}</p>
        <p className="truncate font-mono text-[11px] text-muted-foreground" title={k}>{k}</p>
      </div>
      <div className="min-w-0">
        <div className="flex items-start gap-2">
          {long ? (
            <textarea ref={ref} value={value} onChange={(e) => onChange(e.target.value)} placeholder={original} rows={2}
              className="min-h-11 w-full resize-none rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none placeholder:text-muted-foreground/70 focus:border-brand/50" />
          ) : (
            <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={original}
              className="h-11 w-full rounded-xl border border-border/70 bg-background px-3.5 text-sm outline-none placeholder:text-muted-foreground/70 focus:border-brand/50" />
          )}
          {value && (
            <button type="button" onClick={() => onChange('')} title="Use the original wording" aria-label="Use the original wording"
              className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-muted-foreground hover:bg-muted hover:text-foreground">
              <RotateCcw className="h-4 w-4" />
            </button>
          )}
        </div>
        {vars.length > 0 && (
          <p className={cn('mt-1 text-[11px]', missing.length ? 'text-destructive' : 'text-muted-foreground')}>
            {missing.length ? `Keep ${missing.join(', ')} in your text; the shop fills it in.` : `${vars.join(', ')} ${vars.length === 1 ? 'is' : 'are'} filled in by the shop.`}
          </p>
        )}
      </div>
    </div>
  )
}

function ImageSlots({ draft, onChange }: { draft: Record<string, string>; onChange: (slot: string, v: string) => void }) {
  const groups = Array.from(new Set(IMAGE_SLOTS.map((s) => s.group)))
  return (
    <div className="space-y-5">
      {groups.map((g) => (
        <section key={g} className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
          <h3 className="font-display text-base font-bold">{g}</h3>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {IMAGE_SLOTS.filter((s) => s.group === g).map((s) => <SlotCard key={s.id} slot={s} value={draft[s.id] || ''} onChange={(v) => onChange(s.id, v)} />)}
          </div>
        </section>
      ))}
    </div>
  )
}

function SlotCard({ slot, value, onChange }: { slot: (typeof IMAGE_SLOTS)[number]; value: string; onChange: (v: string) => void }) {
  const [busy, setBusy] = useState(false)
  const input = useRef<HTMLInputElement>(null)
  const src = value || slot.def
  const pick = async (file?: File) => {
    if (!file) return
    setBusy(true)
    try { const r = await api.upload(file); onChange(r.url) } catch (e) { toast.error((e as Error).message) } finally { setBusy(false) }
  }
  return (
    <div className="flex flex-col rounded-2xl border border-border/60 bg-background p-3">
      <div className="relative aspect-[4/3] overflow-hidden rounded-xl bg-shell">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={asset(src)} alt="" className={cn('h-full w-full', /-(cut|pouch)\.|\.png$|mark|lockup|logo/.test(src) ? 'object-contain p-3' : 'object-cover')} />
        {value && <span className="absolute left-2 top-2 rounded-full bg-brand px-2 py-0.5 text-[11px] font-semibold text-brand-foreground">Changed</span>}
      </div>
      <p className="mt-3 text-sm font-semibold">{slot.label}</p>
      {slot.hint && <p className="mt-0.5 text-[11px] text-muted-foreground">{slot.hint}</p>}
      <div className="mt-3 flex items-center gap-2">
        <input ref={input} type="file" accept="image/*" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = '' }} />
        <button type="button" onClick={() => input.current?.click()} disabled={busy}
          className="inline-flex h-10 items-center gap-2 rounded-full bg-brand px-4 text-xs font-bold text-brand-foreground disabled:opacity-60">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />} Upload
        </button>
        {value && (
          <button type="button" onClick={() => onChange('')} className="inline-flex h-10 items-center gap-1.5 rounded-full px-3 text-xs font-semibold text-muted-foreground hover:text-foreground">
            <RotateCcw className="h-3.5 w-3.5" /> Original
          </button>
        )}
      </div>
      <input value={value.startsWith('data:') ? '' : value} onChange={(e) => onChange(e.target.value)}
        placeholder={value.startsWith('data:') ? 'Uploaded picture' : `or paste a link, e.g. ${slot.def}`}
        className="mt-2 h-10 w-full rounded-xl border border-border/70 bg-card px-3 text-xs outline-none focus:border-brand/50" />
    </div>
  )
}
