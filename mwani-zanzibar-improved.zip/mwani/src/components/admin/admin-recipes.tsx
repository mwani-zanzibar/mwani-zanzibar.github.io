'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { Plus, Search, Pencil, Trash2, Loader2, X, ChefHat, Star, Eye, EyeOff, Upload, Clock, Users } from 'lucide-react'
import { api, type ApiRecipe } from '@/lib/api'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'

const CATEGORIES = ['Cooking', 'Beverage', 'Skincare', 'Wellness']

type EditorState = {
  id?: string
  title: string
  excerpt: string
  content: string
  image: string
  category: string
  prepTime: string
  servings: string
  ingredients: string[]
  steps: string[]
  featured: boolean
  active: boolean
}

const blank: EditorState = {
  title: '', excerpt: '', content: '', image: '/products/powder.webp', category: 'Cooking',
  prepTime: '', servings: '', ingredients: [], steps: [], featured: false, active: true,
}

export function AdminRecipes() {
  const [recipes, setRecipes] = useState<ApiRecipe[]>([])
  const [loading, setLoading] = useState(true)
  const [q, setQ] = useState('')
  const [editing, setEditing] = useState<EditorState | null>(null)

  const load = () => {
    setLoading(true)
    api.recipes({ admin: '1' }).then((d) => setRecipes(d.recipes)).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const filtered = recipes.filter((r) => r.title.toLowerCase().includes(q.toLowerCase()) || r.category.toLowerCase().includes(q.toLowerCase()))

  const save = async (e: EditorState) => {
    try {
      if (e.id) await api.updateRecipe(e.id, e)
      else await api.createRecipe(e)
      toast.success(e.id ? 'Recipe updated' : 'Recipe created')
      setEditing(null)
      load()
    } catch (err) {
      toast.error((err as Error).message)
    }
  }

  const del = async (r: ApiRecipe) => {
    if (!confirm(`Delete "${r.title}"?`)) return
    try {
      await api.deleteRecipe(r.id)
      toast.success('Recipe deleted')
      load()
    } catch (err) {
      toast.error((err as Error).message)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search recipes…" className="w-full rounded-full border border-border/70 bg-background pl-10 pr-4 py-2.5 text-sm outline-none focus:border-brand/50" />
        </div>
        <button onClick={() => setEditing({ ...blank })} className="inline-flex items-center justify-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-soft hover:opacity-95 transition">
          <Plus className="h-4 w-4" /> Add recipe
        </button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <ChefHat className="h-10 w-10 text-muted-foreground/40 mx-auto" />
          <p className="mt-3 text-sm text-muted-foreground">No recipes yet. Tap “Add recipe” to create one.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r) => (
            <div key={r.id} className="group rounded-2xl border border-border/60 bg-card overflow-hidden shadow-soft hover:shadow-glow transition-shadow">
              <div className="relative aspect-[4/3] overflow-hidden bg-muted/30">
                <Image src={r.image} alt={r.title} fill className="object-cover transition-transform duration-500 group-hover:scale-105" sizes="(max-width: 640px) 100vw, 33vw" />
                <span className="absolute top-2 left-2 rounded-full bg-background/85 backdrop-blur px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-brand">{r.category}</span>
                {r.featured && <span className="absolute top-2 right-2 rounded-full bg-coral px-2 py-0.5 text-[10px] font-bold text-white inline-flex items-center gap-0.5"><Star className="h-2.5 w-2.5" /> Popular</span>}
                {!r.active && <span className="absolute inset-0 grid place-items-center bg-background/70"><span className="rounded-full bg-muted px-3 py-1 text-xs font-bold">Hidden</span></span>}
              </div>
              <div className="p-4">
                <h3 className="font-display text-base font-bold leading-snug line-clamp-1">{r.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground line-clamp-2 min-h-[2rem]">{r.excerpt}</p>
                <div className="mt-2 flex items-center gap-3 text-[11px] text-muted-foreground">
                  {r.prepTime && <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3" />{r.prepTime}</span>}
                  {r.servings && <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" />{r.servings}</span>}
                </div>
                <div className="mt-3 flex gap-2">
                  <button onClick={() => setEditing({ id: r.id, title: r.title, excerpt: r.excerpt, content: r.content, image: r.image, category: r.category, prepTime: r.prepTime, servings: r.servings, ingredients: r.ingredients, steps: r.steps, featured: r.featured, active: r.active })} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-brand/10 text-brand py-2 text-xs font-bold hover:bg-brand/20 transition">
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </button>
                  <button onClick={() => del(r)} className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-destructive/10 text-destructive px-3 py-2 text-xs font-bold hover:bg-destructive/20 transition">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {editing && <RecipeEditor key={editing.id || 'new'} initial={editing} onClose={() => setEditing(null)} onSave={save} />}
      </AnimatePresence>
    </div>
  )
}

function RecipeEditor({ initial, onClose, onSave }: { initial: EditorState; onClose: () => void; onSave: (e: EditorState) => void }) {
  const [f, setF] = useState<EditorState>(initial)
  const [ingredientsStr, setIngredientsStr] = useState(initial.ingredients.join('\n'))
  const [stepsStr, setStepsStr] = useState(initial.steps.join('\n'))
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)

  const submit = async () => {
    if (!f.title.trim() || !f.excerpt.trim() || !f.content.trim()) {
      toast.error('Title, excerpt and content are required.')
      return
    }
    setSaving(true)
    await onSave({
      ...f,
      ingredients: ingredientsStr.split('\n').map((s) => s.trim()).filter(Boolean),
      steps: stepsStr.split('\n').map((s) => s.trim()).filter(Boolean),
    })
    setSaving(false)
  }

  const upload = async (file: File | undefined) => {
    if (!file) return
    setUploading(true)
    try {
      const r = await api.upload(file)
      setF({ ...f, image: r.url })
      toast.success('Image uploaded')
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setUploading(false)
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto scrollbar-thin rounded-3xl">
        <DialogTitle className="sr-only">{f.id ? 'Edit recipe' : 'New recipe'}</DialogTitle>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold flex items-center gap-2"><ChefHat className="h-5 w-5 text-coral" /> {f.id ? 'Edit recipe' : 'New recipe'}</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent/40"><X className="h-4 w-4" /></button>
        </div>

        <div className="mt-3 grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2 flex gap-4">
            <div className="relative h-20 w-20 rounded-xl overflow-hidden bg-muted/30 shrink-0 ring-1 ring-border/60">
              <Image src={f.image} alt="preview" fill className="object-cover" sizes="80px" />
            </div>
            <div className="flex-1">
              <label className="text-xs font-semibold text-muted-foreground">Recipe image</label>
              <div className="mt-1 flex gap-2">
                <input value={f.image} onChange={(e) => setF({ ...f, image: e.target.value })} className="flex-1 rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="/products/….jpg" />
                <label className={cn('relative inline-flex items-center gap-1.5 rounded-xl bg-brand/10 text-brand px-3.5 py-2.5 text-xs font-bold hover:bg-brand/20 transition cursor-pointer', uploading && 'opacity-50 pointer-events-none')}>
                  {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />} Upload
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => upload(e.target.files?.[0])} />
                </label>
              </div>
            </div>
          </div>

          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Title *</label>
            <input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Category</label>
            <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50">
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Prep time</label>
              <input value={f.prepTime} onChange={(e) => setF({ ...f, prepTime: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="10 min" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Servings</label>
              <input value={f.servings} onChange={(e) => setF({ ...f, servings: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" placeholder="2 servings" />
            </div>
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Excerpt *</label>
            <input value={f.excerpt} onChange={(e) => setF({ ...f, excerpt: e.target.value })} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Content *</label>
            <textarea value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} rows={3} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Ingredients (one per line)</label>
            <textarea value={ingredientsStr} onChange={(e) => setIngredientsStr(e.target.value)} rows={4} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none font-mono text-xs" placeholder={'1 tsp seaweed powder\n1 ripe banana'} />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs font-semibold text-muted-foreground">Method steps (one per line)</label>
            <textarea value={stepsStr} onChange={(e) => setStepsStr(e.target.value)} rows={4} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div className="sm:col-span-2 flex items-center gap-4">
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={f.featured} onChange={(e) => setF({ ...f, featured: e.target.checked })} className="h-4 w-4 accent-brand" />
              <Star className="h-4 w-4 text-coral" /> Featured (Popular)
            </label>
            <label className="inline-flex items-center gap-2 text-sm font-medium">
              <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} className="h-4 w-4 accent-brand" />
              {f.active ? <Eye className="h-4 w-4 text-leaf" /> : <EyeOff className="h-4 w-4 text-muted-foreground" />} Active (visible)
            </label>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button onClick={onClose} className="rounded-full border border-border/70 px-5 py-2.5 text-sm font-semibold hover:bg-accent/40 transition">Cancel</button>
          <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-glow hover:opacity-95 transition disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {f.id ? 'Save changes' : 'Create recipe'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
