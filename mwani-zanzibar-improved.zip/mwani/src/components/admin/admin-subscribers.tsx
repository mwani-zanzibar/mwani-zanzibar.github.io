'use client'

import { useEffect, useState } from 'react'
import { Mail, Trash2, Loader2, Download, Users, Calendar, Copy } from 'lucide-react'
import { api } from '@/lib/api'
import { toast } from 'sonner'
import { toCSV, downloadCSV } from '@/lib/format'

type Sub = { id: string; email: string; name: string; createdAt: string }

export function AdminSubscribers() {
  const [subs, setSubs] = useState<Sub[]>([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    setLoading(true)
    api.subscribers().then((d) => setSubs(d.subscribers)).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const del = async (id: string) => {
    if (!confirm('Remove this subscriber?')) return
    try {
      await api.deleteSubscriber(id)
      toast.success('Subscriber removed')
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const copyAll = () => {
    const emails = subs.map((s) => s.email).join(', ')
    navigator.clipboard?.writeText(emails)
    toast.success(`Copied ${subs.length} emails`)
  }

  const exportCSV = () => {
    if (subs.length === 0) { toast.error('No subscribers yet'); return }
    const csv = toCSV(['Email', 'Name', 'Subscribed'], subs.map((s) => [s.email, s.name, new Date(s.createdAt).toLocaleString()]))
    downloadCSV(`mwani-subscribers-${new Date().toISOString().slice(0, 10)}.csv`, csv)
    toast.success(`Exported ${subs.length} subscribers`)
  }

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
          <div className="flex items-center gap-2 text-brand">
            <Users className="h-5 w-5" />
            <span className="text-xs font-bold uppercase tracking-wide">Subscribers</span>
          </div>
          <div className="mt-2 font-display text-3xl font-bold">{subs.length}</div>
        </div>
        <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
          <div className="flex items-center gap-2 text-coral">
            <Calendar className="h-5 w-5" />
            <span className="text-xs font-bold uppercase tracking-wide">Latest</span>
          </div>
          <div className="mt-2 text-sm font-semibold truncate">{subs[0]?.email || '—'}</div>
          <div className="text-[11px] text-muted-foreground">{subs[0] ? new Date(subs[0].createdAt).toLocaleDateString() : 'No subscribers yet'}</div>
        </div>
        <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft flex flex-col justify-between">
          <div className="flex items-center gap-2 text-leaf">
            <Mail className="h-5 w-5" />
            <span className="text-xs font-bold uppercase tracking-wide">Actions</span>
          </div>
          <div className="mt-2 flex gap-2">
            <button onClick={copyAll} disabled={subs.length === 0} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-full bg-leaf/15 text-leaf border border-leaf/30 px-3 py-2 text-xs font-bold hover:bg-leaf/25 transition disabled:opacity-40">
              <Copy className="h-3.5 w-3.5" /> Copy all
            </button>
            <button onClick={exportCSV} disabled={subs.length === 0} className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-full bg-brand/10 text-brand border border-brand/30 px-3 py-2 text-xs font-bold hover:bg-brand/20 transition disabled:opacity-40">
              <Download className="h-3.5 w-3.5" /> Export
            </button>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : subs.length === 0 ? (
        <div className="text-center py-16">
          <Mail className="h-10 w-10 text-muted-foreground/40 mx-auto" />
          <p className="mt-3 text-sm text-muted-foreground">No subscribers yet. Signups from the store footer will appear here.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border/60 bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-sand/40 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left font-semibold px-4 py-3">Email</th>
                <th className="text-left font-semibold px-4 py-3 hidden sm:table-cell">Name</th>
                <th className="text-left font-semibold px-4 py-3 hidden sm:table-cell">Subscribed</th>
                <th className="text-right font-semibold px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {subs.map((s) => (
                <tr key={s.id} className="hover:bg-sand/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="grid h-8 w-8 place-items-center rounded-full bg-brand/10 text-brand font-bold text-xs">
                        <Mail className="h-3.5 w-3.5" />
                      </div>
                      <span className="font-semibold">{s.email}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{s.name || '—'}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground hidden sm:table-cell whitespace-nowrap">{new Date(s.createdAt).toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => del(s.id)} className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition ml-auto">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
