'use client'

import { useEffect, useState } from 'react'
import { Loader2, Save, MessageCircle, Phone, Mail, Globe, Ship, DollarSign, Image as ImageIcon } from 'lucide-react'
import { api, type ApiSettings } from '@/lib/api'
import { toast } from 'sonner'
import { AdminPromos } from '@/components/admin/admin-promos'

export function AdminSettings() {
  const [s, setS] = useState<ApiSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    api.settings().then((d) => setS(d.settings)).finally(() => setLoading(false))
  }, [])

  const set = (k: keyof ApiSettings, v: string | number) => setS((prev) => (prev ? { ...prev, [k]: v } : prev))

  const save = async () => {
    if (!s) return
    setSaving(true)
    try {
      await api.updateSettings(s)
      toast.success('Settings saved')
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setSaving(false)
    }
  }

  if (loading || !s) return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>

  return (
    <div className="space-y-5 max-w-4xl">
      {/* Promo codes */}
      <AdminPromos />

      {/* Contact */}
      <Section icon={Phone} title="WhatsApp & Phone" desc="Numbers shown on the site and used for order redirects.">
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Primary WhatsApp number" value={s.whatsappPrimary} onChange={(v) => set('whatsappPrimary', v)} placeholder="+255 774 870 703" />
          <Field label="Secondary WhatsApp number" value={s.whatsappSecondary} onChange={(v) => set('whatsappSecondary', v)} placeholder="+255 773 939 262" />
          <Field label="Phone shown in the footer" value={s.phonePrimary} onChange={(v) => set('phonePrimary', v)} />
        </div>
      </Section>

      {/* Business */}
      <Section icon={Globe} title="Business & Contact" desc="Shown in footer and contact section.">
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Shop name (price list and invoices)" value={s.shopName} onChange={(v) => set('shopName', v)} />
          <Field label="Tagline (footer)" value={s.tagline} onChange={(v) => set('tagline', v)} />
          <Field label="Email" value={s.email} onChange={(v) => set('email', v)} />
          <Field label="Website" value={s.website} onChange={(v) => set('website', v)} />
          <Field label="Instagram handle (without @)" value={s.instagram} onChange={(v) => set('instagram', v)} />
          <Field label="Address" value={s.address} onChange={(v) => set('address', v)} />
        </div>
      </Section>

      {/* Wording and pictures now live in Site content */}
      <Section icon={ImageIcon} title="Wording and pictures" desc="Headlines, section text, questions and answers, and every section picture are edited in Site content (left menu), in English and Kiswahili.">
        <a href="#content" className="inline-flex h-10 items-center rounded-full bg-brand/10 px-4 text-sm font-semibold text-brand hover:bg-brand/15">Open Site content</a>
      </Section>

      {/* Shipping & Currency */}
      <Section icon={Ship} title="Shipping, Ferry & Currency" desc="Info for mainland deliveries, shipping fees, and the USD exchange rate.">
        <div className="grid sm:grid-cols-3 gap-3">
          <Field label="Shipping fee to mainland (TSh)" type="number" value={String(s.shippingFeeMainland)} onChange={(v) => set('shippingFeeMainland', Number(v))} />
          <Field label="Free shipping threshold (TSh)" type="number" value={String(s.freeShippingThreshold)} onChange={(v) => set('freeShippingThreshold', Number(v))} />
          <Field label="USD rate (TSh per $1)" type="number" value={String(s.usdRate)} onChange={(v) => set('usdRate', Number(v))} />
        </div>
        <p className="text-[11px] text-muted-foreground -mt-1">The USD rate is used by the storefront currency toggle to convert displayed prices. Customers see approximate USD amounts for reference only — orders are always charged in TSh.</p>
        <Field label="Ferry info text" value={s.ferryInfo} onChange={(v) => set('ferryInfo', v)} textarea rows={3} />
      </Section>

      {/* Message template */}
      <Section icon={MessageCircle} title="WhatsApp order message template" desc="Pre-filled message when customer taps the WhatsApp button. Placeholders: {orderNumber}, {name}, {location}, {channel}, {items}, {total}.">
        <Field label="Message template" value={s.whatsappMessageTemplate} onChange={(v) => set('whatsappMessageTemplate', v)} textarea rows={7} mono />
      </Section>

      {/* Save bar */}
      <div className="sticky bottom-4 z-10">
        <div className="rounded-2xl glass-strong border border-border/60 shadow-glow p-3 flex items-center justify-between">
          <p className="text-xs text-muted-foreground hidden sm:block">Changes apply to the store instantly.</p>
          <button onClick={save} disabled={saving} className="ml-auto inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-6 py-3 text-sm font-bold shadow-soft hover:opacity-95 transition disabled:opacity-50">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save settings
          </button>
        </div>
      </div>
    </div>
  )
}

function Section({ icon: Icon, title, desc, children }: { icon: typeof Phone; title: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
      <div className="flex items-start gap-3 mb-4">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand shrink-0">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h3 className="font-display text-base font-bold">{title}</h3>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
      </div>
      {children}
    </div>
  )
}

function Field({
  label, value, onChange, placeholder, textarea, rows, type = 'text', mono,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  textarea?: boolean
  rows?: number
  type?: string
  mono?: boolean
}) {
  return (
    <div>
      <label className="text-xs font-semibold text-muted-foreground">{label}</label>
      {textarea ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={rows || 3}
          placeholder={placeholder}
          className={`mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none ${mono ? 'font-mono text-xs' : ''}`}
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={`mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 ${mono ? 'font-mono text-xs' : ''}`}
        />
      )}
    </div>
  )
}
