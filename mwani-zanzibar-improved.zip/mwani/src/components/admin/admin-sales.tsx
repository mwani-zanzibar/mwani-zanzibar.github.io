'use client'

import { useEffect, useState } from 'react'
import { Plus, Loader2, Trash2, X, ShoppingBag, Store, Ship, Globe, Boxes, Filter, Download } from 'lucide-react'
import { api, type ApiSale, type ApiProduct } from '@/lib/api'
import { formatTZS, toCSV, downloadCSV } from '@/lib/format'
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

const CHANNELS = [
  { k: 'local', label: 'Local (shop)', icon: Store },
  { k: 'ferry', label: 'Ferry (Azam)', icon: Ship },
  { k: 'online', label: 'Online', icon: Globe },
  { k: 'wholesale', label: 'Wholesale', icon: Boxes },
]

export function AdminSales() {
  const [sales, setSales] = useState<ApiSale[]>([])
  const [products, setProducts] = useState<ApiProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [adding, setAdding] = useState(false)

  const load = () => {
    setLoading(true)
    Promise.all([api.sales(), api.products({ admin: '1' })]).then(([s, p]) => {
      setSales(s.sales)
      setProducts(p.products)
    }).finally(() => setLoading(false))
  }
  useEffect(load, [])

  const filtered = filter === 'all' ? sales : sales.filter((s) => s.channel === filter)
  const total = filtered.reduce((sum, s) => sum + s.total, 0)

  const exportCSV = () => {
    if (filtered.length === 0) { toast.error('No sales to export'); return }
    const csv = toCSV(
      ['Date', 'Item', 'Qty', 'Unit Price', 'Total', 'Channel', 'Customer', 'Phone', 'Location', 'Note'],
      filtered.map((s) => [
        new Date(s.date).toLocaleString(),
        s.itemName,
        s.qty,
        s.price,
        s.total,
        s.channel,
        s.customerName,
        s.customerPhone,
        s.location,
        s.note,
      ])
    )
    downloadCSV(`mwani-sales-${new Date().toISOString().slice(0, 10)}.csv`, csv)
    toast.success(`Exported ${filtered.length} sales`)
  }

  const del = async (id: string) => {
    if (!confirm('Delete this sale record? Stock will be restored.')) return
    try {
      await api.deleteSale(id)
      toast.success('Sale deleted')
      load()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center justify-between">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-thin pb-1">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          <button onClick={() => setFilter('all')} className={cn('rounded-full px-3 py-1.5 text-xs font-semibold whitespace-nowrap', filter === 'all' ? 'bg-brand text-primary-foreground' : 'bg-background border border-border/60 text-muted-foreground hover:text-foreground')}>All</button>
          {CHANNELS.map((c) => (
            <button key={c.k} onClick={() => setFilter(c.k)} className={cn('rounded-full px-3 py-1.5 text-xs font-semibold whitespace-nowrap', filter === c.k ? 'bg-brand text-primary-foreground' : 'bg-background border border-border/60 text-muted-foreground hover:text-foreground')}>{c.label}</button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={exportCSV} className="inline-flex items-center justify-center gap-2 rounded-full bg-leaf/15 text-leaf border border-leaf/30 px-4 py-2.5 text-sm font-bold hover:bg-leaf/25 transition">
            <Download className="h-4 w-4" /> Export
          </button>
          <button onClick={() => setAdding(true)} className="inline-flex items-center justify-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-soft hover:opacity-95 transition">
            <Plus className="h-4 w-4" /> Record a sale
          </button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-border/60 bg-card p-4">
          <div className="text-xs text-muted-foreground">Records</div>
          <div className="font-display text-xl font-bold">{filtered.length}</div>
        </div>
        <div className="rounded-xl border border-border/60 bg-card p-4">
          <div className="text-xs text-muted-foreground">Total value</div>
          <div className="font-display text-xl font-bold text-brand">{formatTZS(total)}</div>
        </div>
        <div className="rounded-xl border border-border/60 bg-card p-4">
          <div className="text-xs text-muted-foreground">Units sold</div>
          <div className="font-display text-xl font-bold">{filtered.reduce((s, x) => s + x.qty, 0)}</div>
        </div>
        <div className="rounded-xl border border-border/60 bg-card p-4">
          <div className="text-xs text-muted-foreground">Avg order</div>
          <div className="font-display text-xl font-bold">{filtered.length ? formatTZS(total / filtered.length) : '—'}</div>
        </div>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-brand" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <ShoppingBag className="h-10 w-10 text-muted-foreground/40 mx-auto" />
          <p className="mt-3 text-sm text-muted-foreground">No sales recorded yet. Tap “Record a sale” to add one.</p>
        </div>
      ) : (
        <div className="rounded-2xl border border-border/60 bg-card overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead className="bg-sand/40 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left font-semibold px-4 py-3">Item</th>
                <th className="text-center font-semibold px-4 py-3">Qty</th>
                <th className="text-right font-semibold px-4 py-3">Price</th>
                <th className="text-right font-semibold px-4 py-3">Total</th>
                <th className="text-center font-semibold px-4 py-3">Channel</th>
                <th className="text-left font-semibold px-4 py-3">Customer</th>
                <th className="text-left font-semibold px-4 py-3">Date</th>
                <th className="text-right font-semibold px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {filtered.map((s) => (
                <tr key={s.id} className="hover:bg-sand/30 transition-colors">
                  <td className="px-4 py-3 font-semibold">{s.itemName}</td>
                  <td className="px-4 py-3 text-center">{s.qty}</td>
                  <td className="px-4 py-3 text-right">{formatTZS(s.price)}</td>
                  <td className="px-4 py-3 text-right font-bold text-brand">{formatTZS(s.total)}</td>
                  <td className="px-4 py-3 text-center"><span className="inline-flex rounded-full bg-brand/10 text-brand px-2.5 py-0.5 text-[11px] font-bold capitalize">{s.channel}</span></td>
                  <td className="px-4 py-3">
                    <div className="text-xs font-semibold">{s.customerName}</div>
                    <div className="text-[11px] text-muted-foreground">{s.location}</div>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{new Date(s.date).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => del(s.id)} className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition ml-auto">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {adding && <SaleEditor products={products} onClose={() => setAdding(false)} onSaved={() => { setAdding(false); load() }} />}
    </div>
  )
}

function SaleEditor({ products, onClose, onSaved }: { products: ApiProduct[]; onClose: () => void; onSaved: () => void }) {
  const [productId, setProductId] = useState('')
  const [itemName, setItemName] = useState('')
  const [qty, setQty] = useState(1)
  const [price, setPrice] = useState(0)
  const [channel, setChannel] = useState('local')
  const [customerName, setCustomerName] = useState('Walk-in')
  const [customerPhone, setCustomerPhone] = useState('')
  const [location, setLocation] = useState('Zanzibar')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  const onProductChange = (id: string) => {
    setProductId(id)
    const p = products.find((pp) => pp.id === id)
    if (p) { setItemName(p.name); setPrice(p.price) }
  }

  const submit = async () => {
    if (!itemName.trim() || !qty || !price) {
      toast.error('Item, quantity and price are required.')
      return
    }
    setSaving(true)
    try {
      await api.createSale({
        productId: productId || undefined,
        itemName: itemName.trim(),
        qty: Number(qty),
        price: Number(price),
        channel,
        customerName: customerName.trim() || 'Walk-in',
        customerPhone: customerPhone.trim(),
        location: location.trim(),
        note: note.trim(),
      } as Partial<ApiSale>)
      toast.success('Sale recorded')
      onSaved()
    } catch (e) {
      toast.error((e as Error).message)
      setSaving(false)
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[92vh] overflow-y-auto scrollbar-thin rounded-3xl">
        <DialogTitle className="sr-only">Record a sale</DialogTitle>
        <div className="flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">Record a sale</h2>
          <button onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-accent/40"><X className="h-4 w-4" /></button>
        </div>

        <div className="mt-4 space-y-3">
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Select product (optional)</label>
            <select value={productId} onChange={(e) => onProductChange(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50">
              <option value="">— Custom item —</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.stock} in stock)</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Item name *</label>
            <input value={itemName} onChange={(e) => setItemName(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Quantity *</label>
              <input type="number" min="1" value={qty} onChange={(e) => setQty(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Unit price (TSh) *</label>
              <input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Channel</label>
            <div className="mt-1 grid grid-cols-4 gap-2">
              {CHANNELS.map((c) => (
                <button key={c.k} type="button" onClick={() => setChannel(c.k)} className={cn('rounded-xl border p-2.5 text-center transition', channel === c.k ? 'border-brand bg-brand/5' : 'border-border/60 hover:border-brand/40')}>
                  <c.icon className={cn('h-4 w-4 mx-auto', channel === c.k ? 'text-brand' : 'text-muted-foreground')} />
                  <div className="text-[10px] font-bold mt-1">{c.label.split(' ')[0]}</div>
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Customer name</label>
              <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground">Phone</label>
              <input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Location</label>
            <input value={location} onChange={(e) => setLocation(e.target.value)} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50" />
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground">Note</label>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className="mt-1 w-full rounded-xl border border-border/70 bg-background px-3.5 py-2.5 text-sm outline-none focus:border-brand/50 resize-none" />
          </div>
          <div className="rounded-xl bg-brand/5 border border-brand/15 p-3 flex items-center justify-between">
            <span className="text-sm font-semibold">Total</span>
            <span className="font-display text-xl font-bold text-brand">{formatTZS(qty * price)}</span>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button onClick={onClose} className="rounded-full border border-border/70 px-5 py-2.5 text-sm font-semibold hover:bg-accent/40 transition">Cancel</button>
          <button onClick={submit} disabled={saving} className="inline-flex items-center gap-2 rounded-full bg-brand text-primary-foreground px-5 py-2.5 text-sm font-bold shadow-glow hover:opacity-95 transition disabled:opacity-50">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />} Record sale
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
