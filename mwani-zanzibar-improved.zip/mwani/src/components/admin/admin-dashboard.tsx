'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import {
  TrendingUp, ShoppingBag, Package, AlertTriangle, Star, Clock, DollarSign,
  ArrowUpRight, Boxes, Mail, ChefHat, History, Loader2,
} from 'lucide-react'
import { api, type ApiRestockLog } from '@/lib/api'
import { formatTZS, statusLabel } from '@/lib/format'
import { Reveal } from '@/components/shared/reveal'
import { toast } from 'sonner'
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, Legend,
} from 'recharts'
import { motion } from 'framer-motion'

type Stats = {
  totalProducts: number
  lowStock: number
  outOfStock: number
  totalOrders: number
  pendingOrders: number
  onlineRevenue: number
  localRevenue: number
  totalRevenue: number
  reviews: number
  pendingReviews: number
  subscribers: number
  recipes: number
  range: string
  rangeDays: number
  days: { date: string; label: string; orders: number; sales: number }[]
  categoryBreakdown: { name: string; value: number }[]
  topProducts: { name: string; qty: number; revenue: number }[]
  recentOrders?: unknown[]
}

const PIE_COLORS = ['var(--brand)', 'var(--coral)', 'var(--turquoise)', 'var(--leaf)', 'var(--rose)', 'var(--chart-5)']

export function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)
  const [range, setRange] = useState<'7d' | '30d' | '90d' | 'all'>('7d')
  const [historyVersion, setHistoryVersion] = useState(0)
  const [reload, setReload] = useState(0)

  useEffect(() => {
    setLoading(true)
    api.stats(range).then((d) => setStats(d as Stats)).finally(() => setLoading(false))
  }, [range, reload])

  if (loading || !stats) {
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="h-28 rounded-2xl bg-card shimmer" />
        ))}
      </div>
    )
  }

  const kpis = [
    { label: 'Total Revenue', value: formatTZS(stats.totalRevenue), sub: `Online ${formatTZS(stats.onlineRevenue)} · Local ${formatTZS(stats.localRevenue)}`, icon: DollarSign, color: 'text-brand', bg: 'bg-brand/10' },
    { label: 'Orders', value: stats.totalOrders, sub: `${stats.pendingOrders} pending`, icon: ShoppingBag, color: 'text-coral', bg: 'bg-coral/10' },
    { label: 'Products', value: stats.totalProducts, sub: `${stats.lowStock} low stock`, icon: Package, color: 'text-turquoise', bg: 'bg-turquoise/10' },
    { label: 'Subscribers', value: stats.subscribers, sub: 'Newsletter signups', icon: Mail, color: 'text-leaf', bg: 'bg-leaf/10' },
    { label: 'Recipes', value: stats.recipes, sub: 'Published', icon: ChefHat, color: 'text-rose', bg: 'bg-rose/15' },
    { label: 'Reviews', value: stats.reviews, sub: `${stats.pendingReviews} pending`, icon: Star, color: 'text-amber-500', bg: 'bg-amber-500/10' },
  ]

  return (
    <div className="space-y-6">
      {stats.totalProducts === 0 && <StarterCard onDone={() => setReload((n) => n + 1)} />}
      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {kpis.map((k, i) => (
          <Reveal key={k.label} delay={i * 0.05}>
            <motion.div whileHover={{ y: -3 }} className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
              <div className="flex items-center justify-between">
                <div className={`grid h-10 w-10 place-items-center rounded-xl ${k.bg} ${k.color}`}>
                  <k.icon className="h-5 w-5" />
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground/40" />
              </div>
              <div className="mt-3 font-display text-2xl font-bold text-foreground">{k.value}</div>
              <div className="text-xs text-muted-foreground">{k.label}</div>
              <div className="text-[11px] text-muted-foreground/80 mt-1">{k.sub}</div>
            </motion.div>
          </Reveal>
        ))}
      </div>

      {/* Range selector */}
      <div className="flex items-center justify-end -mb-2">
        <div className="inline-flex rounded-full bg-muted/60 p-1 text-xs font-semibold">
          {([
            { k: '7d', label: '7 days' },
            { k: '30d', label: '30 days' },
            { k: '90d', label: '90 days' },
            { k: 'all', label: 'All time' },
          ] as const).map((r) => (
            <button
              key={r.k}
              onClick={() => setRange(r.k)}
              className={`relative rounded-full px-3 py-1.5 transition-colors ${range === r.k ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
            >
              {range === r.k && <motion.span layoutId="range-active" className="absolute inset-0 rounded-full bg-brand" transition={{ type: 'spring', stiffness: 400, damping: 30 }} />}
              <span className="relative">{r.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Revenue chart */}
        <Reveal className="lg:col-span-2">
          <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-display text-lg font-bold">Revenue · {range === 'all' ? 'all time' : `last ${stats.rangeDays} days`}</h3>
                <p className="text-xs text-muted-foreground">Online orders + local sales</p>
              </div>
              <div className="inline-flex items-center gap-1.5 rounded-full bg-brand/10 text-brand px-3 py-1.5 text-xs font-bold">
                <TrendingUp className="h-3.5 w-3.5" /> {formatTZS(stats.totalRevenue)}
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={stats.days} margin={{ top: 8, right: 8, bottom: 0, left: -16 }}>
                  <defs>
                    <linearGradient id="gOrders" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brand)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--brand)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--coral)" stopOpacity={0.4} />
                      <stop offset="100%" stopColor="var(--coral)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} axisLine={false} tickLine={false} tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: '1px solid var(--border)', background: 'var(--popover)', fontSize: 12 }}
                    formatter={(v: number, n) => [formatTZS(Number(v)), n === 'orders' ? 'Orders' : 'Local sales']}
                  />
                  <Area type="monotone" dataKey="orders" stroke="var(--brand)" strokeWidth={2} fill="url(#gOrders)" />
                  <Area type="monotone" dataKey="sales" stroke="var(--coral)" strokeWidth={2} fill="url(#gSales)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Reveal>

        {/* Category breakdown */}
        <Reveal delay={0.06}>
          <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft h-full">
            <h3 className="font-display text-lg font-bold">Sales by category</h3>
            <p className="text-xs text-muted-foreground mb-2">Units sold across all channels</p>
            {stats.categoryBreakdown.length === 0 ? (
              <div className="h-48 grid place-items-center text-sm text-muted-foreground">No sales yet</div>
            ) : (
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={stats.categoryBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={3}>
                      {stats.categoryBreakdown.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid var(--border)', background: 'var(--popover)', fontSize: 12 }} formatter={(v: number, n) => [`${v} units`, n]} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </Reveal>
      </div>

      {/* Top products + low stock */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Reveal>
          <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
            <h3 className="font-display text-lg font-bold flex items-center gap-2"><Boxes className="h-4 w-4 text-coral" /> Top products</h3>
            <div className="mt-3 space-y-2">
              {stats.topProducts.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">No sales recorded yet.</p> :
                stats.topProducts.map((p, i) => (
                  <div key={p.name} className="flex items-center gap-3 rounded-xl bg-sand/40 p-3">
                    <div className="grid h-8 w-8 place-items-center rounded-lg bg-brand text-primary-foreground font-bold text-xs">{i + 1}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold line-clamp-1">{p.name}</div>
                      <div className="text-[11px] text-muted-foreground">{p.qty} units sold</div>
                    </div>
                    <div className="text-sm font-bold text-brand">{formatTZS(p.revenue)}</div>
                  </div>
                ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.06}>
          <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
            <h3 className="font-display text-lg font-bold flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-amber-500" /> Stock attention</h3>
            <div className="mt-3 space-y-2">
              <StockAlerts onRestock={() => setHistoryVersion((v) => v + 1)} />
            </div>
          </div>
        </Reveal>
      </div>

      {/* Restock history */}
      <Reveal>
        <RestockHistory version={historyVersion} />
      </Reveal>
    </div>
  )
}

function StockAlerts({ onRestock }: { onRestock: () => void }) {
  const [items, setItems] = useState<{ id: string; name: string; stock: number; lowStockThreshold: number; image: string }[]>([])
  const [restocking, setRestocking] = useState<string | null>(null)

  const load = () => {
    api.products({ admin: '1' }).then((d) => {
      setItems(d.products.filter((p) => p.stock <= p.lowStockThreshold).sort((a, b) => a.stock - b.stock))
    })
  }
  useEffect(load, [])

  const restock = async (id: string, add: number) => {
    setRestocking(id)
    try {
      const p = items.find((i) => i.id === id)
      if (!p) return
      await api.restock(id, add)
      toast.success(`Restocked +${add} (${p.name})`)
      load()
      onRestock()
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setRestocking(null)
    }
  }

  if (items.length === 0) return <p className="text-sm text-muted-foreground py-6 text-center">All products well stocked.</p>
  return (
    <>
      {items.map((p) => (
        <div key={p.id} className="flex items-center gap-3 rounded-xl bg-sand/40 p-3">
          <div className="relative h-10 w-10 rounded-lg overflow-hidden bg-muted/30 shrink-0">
            <Image src={p.image} alt={p.name} fill className="object-cover" sizes="40px" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold line-clamp-1">{p.name}</div>
            <div className="text-[11px] text-muted-foreground">Threshold: {p.lowStockThreshold}</div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-sm font-bold ${p.stock <= 0 ? 'text-destructive' : 'text-amber-600'}`}>
              {p.stock <= 0 ? 'Out' : `${p.stock} left`}
            </span>
            <div className="flex items-center gap-1">
              {[10, 25, 50].map((n) => (
                <button
                  key={n}
                  disabled={restocking === p.id}
                  onClick={() => restock(p.id, n)}
                  className="rounded-full bg-brand/10 text-brand px-2.5 py-1 text-[10px] font-bold hover:bg-brand/20 transition disabled:opacity-50"
                  title={`Add ${n} units`}
                >
                  {restocking === p.id ? '…' : `+${n}`}
                </button>
              ))}
            </div>
          </div>
        </div>
      ))}
    </>
  )
}

function RestockHistory({ version }: { version: number }) {
  const [logs, setLogs] = useState<ApiRestockLog[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    api.restockLogs().then((d) => setLogs(d.logs)).finally(() => setLoading(false))
  }, [version])

  return (
    <div className="rounded-2xl border border-border/60 bg-card p-5 shadow-soft">
      <h3 className="font-display text-lg font-bold flex items-center gap-2">
        <History className="h-4 w-4 text-turquoise" /> Restock history
      </h3>
      <p className="text-xs text-muted-foreground mt-0.5">Every quick-restock action is logged for your records.</p>
      {loading ? (
        <div className="grid place-items-center py-10"><Loader2 className="h-5 w-5 animate-spin text-brand" /></div>
      ) : logs.length === 0 ? (
        <p className="text-sm text-muted-foreground py-8 text-center">No restocks yet. Use the +10/+25/+50 buttons above to restock low items.</p>
      ) : (
        <div className="mt-4 overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm min-w-[640px]">
            <thead className="text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left font-semibold px-3 py-2">Product</th>
                <th className="text-center font-semibold px-3 py-2">Added</th>
                <th className="text-center font-semibold px-3 py-2">Before</th>
                <th className="text-center font-semibold px-3 py-2">After</th>
                <th className="text-left font-semibold px-3 py-2 hidden sm:table-cell">By</th>
                <th className="text-left font-semibold px-3 py-2">When</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {logs.map((l) => (
                <tr key={l.id} className="hover:bg-sand/30 transition-colors">
                  <td className="px-3 py-2.5 font-semibold">{l.productName}</td>
                  <td className="px-3 py-2.5 text-center"><span className="inline-flex items-center rounded-full bg-leaf/15 text-leaf px-2 py-0.5 text-[11px] font-bold">+{l.quantity}</span></td>
                  <td className="px-3 py-2.5 text-center text-muted-foreground">{l.fromStock}</td>
                  <td className="px-3 py-2.5 text-center font-bold text-brand">{l.toStock}</td>
                  <td className="px-3 py-2.5 text-muted-foreground hidden sm:table-cell">{l.adminName}</td>
                  <td className="px-3 py-2.5 text-xs text-muted-foreground whitespace-nowrap">{new Date(l.createdAt).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

// Shown once, on a brand-new database: fills it with the 15 products, recipes,
// sample promo codes and default settings from the code. No terminal needed.
function StarterCard({ onDone }: { onDone: () => void }) {
  const [busy, setBusy] = useState(false)
  const load = async () => {
    setBusy(true)
    try {
      const r = await api.loadStarterData()
      toast.success(`Added ${r.products} products and ${r.recipes} recipes. Your shop is ready.`)
      onDone()
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="rounded-2xl border border-brand/30 bg-brand/5 p-5 sm:p-6">
      <h2 className="font-display text-lg font-bold">Your shop has no products yet</h2>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        This is a new database. Load the starting catalogue: the 15 products with their photos, 6 recipes, sample promo codes and the shop settings.
        You can change or delete any of it afterwards.
      </p>
      <button onClick={load} disabled={busy}
        className="mt-4 inline-flex h-11 items-center gap-2 rounded-full bg-brand px-6 text-sm font-bold text-brand-foreground shadow-soft transition hover:opacity-95 disabled:opacity-60">
        {busy ? 'Loading…' : 'Load starting catalogue'}
      </button>
    </div>
  )
}
