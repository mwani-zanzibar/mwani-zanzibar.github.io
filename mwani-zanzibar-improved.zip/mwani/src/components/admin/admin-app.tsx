'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { api } from '@/lib/api'
import { AdminLogin } from '@/components/admin/admin-login'
import { AdminShell } from '@/components/admin/admin-shell'
import { Loader2 } from 'lucide-react'

export function AdminApp({
  authed,
  setAuthed,
}: {
  authed: boolean | null
  setAuthed: (v: boolean) => void
}) {
  const onLogin = () => setAuthed(true)
  const onLogout = async () => {
    await api.logout()
    setAuthed(false)
  }

  if (authed === null) {
    return (
      <div className="relative min-h-screen flex items-center justify-center">
        
        <div className="relative flex flex-col items-center gap-4">
          <div className="relative h-14 w-14 rounded-full bg-surface shadow-lg overflow-hidden ring-1 ring-border/60">
            <Image src="/mwani-logo.png" alt="Mwani logo" fill className="object-contain p-1.5" sizes="56px" />
          </div>
          <Loader2 className="h-5 w-5 animate-spin text-brand" />
          <p className="text-sm text-muted-foreground">Checking admin session…</p>
        </div>
      </div>
    )
  }

  if (!authed) {
    return <AdminLogin onLogin={onLogin} />
  }

  return <AdminShell onLogout={onLogout} />
}
