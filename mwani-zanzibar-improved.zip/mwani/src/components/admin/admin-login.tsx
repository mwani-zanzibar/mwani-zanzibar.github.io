'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Lock, User, Loader2, ArrowLeft, Eye, EyeOff } from 'lucide-react'
import { api, isDemo } from '@/lib/api'
import { asset } from '@/lib/asset'
import { toast } from 'sonner'
import { motion } from 'framer-motion'

export function AdminLogin({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [loading, setLoading] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await api.login(email, password)
      toast.success('Signed in')
      onLogin()
    } catch (err) {
      toast.error((err as Error).message || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center p-4">
      
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-md"
      >
        <div className="rounded-3xl glass-strong border border-border/60 shadow-glow p-8">
          <div className="flex flex-col items-center text-center">
            <div className="relative h-16 w-16 rounded-full bg-surface shadow-lg overflow-hidden ring-1 ring-border/60">
              <Image src={asset("/mwani-logo.png")} alt="Mwani logo" fill className="object-contain p-1.5" sizes="64px" />
            </div>
            <h1 className="mt-4 font-display text-2xl font-bold">Admin Panel</h1>
            <p className="mt-1 text-sm text-muted-foreground">Mwani Zanzibar Seaweed · Wakulima Hai</p>
          </div>

          {isDemo && (
            <p className="mt-5 rounded-xl bg-secondary px-3.5 py-2.5 text-xs text-secondary-foreground">
              Demo mode: the database is not connected yet. Use any email with the password <strong>mwani-demo</strong>. Changes stay in this browser.
            </p>
          )}
          <form onSubmit={submit} className="mt-6 space-y-3">
            <div>
              <label htmlFor="admin-email" className="text-xs font-semibold text-muted-foreground">Admin email</label>
              <div className="relative mt-1">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  value={email}
                  id="admin-email"
                  type="email"
                  required
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-border/70 bg-background pl-10 pr-4 py-2.5 text-sm outline-none focus:border-brand/50 focus:ring-2 focus:ring-brand/15"
                  autoComplete="email"
                />
              </div>
            </div>
            <div>
              <label htmlFor="admin-password" className="text-xs font-semibold text-muted-foreground">Password</label>
              <div className="relative mt-1">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  id="admin-password"
                  required
                  type={show ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-border/70 bg-background pl-10 pr-10 py-2.5 text-sm outline-none focus:border-brand/50 focus:ring-2 focus:ring-brand/15"
                  autoComplete="current-password"
                />
                <button type="button" aria-label={show ? 'Hide password' : 'Show password'} onClick={() => setShow((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-brand text-primary-foreground py-3 text-sm font-bold shadow-glow hover:opacity-95 transition disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
              Sign in
            </button>
          </form>

          <div className="mt-4 rounded-xl bg-brand/5 border border-brand/15 px-4 py-2.5 text-center">
            <p className="text-[11px] text-muted-foreground">Your staff email and password (Firebase → Authentication → Users)</p>
          </div>

          <a href="/" className="mt-5 inline-flex w-full items-center justify-center gap-2 text-xs font-semibold text-muted-foreground hover:text-foreground transition">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to store
          </a>
        </div>
      </motion.div>
    </div>
  )
}
