'use client'

import { useSearchParams } from 'next/navigation'
import { lazy, Suspense, useEffect, useState } from 'react'

// Staff dashboard loads only for ?admin=1, so shoppers never download it.
const AdminApp = lazy(() => import('@/components/admin/admin-app').then((m) => ({ default: m.AdminApp })))
import { StorefrontWithI18n as Storefront } from '@/components/store/storefront'
import { api } from '@/lib/api'

export default function SiteApp() {
  const sp = useSearchParams()
  const isAdmin = sp.get('admin') === '1'
  const [adminAuthed, setAdminAuthed] = useState<boolean | null>(null)

  useEffect(() => {
    if (isAdmin) {
      api.session().then((r) => setAdminAuthed(r.authenticated)).catch(() => setAdminAuthed(false))
    }
  }, [isAdmin])

  if (isAdmin) {
    return <Suspense fallback={null}><AdminApp authed={adminAuthed} setAuthed={setAdminAuthed} /></Suspense>
  }
  return <Storefront />
}
