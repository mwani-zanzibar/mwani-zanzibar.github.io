'use client'

import { useEffect, useState } from 'react'
import { motion, useScroll, useSpring, AnimatePresence } from 'framer-motion'
import { ArrowUp } from 'lucide-react'

export function ScrollUtilities() {
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 25, restDelta: 0.001 })
  const [showTop, setShowTop] = useState(false)
  const [showBar, setShowBar] = useState(false)

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY
      setShowTop(y > 600)
      setShowBar(y > 10)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      {/* scroll progress bar — only visible when scrolled, GPU-composited */}
      <AnimatePresence>
        {showBar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            style={{ scaleX, willChange: 'transform' }}
            className="fixed top-0 left-0 right-0 z-[40] h-1 origin-left bg-brand"
            aria-hidden
          />
        )}
      </AnimatePresence>

      {/* back to top */}
      <AnimatePresence>
        {showTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.5, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.5, y: 20 }}
            whileHover={{ y: -3 }}
            whileTap={{ scale: 0.92 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            aria-label="Back to top"
            className="fixed bottom-5 right-5 z-[40] grid h-11 w-11 place-items-center rounded-full bg-brand text-primary-foreground shadow-glow"
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </>
  )
}
