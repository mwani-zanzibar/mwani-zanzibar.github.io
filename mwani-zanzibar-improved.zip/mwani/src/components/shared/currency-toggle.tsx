'use client'

import { useCurrency, type Currency } from '@/lib/currency-store'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'

export function CurrencyToggle({ className = '' }: { className?: string }) {
  const { currency, setCurrency } = useCurrency()
  const options: Currency[] = ['TZS', 'USD']
  return (
    <div className={`inline-flex items-center rounded-full bg-muted/60 p-0.5 text-[10px] font-bold ${className}`}>
      {options.map((c) => (
        <button
          key={c}
          onClick={() => setCurrency(c)}
          className={cn('relative rounded-full px-2.5 py-1 transition-colors', currency === c ? 'text-primary-foreground' : 'text-muted-foreground hover:text-foreground')}
          aria-label={`Switch to ${c}`}
        >
          {currency === c && (
            <motion.span
              layoutId="currency-active"
              className="absolute inset-0 rounded-full bg-brand"
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            />
          )}
          <span className="relative">{c}</span>
        </button>
      ))}
    </div>
  )
}
