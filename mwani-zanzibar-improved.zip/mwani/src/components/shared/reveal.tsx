'use client'

import { useRef } from 'react'
import { motion, useReducedMotion, useScroll, useTransform, type Variants } from 'framer-motion'
import { cn } from '@/lib/utils'
export { SplitReveal } from '@/components/motion/split-reveal'

// Motion language (see DESIGN.md).
export const EASE_OUT = [0.22, 1, 0.36, 1] as const
export const EASE_IO = [0.65, 0, 0.35, 1] as const
export const SPRING_SNAPPY = { type: 'spring', stiffness: 500, damping: 38 } as const
export const SPRING_SOFT = { type: 'spring', stiffness: 260, damping: 30 } as const
export const SPRING_POP = { type: 'spring', stiffness: 420, damping: 18 } as const
const VIEW = { once: true, margin: '0px 0px -10% 0px' } as const

type As = 'div' | 'li' | 'p' | 'section' | 'span' | 'article'

export function Reveal({ children, className, delay = 0, y = 18, as = 'div' }: { children: React.ReactNode; className?: string; delay?: number; y?: number; as?: As }) {
  const reduce = useReducedMotion()
  const M = motion[as]
  if (reduce) return <M className={className}>{children}</M>
  return (
    <M className={className} initial={{ opacity: 0, y }} whileInView={{ opacity: 1, y: 0 }} viewport={VIEW} transition={{ duration: 0.7, delay, ease: EASE_OUT }}>
      {children}
    </M>
  )
}

// Image unveils upward from a mask while settling from a slight zoom.
export function ImageReveal({ children, className, delay = 0, from = 'bottom' }: { children: React.ReactNode; className?: string; delay?: number; from?: 'bottom' | 'left' | 'right' }) {
  const reduce = useReducedMotion()
  if (reduce) return <div className={cn('relative overflow-hidden', className)}>{children}</div>
  const hidden = from === 'left' ? 'inset(0% 100% 0% 0%)' : from === 'right' ? 'inset(0% 0% 0% 100%)' : 'inset(100% 0% 0% 0%)'
  return (
    <motion.div className={cn('relative overflow-hidden', className)} initial={{ clipPath: hidden }} whileInView={{ clipPath: 'inset(0% 0% 0% 0%)' }} viewport={VIEW} transition={{ duration: 0.95, delay, ease: EASE_IO }}>
      <motion.div className="absolute inset-0" initial={{ scale: 1.14 }} whileInView={{ scale: 1 }} viewport={VIEW} transition={{ duration: 1.4, delay, ease: EASE_OUT }}>
        {children}
      </motion.div>
    </motion.div>
  )
}

const group: Variants = { hidden: {}, show: { transition: { staggerChildren: 0.06 } } }
const item: Variants = { hidden: { opacity: 0, y: 28, scale: 0.97 }, show: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.7, ease: EASE_OUT } } }

export function Stagger({ children, className, as = 'div' }: { children: React.ReactNode; className?: string; as?: 'div' | 'ul' | 'ol' }) {
  const reduce = useReducedMotion()
  const M = motion[as]
  if (reduce) return <M className={className}>{children}</M>
  return <M className={className} variants={group} initial="hidden" whileInView="show" viewport={VIEW}>{children}</M>
}
export function StaggerItem({ children, className, as = 'div' }: { children: React.ReactNode; className?: string; as?: 'div' | 'li' }) {
  const M = motion[as]
  return <M className={className} variants={item}>{children}</M>
}

// Moves its child against the scroll for depth. amount = px of travel.
export function Parallax({ children, className, amount = 60 }: { children: React.ReactNode; className?: string; amount?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const y = useTransform(scrollYProgress, [0, 1], [amount, -amount])
  return <motion.div ref={ref} className={className} style={reduce ? undefined : { y }}>{children}</motion.div>
}

// Back-compat names used by older components.
export function Lines({ text, className }: { text: string; className?: string; delay?: number; inView?: boolean }) { return <span className={className}>{text}</span> }
export const Words = Lines
export const RevealText = Lines
export function RevealClip({ children, className }: { children: React.ReactNode; className?: string }) { return <Reveal className={className}>{children}</Reveal> }
export function RevealScale({ children, className }: { children: React.ReactNode; className?: string }) { return <Reveal className={className}>{children}</Reveal> }
