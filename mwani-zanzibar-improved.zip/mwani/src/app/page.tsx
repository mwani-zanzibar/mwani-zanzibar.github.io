import { Suspense } from 'react'
import SiteApp from '@/components/site-app'

export default function Page() {
  return (
    <Suspense
      fallback={
        <div className="grid min-h-screen place-items-center bg-background">
          <p className="text-sm text-muted-foreground">Loading Mwani Zanzibar…</p>
        </div>
      }
    >
      <SiteApp />
    </Suspense>
  )
}
