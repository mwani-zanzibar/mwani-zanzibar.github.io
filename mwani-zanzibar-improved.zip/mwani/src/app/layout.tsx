import type { Metadata } from "next";
import { Figtree, Fraunces, Quicksand } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";

const figtree = Figtree({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const fraunces = Fraunces({
  variable: "--font-display",
  subsets: ["latin"],
  style: ["normal", "italic"],
  axes: ["SOFT", "WONK", "opsz"],
  display: "swap",
});

// Only for the logotype: matches the lettering in the Mwani logo.
const quicksand = Quicksand({
  variable: "--font-logo",
  subsets: ["latin"],
  weight: ["600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Mwani Zanzibar Seaweed — 100% Organic Seaweed Products from Zanzibar",
  description:
    "Mwani Zanzibar Seaweed by Wakulima Hai Co-operative Society — organic seaweed powder, tea, capsules, soaps, oils & skincare, sustainably harvested by women farmers in Zanzibar. Order online and confirm on WhatsApp.",
  keywords: [
    "Mwani Zanzibar", "Zanzibar Seaweed", "Wakulima Hai", "seaweed powder",
    "seaweed tea", "seaweed capsules", "Zanzibar products", "organic seaweed",
  ],
  authors: [{ name: "Wakulima Hai Co-operative Society" }],
  icons: { icon: `${process.env.NEXT_PUBLIC_BASE_PATH || ""}/brand/mwani-mark.png` },
  openGraph: {
    title: "Mwani Zanzibar Seaweed",
    description: "100% organic Zanzibar seaweed — food, wellness & skincare by Wakulima Hai farmers.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Mwani Zanzibar Seaweed",
    description: "100% organic Zanzibar seaweed — food, wellness & skincare by Wakulima Hai farmers.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${figtree.variable} ${fraunces.variable} ${quicksand.variable} font-sans antialiased text-foreground`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
          <Toaster position="top-center" richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
