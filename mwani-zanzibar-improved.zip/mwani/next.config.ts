import type { NextConfig } from 'next'

// For GitHub Pages project sites (username.github.io/<repo>/), build with
//   NEXT_PUBLIC_BASE_PATH=/<repo> npm run build
// Leave it empty for a custom domain or username.github.io root.
const basePath = (process.env.NEXT_PUBLIC_BASE_PATH || '').replace(/\/$/, '')

const nextConfig: NextConfig = {
  output: 'export',
  basePath: basePath || undefined,
  trailingSlash: true,
  reactStrictMode: true,
  // Static hosting has no image optimiser; this loader only adds the base path.
  images: { loader: 'custom', loaderFile: './src/lib/image-loader.ts' },
}

export default nextConfig
